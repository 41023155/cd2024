﻿# NX 1872
# Journal created by liyu8 on Wed May 15 14:55:01 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Display
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, True)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(True)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject1 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject1
    feature1 = sketch1.Feature
    
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId4)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId3, None)
    
    theSession.SetUndoMarkName(markId1, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId6, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(169.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(169.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(169.0, 0.0, 16.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(169.0, 0.0, 16.0)
    endPoint3 = NXOpen.Point3d(0.0, 0.0, 16.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, 0.0, 16.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(84.5, 0.0, -10.497347910803205)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(179.4973479108032, 0.0, 8.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId7, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point1_1 = NXOpen.Point3d(84.5, 0.0, 16.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(0.0, 0.0, 16.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line3, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    point1_3 = NXOpen.Point3d(84.5, 0.0, 16.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(0.0, 0.0, 16.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line3, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Destroy()
    
    theSession.UndoToMark(markId7, None)
    
    theSession.DeleteUndoMark(markId7, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines9 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines12)
    
    theSession.SetUndoMarkName(markId8, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    point3 = NXOpen.Point3d(25.459713596166836, 0.0, 16.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line3, workPart.ModelingViews.WorkView, point3)
    
    point1_5 = NXOpen.Point3d(0.0, 0.0, 16.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line3, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(169.0, 0.0, 16.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point4 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point4
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point5 = NXOpen.Point3d(25.151111007122374, 0.0, 33.329079616800172)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point5)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject2 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.SetUndoMarkName(markId8, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId8, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("120")
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.7100591715976331)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId11, None)
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId10, "Edit Driving Value")
    
    scaleAboutPoint1 = NXOpen.Point3d(135.32223529598963, 0.30860258904445631, 0.0)
    viewCenter1 = NXOpen.Point3d(-135.32223529598963, -0.30860258904445631, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(108.25778823679173, 0.24688207123556508, 0.0)
    viewCenter2 = NXOpen.Point3d(-108.25778823679173, -0.24688207123556508, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(86.606230589433324, 0.19750565698845202, 0.0)
    viewCenter3 = NXOpen.Point3d(-86.606230589433324, -0.19750565698845202, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    point6 = NXOpen.Point3d(120.0, 0.0, 3.1526840496780681)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(line2, workPart.ModelingViews.WorkView, point6)
    
    point1_7 = NXOpen.Point3d(120.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(120.0, 0.0, 11.36094674556213)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder3.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point7
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder3.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point8 = NXOpen.Point3d(157.28486435310464, 0.0, 1.4146342681797488)
    sketchRapidDimensionBuilder3.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.TextCentered = False
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject3 = sketchRapidDimensionBuilder3.Commit()
    
    theSession.DeleteUndoMark(markId13, None)
    
    theSession.SetUndoMarkName(markId12, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId14, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("5")
    
    theSession.SetUndoMarkVisibility(markId14, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId15, None)
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId14, "Edit Driving Value")
    
    sketchRapidDimensionBuilder4.Destroy()
    
    theSession.UndoToMark(markId16, None)
    
    theSession.DeleteUndoMark(markId16, None)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId18, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("120")
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    targetBodies3 = []
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies3)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(38.062848679815318, 0.0, 4.9999999999999929)
    section1.AddToSection(rules1, line3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId20, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId19, None)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId21, None)
    
    theSession.SetUndoMarkName(markId18, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.StartExtend.Value
    expression12 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("120")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId22, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder2.Destroy()
    
    section2.Destroy()
    
    workPart.Expressions.Delete(expression13)
    
    theSession.UndoToMark(markId22, None)
    
    theSession.DeleteUndoMark(markId22, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId23, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 140 * 170 {(0,-120,5)(0,-60,5)(0,0,5) EXTRUDE(2)}")
    point9 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction3 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 140 {(60,-60,5) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point9, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression17 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point10 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId24, None)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject4 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject4
    feature3 = sketch3.Feature
    
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId26)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId25, None)
    
    theSession.SetUndoMarkName(markId23, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point10)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression17)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    scaleAboutPoint4 = NXOpen.Point3d(61.257613925322545, -50.302222014244727, 0.0)
    viewCenter4 = NXOpen.Point3d(-61.257613925322545, 50.302222014244727, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(49.006091140258029, -40.241777611395797, 0.0)
    viewCenter5 = NXOpen.Point3d(-49.006091140258029, 40.241777611395754, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(39.204872912206405, -32.193422089116638, 0.0)
    viewCenter6 = NXOpen.Point3d(-39.204872912206405, 32.193422089116602, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(33.25995263685423, -24.174692415385735, 0.0)
    viewCenter7 = NXOpen.Point3d(-33.25995263685423, 24.174692415385735, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(43.549997365952215, -28.440814606336144, 0.0)
    viewCenter8 = NXOpen.Point3d(-43.549997365952215, 28.440814606336144, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(55.671907063618072, -34.069725830506847, 0.0)
    viewCenter9 = NXOpen.Point3d(-55.671907063618072, 34.069725830506847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(70.515691596655813, -41.969952110044638, 0.0)
    viewCenter10 = NXOpen.Point3d(-70.51569159665587, 41.969952110044638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(88.144614495819866, -52.076686901250262, 0.0)
    viewCenter11 = NXOpen.Point3d(-88.144614495819866, 52.076686901250262, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(199.86839556081699, -95.956117531007422, 0.0)
    viewCenter12 = NXOpen.Point3d(-199.86839556081699, 95.956117531007422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(245.61631842892911, -155.50677338567783, 0.0)
    viewCenter13 = NXOpen.Point3d(-245.61631842892911, 155.50677338567783, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(196.49305474314329, -126.816376435452, 0.0)
    viewCenter14 = NXOpen.Point3d(-196.49305474314338, 126.816376435452, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(158.35170350343125, -115.72597089166722, 0.0)
    viewCenter15 = NXOpen.Point3d(-158.35170350343139, 115.72597089166722, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(126.68136280274494, -92.580776713333762, 0.0)
    viewCenter16 = NXOpen.Point3d(-126.6813628027451, 92.580776713333762, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId28, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(55.0, -68.0, 4.9999999999999956)
    endPoint5 = NXOpen.Point3d(55.0, -55.0, 4.9999999999999956)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(55.0, -55.0, 4.9999999999999956)
    endPoint6 = NXOpen.Point3d(68.0, -55.0, 4.9999999999999973)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(68.0, -55.0, 4.9999999999999973)
    endPoint7 = NXOpen.Point3d(68.0, -68.0, 4.9999999999999973)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(68.0, -68.0, 4.9999999999999973)
    endPoint8 = NXOpen.Point3d(55.0, -68.0, 4.9999999999999956)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line5
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom6)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = line5
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line5
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 0.0
    dimObject2_3.HelpPoint.Y = 0.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(63.397878328642562, -61.5, 4.9999999999999964)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint3
    dimension3 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression18 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line6
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line6
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(61.5, -63.397878328642562, 4.9999999999999964)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression19 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines25 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines28)
    
    theSession.SetUndoMarkName(markId29, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint17 = NXOpen.Point3d(31.724346153768966, -31.107140975680135, 0.0)
    viewCenter17 = NXOpen.Point3d(-31.724346153769151, 31.107140975680135, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(25.37947692301514, -24.688207123555671, 0.0)
    viewCenter18 = NXOpen.Point3d(-25.379476923015336, 24.688207123555671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    point11 = NXOpen.Point3d(55.0, -64.778922743652259, 4.9999999999999956)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(line5, workPart.ModelingViews.WorkView, point11)
    
    point1_9 = NXOpen.Point3d(55.0, -68.0, 4.9999999999999956)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(55.0, -55.0, 4.9999999999999956)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point12 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point12
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point13 = NXOpen.Point3d(47.754051861181111, -65.094931794833769, 4.9999999999999947)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point13)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject5 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId29, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId29, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId31, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p4")
    expression20.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId31, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.46153846153846156)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId32, None)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId31, "Edit Driving Value")
    
    scaleAboutPoint19 = NXOpen.Point3d(-34.207979790398817, 35.077004681147898, 0.0)
    viewCenter19 = NXOpen.Point3d(34.207979790398646, -35.077004681147898, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(-27.36638383231908, 28.061603744918322, 0.0)
    viewCenter20 = NXOpen.Point3d(27.366383832318903, -28.061603744918322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-21.893107065855279, 22.449282995934656, 0.0)
    viewCenter21 = NXOpen.Point3d(21.893107065855101, -22.449282995934656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-17.514485652684233, 17.95942639674772, 0.0)
    viewCenter22 = NXOpen.Point3d(17.514485652684073, -17.959426396747727, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    point14 = NXOpen.Point3d(29.583531418244142, -90.0, 4.9999999999999929)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(line6, workPart.ModelingViews.WorkView, point14)
    
    point1_11 = NXOpen.Point3d(31.384615384615387, -90.0, 4.9999999999999929)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(25.384615384615387, -90.0, 4.999999999999992)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point15 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point15
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point16 = NXOpen.Point3d(28.548032959332559, -85.816782913389801, 4.9999999999999929)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point16)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = True
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId34, None)
    
    theSession.SetUndoMarkName(markId33, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId33, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines33 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines36)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId35, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression21 = workPart.Expressions.FindObject("p5")
    expression21.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId35, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId36, None)
    
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId35, "Edit Driving Value")
    
    sketchRapidDimensionBuilder7.Destroy()
    
    theSession.UndoToMark(markId37, None)
    
    theSession.DeleteUndoMark(markId37, None)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    scaleAboutPoint23 = NXOpen.Point3d(-9.0929708423173992, 16.373819381539374, 0.0)
    viewCenter23 = NXOpen.Point3d(9.0929708423172428, -16.373819381539366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(-7.2743766738539435, 13.099055505231497, 0.0)
    viewCenter24 = NXOpen.Point3d(7.2743766738537676, -13.099055505231497, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(-7.1863593048464542, 15.118277500109084, 0.0)
    viewCenter25 = NXOpen.Point3d(7.1863593048462828, -15.118277500109084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines41 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines44)
    
    theSession.SetUndoMarkName(markId38, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint26 = NXOpen.Point3d(-2.3557589940239332, 17.396374109714554, 0.0)
    viewCenter26 = NXOpen.Point3d(2.3557589940237622, -17.396374109714568, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(-1.8846071952191608, 13.917099287771647, 0.0)
    viewCenter27 = NXOpen.Point3d(1.8846071952189898, -13.917099287771654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(-1.5076857561753445, 11.133679430217311, 0.0)
    viewCenter28 = NXOpen.Point3d(1.5076857561751804, -11.133679430217322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(-1.206148604940293, 8.9069435441738509, 0.0)
    viewCenter29 = NXOpen.Point3d(1.2061486049401267, -8.9069435441738545, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(-0.96491888395225134, 7.1467618437775835, 0.0)
    viewCenter30 = NXOpen.Point3d(0.96491888395208159, -7.1467618437775906, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(-1.206148604940297, 8.9334523047219818, 0.0)
    viewCenter31 = NXOpen.Point3d(1.2061486049401218, -8.9334523047219925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(-1.5076857561753494, 11.166815380902479, 0.0)
    viewCenter32 = NXOpen.Point3d(1.5076857561751718, -11.16681538090249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-1.8846071952191661, 13.958519226128097, 0.0)
    viewCenter33 = NXOpen.Point3d(1.8846071952189953, -13.958519226128111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-2.5110837628606704, 17.810573493279175, 0.0)
    viewCenter34 = NXOpen.Point3d(2.5110837628604994, -17.810573493279197, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-3.1388547035758161, 22.263216866598967, 0.0)
    viewCenter35 = NXOpen.Point3d(3.1388547035756456, -22.263216866598984, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(-4.0044666965722211, 27.909919400351189, 0.0)
    viewCenter36 = NXOpen.Point3d(4.0044666965720275, -27.9099194003512, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(-5.207829163471442, 34.988522146817068, 0.0)
    viewCenter37 = NXOpen.Point3d(5.2078291634712253, -34.988522146817083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint37, viewCenter37)
    
    scaleAboutPoint38 = NXOpen.Point3d(6.2569792133938558, 1.769650686616467, 0.0)
    viewCenter38 = NXOpen.Point3d(-6.2569792133940441, -1.7696506866164774, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(5.0055833707150503, 1.4157205492931735, 0.0)
    viewCenter39 = NXOpen.Point3d(-5.0055833707152511, -1.4157205492931735, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(4.0044666965720142, 1.1325764394345388, 0.0)
    viewCenter40 = NXOpen.Point3d(-4.0044666965722273, -1.1325764394345388, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(5.0055833707150672, 1.4157205492931735, 0.0)
    viewCenter41 = NXOpen.Point3d(-5.0055833707152511, -1.4157205492931817, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(6.2569792133938558, 1.8960543070890763, 0.0)
    viewCenter42 = NXOpen.Point3d(-6.2569792133940441, -1.8960543070890763, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(7.1892059143793245, 2.8440814606336167, 0.0)
    viewCenter43 = NXOpen.Point3d(-7.1892059143794809, -2.8440814606336167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(5.6289112241706016, 22.120633582705878, 0.0)
    viewCenter44 = NXOpen.Point3d(-5.6289112241707979, -22.120633582705878, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(6.7892569589777274, 28.391438192089009, 0.0)
    viewCenter45 = NXOpen.Point3d(-6.7892569589779113, -28.391438192089009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(0.15430129452215161, 79.928070562511451, 0.0)
    viewCenter46 = NXOpen.Point3d(-0.1543012945222535, -79.928070562511465, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint46, viewCenter46)
    
    scaleAboutPoint47 = NXOpen.Point3d(0.1928766181527532, 109.16816587447271, 0.0)
    viewCenter47 = NXOpen.Point3d(-0.1928766181527532, -109.16816587447271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(0.15430129452215161, 87.643135288622588, 0.0)
    viewCenter48 = NXOpen.Point3d(-0.1543012945222535, -87.643135288622616, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(0.12344103561776203, 70.3613903021336, 0.0)
    viewCenter49 = NXOpen.Point3d(-0.12344103561780279, -70.361390302133671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(0.098752828494177006, 51.943987787961071, 0.0)
    viewCenter50 = NXOpen.Point3d(-0.098752828494242217, -51.943987787961134, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(0.86902489074912281, 33.180950374058796, 0.0)
    viewCenter51 = NXOpen.Point3d(-0.86902489074920108, -33.180950374058831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    point1_13 = NXOpen.Point3d(25.384615384615387, -96.0, 4.999999999999992)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point17 = NXOpen.Point3d(0.0, -93.519950214732987, 4.9999999999999893)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(edge1, workPart.ModelingViews.WorkView, point17)
    
    point1_14 = NXOpen.Point3d(0.0, -93.519950214732987, 4.9999999999999893)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge1, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(25.384615384615387, -96.0, 4.999999999999992)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line5, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point18 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point18
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point19 = NXOpen.Point3d(7.1813557765418627, -138.77244634392557, 4.9999999999999902)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point19)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId39, None)
    
    theSession.SetUndoMarkName(markId38, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId38, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId40, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits213 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression22 = workPart.Expressions.FindObject("p6")
    expression22.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId40, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId41, None)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId40, "Edit Driving Value")
    
    point20 = NXOpen.Point3d(58.374822067946866, -89.999999999999986, 4.9999999999999964)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(line6, workPart.ModelingViews.WorkView, point20)
    
    point1_16 = NXOpen.Point3d(59.899999999999999, -89.999999999999986, 4.9999999999999964)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line6, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(54.0, -89.999999999999986, 4.9999999999999956)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    dimensionlinearunits223 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits225 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    point1_18 = NXOpen.Point3d(60.0, 0.0, 4.9999999999999964)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(58.374822067946866, -89.999999999999986, 4.9999999999999964)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(60.0, 0.0, 4.9999999999999964)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(58.374822067946866, -89.999999999999986, 4.9999999999999964)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(60.0, 0.0, 4.9999999999999964)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line3, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    dimensionlinearunits229 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point21 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point21
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point22 = NXOpen.Point3d(-5.3326026502460246, -33.98384497213604, 4.9999999999999885)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point22)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject8 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId43, None)
    
    theSession.SetUndoMarkName(markId42, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId42, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId44, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression23 = workPart.Expressions.FindObject("p7")
    expression23.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId44, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId45, None)
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId44, "Edit Driving Value")
    
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId46, None)
    
    theSession.DeleteUndoMark(markId46, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch4 = theSession.ActiveSketch
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression24 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("120")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId48, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scalar3 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 120 * 140 {(0,0,5)(60,0,5)(120,0,5) EXTRUDE(2)}")
    point23 = workPart.Points.CreatePoint(edge2, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction4 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction4, point23, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem3
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature4 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    theSession.BeginTaskEnvironment()
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    sketchInPlaceBuilder3.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject9 = sketchInPlaceBuilder3.Commit()
    
    sketchInPlaceBuilder3.Destroy()
    
    sketch5 = nXObject9
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.DeleteUndoMarksUpToMark(markId50, None, True)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_002")
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Dialog Begin Profile
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId52, "Curve")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.Preferences.Sketch.SectionView = False
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.SketchOnly)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId49, None)
    
    theSession.DeleteUndoMark(markId49, None)
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    datumCsys3 = feature4
    nErrs3 = theSession.UpdateManager.AddToDeleteList(datumCsys3)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section3.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(59.899999999999991, -58.925718256395491, 5.0)
    section3.AddToSection(rules2, line7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId55, None)
    
    direction5 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction5
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies8[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies9)
    
    expression25 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId54, None)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = body1
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies10)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    feature5 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId48, "Extrude")
    
    expression26 = extrudeBuilder3.Limits.StartExtend.Value
    expression27 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression24)
    
    workPart.Expressions.Delete(expression25)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId57, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder4.Destroy()
    
    section4.Destroy()
    
    workPart.Expressions.Delete(expression28)
    
    theSession.UndoToMark(markId57, None)
    
    theSession.DeleteUndoMark(markId57, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.PlaneReference = plane7
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId58, "Create Sketch Dialog")
    
    scalar4 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point24 = workPart.Points.CreatePoint(edge1, scalar4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature5
    edge3 = extrude2.FindObject("EDGE * 140 EXTRUDE(2) 140 {(59.9,-60,5)(59.9,-57,5)(59.9,-54,5) EXTRUDE(2)}")
    direction6 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction6, point24, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin8, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face1
    plane8.SetGeometry(geom7)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin9, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression31 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar5 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point25 = workPart.Points.CreatePoint(edge1, scalar5, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face1
    plane9.SetGeometry(geom8)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId59, None)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject10 = sketchInPlaceBuilder4.Commit()
    
    sketch6 = nXObject10
    feature6 = sketch6.Feature
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId61)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId60, None)
    
    theSession.SetUndoMarkName(markId58, "Create Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point25)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression32)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression31)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    scaleAboutPoint52 = NXOpen.Point3d(78.539358911811533, -78.693660206333746, 0.0)
    viewCenter52 = NXOpen.Point3d(-78.539358911811533, 78.693660206333746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(92.002146858875435, -101.45310114836165, 0.0)
    viewCenter53 = NXOpen.Point3d(-92.002146858875435, 101.45310114836158, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(130.91500457119861, -152.37252834069523, 0.0)
    viewCenter54 = NXOpen.Point3d(-130.91500457119861, 152.37252834069517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(105.11775689326444, -123.05528238147286, 0.0)
    viewCenter55 = NXOpen.Point3d(-105.11775689326444, 123.05528238147279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(84.094205514611531, -98.444225905178286, 0.0)
    viewCenter56 = NXOpen.Point3d(-84.094205514611531, 98.444225905178229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(81.594524543351511, -89.12442771603601, 0.0)
    viewCenter57 = NXOpen.Point3d(-81.594524543351511, 89.124427716035967, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(65.275619634681206, -71.299542172828822, 0.0)
    viewCenter58 = NXOpen.Point3d(-65.275619634681206, 71.299542172828765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(50.008432349474376, -53.08952059849414, 0.0)
    viewCenter59 = NXOpen.Point3d(-50.008432349474376, 53.089520598494111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(62.313034779854497, -66.361900748117677, 0.0)
    viewCenter60 = NXOpen.Point3d(-62.313034779854561, 66.361900748117662, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(77.39752933234702, -82.458611792675981, 0.0)
    viewCenter61 = NXOpen.Point3d(-77.397529332347062, 82.458611792675953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint61, viewCenter61)
    
    scaleAboutPoint62 = NXOpen.Point3d(96.129706487344905, -102.1474569737116, 0.0)
    viewCenter62 = NXOpen.Point3d(-96.129706487344905, 102.14745697371157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(120.16213310918118, -127.68432121713951, 0.0)
    viewCenter63 = NXOpen.Point3d(-120.16213310918118, 127.68432121713951, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(104.87666112057349, 35.682174358264056, 0.0)
    viewCenter64 = NXOpen.Point3d(-104.87666112057349, -35.682174358264056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(83.901328896458793, 28.545739486611243, 0.0)
    viewCenter65 = NXOpen.Point3d(-83.901328896458793, -28.545739486611243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(67.121063117166997, 22.836591589288993, 0.0)
    viewCenter66 = NXOpen.Point3d(-67.121063117166997, -22.836591589288993, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(83.515575660153218, 28.545739486611211, 0.0)
    viewCenter67 = NXOpen.Point3d(-83.515575660153218, -28.545739486611275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(103.91227802980957, 33.753408176736244, 0.0)
    viewCenter68 = NXOpen.Point3d(-103.91227802980957, -33.753408176736322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(129.8903475372619, 40.986281357465423, 0.0)
    viewCenter69 = NXOpen.Point3d(-129.8903475372619, -40.986281357465522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(162.36293442157734, 51.232851696831759, 0.0)
    viewCenter70 = NXOpen.Point3d(-162.36293442157719, -51.232851696831887, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(310.31662930342071, -110.18830236267149, 0.0)
    viewCenter71 = NXOpen.Point3d(-310.31662930342071, 110.18830236267134, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(248.25330344273658, -88.150641890137194, 0.0)
    viewCenter72 = NXOpen.Point3d(-248.25330344273658, 88.150641890137067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    scaleAboutPoint73 = NXOpen.Point3d(198.6026427541893, -70.520513512109758, 0.0)
    viewCenter73 = NXOpen.Point3d(-198.60264275418939, 70.520513512109659, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(153.095815658768, -64.131475535799012, 0.0)
    viewCenter74 = NXOpen.Point3d(-153.09581565876817, 64.131475535798842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(118.61912016395884, -53.619699846472564, 0.0)
    viewCenter75 = NXOpen.Point3d(-118.61912016395897, 53.619699846472372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    scaleAboutPoint76 = NXOpen.Point3d(88.723244350278165, -41.969952110044737, 0.0)
    viewCenter76 = NXOpen.Point3d(-88.723244350278293, 41.969952110044559, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(57.646963633502381, -25.428853337262428, 0.0)
    viewCenter77 = NXOpen.Point3d(-57.646963633502565, 25.428853337262268, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-50.067684046570989, 15.997958216063992, 0.0)
    viewCenter78 = NXOpen.Point3d(50.067684046570797, -15.997958216064124, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint78, viewCenter78)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId63, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(55.0, -114.0, 4.9999999999999956)
    endPoint9 = NXOpen.Point3d(55.0, -107.0, 4.9999999999999956)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(55.0, -107.0, 4.9999999999999956)
    endPoint10 = NXOpen.Point3d(61.0, -107.0, 4.9999999999999964)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(61.0, -107.0, 4.9999999999999964)
    endPoint11 = NXOpen.Point3d(61.0, -114.0, 4.9999999999999964)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(61.0, -114.0, 4.9999999999999964)
    endPoint12 = NXOpen.Point3d(55.0, -114.0, 4.9999999999999956)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint21 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom9.Geometry = line9
    geom9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateHorizontalConstraint(geom9)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line9
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line10
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_9, conGeom2_9)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line10
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = line11
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_10, conGeom2_10)
    
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line11
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line12
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_11, conGeom2_11)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line12
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line9
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line9
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line9
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(60.374642130331239, -110.5, 4.9999999999999964)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression33 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line10
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line10
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(58.0, -112.37464213033124, 4.9999999999999964)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression34 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId64, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(109.0, -61.0, 5.0000000000000018)
    endPoint13 = NXOpen.Point3d(109.0, -53.0, 5.0000000000000018)
    line13 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(109.0, -53.0, 5.0000000000000018)
    endPoint14 = NXOpen.Point3d(115.0, -53.0, 5.0000000000000027)
    line14 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(115.0, -53.0, 5.0000000000000027)
    endPoint15 = NXOpen.Point3d(115.0, -61.0, 5.0000000000000027)
    line15 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(115.0, -61.0, 5.0000000000000027)
    endPoint16 = NXOpen.Point3d(109.0, -61.0, 5.0000000000000018)
    line16 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line13, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line13
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line14
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line14
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line15
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line15
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line16
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line16
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line13
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint32 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom10.Geometry = line13
    geom10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateHorizontalConstraint(geom10)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line13
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line14
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line14
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line15
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line15
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line16
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line16
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line13
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_16, conGeom2_16)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line13
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line13
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(114.37464213033124, -57.0, 5.0000000000000027)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression35 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line14
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line14
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(112.0, -58.374642130331239, 5.0000000000000018)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression36 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line13
    geoms7[1] = line14
    geoms7[2] = line15
    geoms7[3] = line16
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line13
    geoms8[1] = line14
    geoms8[2] = line15
    geoms8[3] = line16
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines57 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines60)
    
    theSession.SetUndoMarkName(markId65, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint79 = NXOpen.Point3d(-64.228839652642549, 17.380497814983123, 0.0)
    viewCenter79 = NXOpen.Point3d(64.228839652642336, -17.380497814983254, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-51.509475342586647, 13.398783770096076, 0.0)
    viewCenter80 = NXOpen.Point3d(51.509475342586455, -13.398783770096221, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint80, viewCenter80)
    
    point26 = NXOpen.Point3d(55.0, -109.10197403132302, 4.9999999999999956)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point26)
    
    point1_23 = NXOpen.Point3d(55.0, -107.0, 4.9999999999999956)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(55.0, -114.0, 4.9999999999999956)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point27 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point27
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder11.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point28 = NXOpen.Point3d(50.545846881591459, -109.00085113494494, 4.9999999999999956)
    sketchRapidDimensionBuilder11.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point28)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.TextCentered = False
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject11 = sketchRapidDimensionBuilder11.Commit()
    
    theSession.DeleteUndoMark(markId66, None)
    
    theSession.SetUndoMarkName(markId65, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId65, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder11.Destroy()
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines61 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines64)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId67, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    expression37 = workPart.Expressions.FindObject("p10")
    expression37.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId67, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.8571428571428571)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId68, None)
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId67, "Edit Driving Value")
    
    point1_25 = NXOpen.Point3d(49.714285714285708, -108.85714285714286, 4.9999999999999947)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line10, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    theSession.UndoToMark(markId69, None)
    
    theSession.DeleteUndoMark(markId69, None)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines69 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines72)
    
    theSession.SetUndoMarkName(markId70, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point29 = NXOpen.Point3d(50.849215570725704, -108.85714285714286, 4.9999999999999956)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(line10, workPart.ModelingViews.WorkView, point29)
    
    point1_26 = NXOpen.Point3d(52.285714285714285, -108.85714285714286, 4.9999999999999956)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    point1_27 = NXOpen.Point3d(47.142857142857139, -108.85714285714286, 4.9999999999999947)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point30 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point30
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point31 = NXOpen.Point3d(49.73686371056678, -105.15818107257772, 4.9999999999999947)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point31)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = True
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject12 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId71, None)
    
    theSession.SetUndoMarkName(markId70, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId70, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId72, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression38 = workPart.Expressions.FindObject("p11")
    expression38.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId72, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId73, None)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId72, "Edit Driving Value")
    
    scaleAboutPoint81 = NXOpen.Point3d(5.0055833707150637, -28.415533882241668, 0.0)
    viewCenter81 = NXOpen.Point3d(-5.0055833707152306, 28.415533882241526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(6.2569792133938291, -40.322754930761057, 0.0)
    viewCenter82 = NXOpen.Point3d(-6.2569792133940378, 40.322754930760908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(5.0055833707150477, -32.359326840986952, 0.0)
    viewCenter83 = NXOpen.Point3d(-5.0055833707152484, 32.359326840986789, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(3.9235683794695673, -25.968359789892027, 0.0)
    viewCenter84 = NXOpen.Point3d(-3.9235683794697547, 25.968359789891888, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(3.1388547035756318, -20.774687831913639, 0.0)
    viewCenter85 = NXOpen.Point3d(-3.1388547035758241, 20.774687831913493, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    point32 = NXOpen.Point3d(94.185714285714255, -63.489884882609999, 5.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(line13, workPart.ModelingViews.WorkView, point32)
    
    point1_28 = NXOpen.Point3d(94.185714285714255, -62.571428571428555, 5.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(94.185714285714255, -69.428571428571416, 5.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line13, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point33 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point33
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder14.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point34 = NXOpen.Point3d(90.338515589538488, -63.748759497337893, 5.0)
    sketchRapidDimensionBuilder14.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point34)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.TextCentered = False
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject13 = sketchRapidDimensionBuilder14.Commit()
    
    theSession.DeleteUndoMark(markId75, None)
    
    theSession.SetUndoMarkName(markId74, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId74, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines77 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines80)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId76, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    expression39 = workPart.Expressions.FindObject("p12")
    expression39.SetFormula("5.9")
    
    theSession.SetUndoMarkVisibility(markId76, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId77, None)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId76, "Edit Driving Value")
    
    point35 = NXOpen.Point3d(98.208303877266502, -63.528571428571396, 5.0000000000000009)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(line14, workPart.ModelingViews.WorkView, point35)
    
    point1_30 = NXOpen.Point3d(99.328571428571394, -63.528571428571396, 5.0000000000000009)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(94.185714285714241, -63.528571428571396, 5.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line14, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point36 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point36
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point37 = NXOpen.Point3d(97.483454956028396, -59.037241509290205, 5.0000000000000009)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point37)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = False
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject14 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId79, None)
    
    theSession.SetUndoMarkName(markId78, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId78, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId80, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    expression40 = workPart.Expressions.FindObject("p13")
    expression40.SetFormula("6")
    
    theSession.SetUndoMarkVisibility(markId80, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId81, None)
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId80, "Edit Driving Value")
    
    sketchRapidDimensionBuilder16.Destroy()
    
    theSession.UndoToMark(markId82, None)
    
    theSession.DeleteUndoMark(markId82, None)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    scaleAboutPoint86 = NXOpen.Point3d(-10.277322204697528, -6.4718653681974505, 0.0)
    viewCenter86 = NXOpen.Point3d(10.27732220469734, 6.4718653681973057, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-8.1804378254015848, -5.1774922945579718, 0.0)
    viewCenter87 = NXOpen.Point3d(8.1804378254013876, 5.1774922945578288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-6.5443502603212904, -4.1419938356463915, 0.0)
    viewCenter88 = NXOpen.Point3d(6.5443502603210888, 4.1419938356462493, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-5.2089714477089109, -2.7834198575543967, 0.0)
    viewCenter89 = NXOpen.Point3d(5.2089714477087101, 2.7834198575542546, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-6.4780783589509383, -2.4520603507026904, 0.0)
    viewCenter90 = NXOpen.Point3d(6.4780783589507411, 2.4520603507025482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-8.0975979486886533, -3.0650754383783432, 0.0)
    viewCenter91 = NXOpen.Point3d(8.0975979486884473, 3.0650754383782028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-10.12199743586079, -3.8313442979729153, 0.0)
    viewCenter92 = NXOpen.Point3d(10.121997435860601, 3.8313442979727701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    scaleAboutPoint93 = NXOpen.Point3d(-12.652496794825952, -4.7891803724661219, 0.0)
    viewCenter93 = NXOpen.Point3d(12.652496794825755, 4.7891803724659834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(-15.572926042225028, -5.1774922945579602, 0.0)
    viewCenter94 = NXOpen.Point3d(15.572926042224827, 5.1774922945578261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(-19.466157552781233, -6.4718653681974416, 0.0)
    viewCenter95 = NXOpen.Point3d(19.466157552781052, 6.4718653681972995, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(-24.332696940976529, -8.0898317102467843, 0.0)
    viewCenter96 = NXOpen.Point3d(24.332696940976351, 8.0898317102466475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(-30.415871176220634, -10.112289637808466, 0.0)
    viewCenter97 = NXOpen.Point3d(30.415871176220477, 10.112289637808335, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint97, viewCenter97)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines89 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines92)
    
    theSession.SetUndoMarkName(markId83, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint98 = NXOpen.Point3d(-72.978340257230556, 27.255780664405361, 0.0)
    viewCenter98 = NXOpen.Point3d(72.978340257230371, -27.255780664405506, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(-58.382672205784438, 21.804624531524272, 0.0)
    viewCenter99 = NXOpen.Point3d(58.382672205784274, -21.804624531524414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(-46.70613776462757, 17.443699625219399, 0.0)
    viewCenter100 = NXOpen.Point3d(46.706137764627407, -17.443699625219555, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    scaleAboutPoint101 = NXOpen.Point3d(-39.791859724776096, 22.651528788690715, 0.0)
    viewCenter101 = NXOpen.Point3d(39.791859724775925, -22.65152878869085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(-49.613421035497488, 42.977230960685574, 0.0)
    viewCenter102 = NXOpen.Point3d(49.613421035497318, -42.977230960685723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(-62.01677629437183, 53.721538700856982, 0.0)
    viewCenter103 = NXOpen.Point3d(62.016776294371667, -53.721538700857124, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(-77.52097036796475, 67.151923376071252, 0.0)
    viewCenter104 = NXOpen.Point3d(77.520970367964622, -67.151923376071409, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(-97.148095031191474, 85.421196647502413, 0.0)
    viewCenter105 = NXOpen.Point3d(97.14809503119136, -85.421196647502555, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(-105.6963867477226, 112.02273982313362, 0.0)
    viewCenter106 = NXOpen.Point3d(105.69638674772246, -112.02273982313375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(-84.557109398178142, 89.61819185850689, 0.0)
    viewCenter107 = NXOpen.Point3d(84.557109398177971, -89.618191858507032, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(-69.818249745415443, 69.521991259932619, 0.0)
    viewCenter108 = NXOpen.Point3d(69.818249745415258, -69.521991259932761, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(-88.754104609182562, 86.408724932444656, 0.0)
    viewCenter109 = NXOpen.Point3d(88.754104609182448, -86.408724932444798, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(-111.55983593956708, 107.70230357651138, 0.0)
    viewCenter110 = NXOpen.Point3d(111.55983593956698, -107.7023035765115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(-139.44979492445893, 134.62787947063927, 0.0)
    viewCenter111 = NXOpen.Point3d(139.44979492445873, -134.62787947063939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(-176.7232013824833, 172.62457324673662, 0.0)
    viewCenter112 = NXOpen.Point3d(176.72320138248313, -172.62457324673673, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(-220.90400172810405, 215.78071655842081, 0.0)
    viewCenter113 = NXOpen.Point3d(220.90400172810394, -215.78071655842089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(-276.88342644978934, 270.47931998768524, 0.0)
    viewCenter114 = NXOpen.Point3d(276.88342644978923, -270.47931998768524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint114, viewCenter114)
    
    scaleAboutPoint115 = NXOpen.Point3d(-472.3028515801679, 343.74983215705123, 0.0)
    viewCenter115 = NXOpen.Point3d(472.30285158016761, -343.74983215705123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-377.84228126413421, 274.99986572564097, 0.0)
    viewCenter116 = NXOpen.Point3d(377.84228126413421, -274.99986572564097, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint116, viewCenter116)
    
    scaleAboutPoint117 = NXOpen.Point3d(-285.99986035466668, 201.91770962868983, 0.0)
    viewCenter117 = NXOpen.Point3d(285.99986035466668, -201.91770962868983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(-353.73270399503684, 244.10946984961009, 0.0)
    viewCenter118 = NXOpen.Point3d(353.73270399503684, -244.10946984961009, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(-439.34053890757377, 278.76698717393748, 0.0)
    viewCenter119 = NXOpen.Point3d(439.34053890757377, -278.76698717393748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(-445.57983380631458, -1.1772254525926802, 0.0)
    viewCenter120 = NXOpen.Point3d(445.57983380631458, 1.1772254525926802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(-574.63317404678287, 47.089018103705627, 0.0)
    viewCenter121 = NXOpen.Point3d(574.63317404678287, -47.089018103705627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(-718.29146755847842, 58.861272629632019, 0.0)
    viewCenter122 = NXOpen.Point3d(718.29146755847842, -58.861272629632019, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(-897.86433444809802, 75.875859249135004, 0.0)
    viewCenter123 = NXOpen.Point3d(897.86433444809802, -75.875859249135004, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(-1294.7755527172478, 554.69851648041913, 0.0)
    viewCenter124 = NXOpen.Point3d(1294.7755527172478, -554.69851648041913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(-1035.820442173798, 443.75881318433522, 0.0)
    viewCenter125 = NXOpen.Point3d(1035.820442173798, -443.75881318433522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(-764.27683680037819, 222.56918713079605, 0.0)
    viewCenter126 = NXOpen.Point3d(764.27683680037819, -222.56918713079605, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(-611.42146944030287, 178.05534970463682, 0.0)
    viewCenter127 = NXOpen.Point3d(611.42146944030242, -178.05534970463682, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(-489.13717555224247, 142.44427976370949, 0.0)
    viewCenter128 = NXOpen.Point3d(489.13717555224207, -142.44427976370949, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(-273.58719518253002, 32.962312672593868, 0.0)
    viewCenter129 = NXOpen.Point3d(273.5871951825294, -32.962312672594024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(-218.11633185636484, 26.36985013807509, 0.0)
    viewCenter130 = NXOpen.Point3d(218.1163318563641, -26.369850138075215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(-174.49306548509185, 21.095880110460023, 0.0)
    viewCenter131 = NXOpen.Point3d(174.49306548509125, -21.095880110460172, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(-139.59445238807356, 16.876704088368015, 0.0)
    viewCenter132 = NXOpen.Point3d(139.59445238807294, -16.876704088368175, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(-111.67556191045885, 14.658622979611042, 0.0)
    viewCenter133 = NXOpen.Point3d(111.67556191045831, -14.658622979611232, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(-69.58988382952262, 57.091478973222273, 0.0)
    viewCenter134 = NXOpen.Point3d(69.589883829522066, -57.091478973222422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(-56.412553277324854, 46.41382939228447, 0.0)
    viewCenter135 = NXOpen.Point3d(56.412553277324285, -46.413829392284633, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(-45.920065249813767, 38.118591798769771, 0.0)
    viewCenter136 = NXOpen.Point3d(45.920065249813121, -38.118591798769977, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(-58.066663154603098, 48.823398407543458, 0.0)
    viewCenter137 = NXOpen.Point3d(58.066663154602473, -48.823398407543671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-73.570857228196019, 61.029248009429359, 0.0)
    viewCenter138 = NXOpen.Point3d(73.570857228195393, -61.029248009429566, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(-101.8388543846672, 79.98979108032006, 0.0)
    viewCenter139 = NXOpen.Point3d(101.83885438466656, -79.989791080320273, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(-127.29856798083391, 99.987238850400104, 0.0)
    viewCenter140 = NXOpen.Point3d(127.2985679808333, -99.987238850400303, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(-159.12320997604232, 125.36980179930571, 0.0)
    viewCenter141 = NXOpen.Point3d(159.12320997604166, -125.3698017993059, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(-203.72592792387223, 17.841087179131854, 0.0)
    viewCenter142 = NXOpen.Point3d(203.72592792387158, -17.841087179132092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(-254.65740990484022, 22.301358973914869, 0.0)
    viewCenter143 = NXOpen.Point3d(254.65740990483957, -22.301358973915068, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(-339.41764249151038, 70.82188322797316, 0.0)
    viewCenter144 = NXOpen.Point3d(339.41764249150964, -70.821883227973274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(-428.0391745626842, 94.178036207411026, 0.0)
    viewCenter145 = NXOpen.Point3d(428.03917456268357, -94.178036207411253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint145, viewCenter145)
    
    scaleAboutPoint146 = NXOpen.Point3d(-540.93509546631844, 124.78589797481976, 0.0)
    viewCenter146 = NXOpen.Point3d(540.93509546631765, -124.78589797481995, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(-760.04618283012337, 437.04494927501742, 0.0)
    viewCenter147 = NXOpen.Point3d(760.04618283012292, -437.04494927501764, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(-608.03694626409879, 349.63595942001393, 0.0)
    viewCenter148 = NXOpen.Point3d(608.03694626409833, -349.6359594200141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(-486.42955701127897, 279.70876753601107, 0.0)
    viewCenter149 = NXOpen.Point3d(486.42955701127863, -279.70876753601129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(-336.40394533287304, 136.36979642833126, 0.0)
    viewCenter150 = NXOpen.Point3d(336.40394533287258, -136.36979642833157, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(-262.49302251729665, 101.2602245302084, 0.0)
    viewCenter151 = NXOpen.Point3d(262.49302251729625, -101.26022453020865, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(-134.77253693425388, 16.876704088367969, 0.0)
    viewCenter152 = NXOpen.Point3d(134.77253693425348, -16.876704088368207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(-107.81802954740323, 13.501363270694373, 0.0)
    viewCenter153 = NXOpen.Point3d(107.81802954740272, -13.501363270694597, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(-125.44695244656715, -30.243053726355718, 0.0)
    viewCenter154 = NXOpen.Point3d(125.4469524465667, 30.243053726355516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    scaleAboutPoint155 = NXOpen.Point3d(-100.85132609972487, -24.194442981084599, 0.0)
    viewCenter155 = NXOpen.Point3d(100.85132609972439, 24.194442981084396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(-84.433668362560411, -12.047845076295239, 0.0)
    viewCenter156 = NXOpen.Point3d(84.433668362559899, 12.047845076295044, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint156, viewCenter156)
    
    scaleAboutPoint157 = NXOpen.Point3d(-67.546934690048388, -9.6382760610362173, 0.0)
    viewCenter157 = NXOpen.Point3d(67.546934690047863, 9.6382760610360219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(-54.037547752038741, -7.7106208488289942, 0.0)
    viewCenter158 = NXOpen.Point3d(54.037547752038243, 7.7106208488287757, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(-4.095477303312661, -12.438116254504411, 0.0)
    viewCenter159 = NXOpen.Point3d(4.0954773033121432, 12.438116254504195, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(-3.6808734281625166, -10.274086272013413, 0.0)
    viewCenter160 = NXOpen.Point3d(3.6808734281619957, 10.2740862720132, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(-2.9446987425300568, -8.2192690176107543, 0.0)
    viewCenter161 = NXOpen.Point3d(2.9446987425295443, 8.2192690176105359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    point38 = NXOpen.Point3d(47.142857142857139, -113.53772894507422, 4.9999999999999947)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point38)
    
    point1_32 = NXOpen.Point3d(47.142857142857139, -114.85714285714286, 4.9999999999999947)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    point1_33 = NXOpen.Point3d(47.142857142857139, -108.85714285714286, 4.9999999999999947)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint162 = NXOpen.Point3d(-0.80251130565674733, 15.325377191891246, 0.0)
    viewCenter162 = NXOpen.Point3d(0.80251130565620032, -15.325377191891455, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(-0.64200904452545937, 12.260301753512975, 0.0)
    viewCenter163 = NXOpen.Point3d(0.64200904452489183, -12.260301753513186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(-0.51360723562042765, 9.8082414028103564, 0.0)
    viewCenter164 = NXOpen.Point3d(0.51360723561985866, -9.8082414028105731, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(-0.64200904452545937, 12.260301753512975, 0.0)
    viewCenter165 = NXOpen.Point3d(0.64200904452489183, -12.260301753513186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(-0.80251130565675588, 15.325377191891246, 0.0)
    viewCenter166 = NXOpen.Point3d(0.80251130565619178, -15.325377191891459, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(-1.0031391320708807, 19.156721489864076, 0.0)
    viewCenter167 = NXOpen.Point3d(1.0031391320703036, -19.156721489864292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint167, viewCenter167)
    
    scaleAboutPoint168 = NXOpen.Point3d(-0.28314410985893101, 27.667224449043601, 0.0)
    viewCenter168 = NXOpen.Point3d(0.28314410985834337, -27.667224449043822, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint168, viewCenter168)
    
    scaleAboutPoint169 = NXOpen.Point3d(-0.35393013732359696, 34.68515345768261, 0.0)
    viewCenter169 = NXOpen.Point3d(0.35393013732299594, -34.685153457682837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(0.69521991259902505, 47.527761297699229, 0.0)
    viewCenter170 = NXOpen.Point3d(-0.69521991259958849, -47.527761297699456, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(0.86902489074888589, 59.567706147714837, 0.0)
    viewCenter171 = NXOpen.Point3d(-0.86902489074943368, -59.567706147715043, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    scaleAboutPoint172 = NXOpen.Point3d(-16.689228015523877, -6.9126979945956828, 0.0)
    viewCenter172 = NXOpen.Point3d(16.689228015523291, 6.9126979945954545, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-20.614652948169173, -10.862811134364575, 0.0)
    viewCenter173 = NXOpen.Point3d(20.614652948168683, 10.86281113436433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-16.818841102922551, 71.595800658311077, 0.0)
    viewCenter174 = NXOpen.Point3d(16.81884110292199, -71.595800658311319, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-12.961308739866974, 58.017286740355509, 0.0)
    viewCenter175 = NXOpen.Point3d(12.961308739866404, -58.017286740355736, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-9.5790243639398387, 47.993874648191969, 0.0)
    viewCenter176 = NXOpen.Point3d(9.5790243639393164, -47.993874648192161, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint176, viewCenter176)
    
    point1_34 = NXOpen.Point3d(0.0, -60.0, 4.9999999999999893)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(47.142857142857139, -113.53772894507422, 4.9999999999999947)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(0.0, -60.0, 4.9999999999999893)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(47.142857142857139, -113.53772894507422, 4.9999999999999947)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(0.0, -60.0, 4.9999999999999893)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point39 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point39
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder17.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point40 = NXOpen.Point3d(20.019143503478528, -140.47753136918064, 4.999999999999992)
    sketchRapidDimensionBuilder17.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point40)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.TextCentered = True
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject15 = sketchRapidDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId84, None)
    
    theSession.SetUndoMarkName(markId83, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId83, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder17.Destroy()
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId85, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    expression41 = workPart.Expressions.FindObject("p14")
    expression41.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId85, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId86, None)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId85, "Edit Driving Value")
    
    scaleAboutPoint177 = NXOpen.Point3d(5.9251697096530833, -7.9002262795378968, 0.0)
    viewCenter177 = NXOpen.Point3d(-5.925169709653618, 7.9002262795377014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(7.6039677940548689, -9.8752828494223355, 0.0)
    viewCenter178 = NXOpen.Point3d(-7.6039677940553911, 9.8752828494221401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(9.5049597425686674, -12.344103561777899, 0.0)
    viewCenter179 = NXOpen.Point3d(-9.5049597425691559, 12.344103561777695, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(7.603967794054868, -9.8752828494223337, 0.0)
    viewCenter180 = NXOpen.Point3d(-7.6039677940553245, 9.8752828494221383, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(6.0831742352438702, -7.9002262795378968, 0.0)
    viewCenter181 = NXOpen.Point3d(-6.0831742352443534, 7.9002262795377014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(4.8665393881950534, -6.320181023630326, 0.0)
    viewCenter182 = NXOpen.Point3d(-4.8665393881955126, 6.3201810236301386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(3.8932315105560105, -5.0561448189042713, 0.0)
    viewCenter183 = NXOpen.Point3d(-3.8932315105564532, 5.0561448189041123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    scaleAboutPoint184 = NXOpen.Point3d(3.1145852084447547, -4.0449158551234294, 0.0)
    viewCenter184 = NXOpen.Point3d(-3.114585208445209, 4.0449158551232625, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(2.4916681667557614, -3.235932684098771, 0.0)
    viewCenter185 = NXOpen.Point3d(-2.4916681667562104, 3.235932684098584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint185, viewCenter185)
    
    point41 = NXOpen.Point3d(58.468697901731659, -108.85714285714286, 4.9999999999999964)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(line10, workPart.ModelingViews.WorkView, point41)
    
    point1_39 = NXOpen.Point3d(59.899999999999999, -108.85714285714286, 4.9999999999999964)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(54.0, -108.85714285714286, 4.9999999999999956)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line10, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint186 = NXOpen.Point3d(33.834912144935593, 1.6050226113128556, 0.0)
    viewCenter186 = NXOpen.Point3d(-33.83491214493602, -1.6050226113130395, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(27.192189531017817, 1.0769183972679417, 0.0)
    viewCenter187 = NXOpen.Point3d(-27.192189531018254, -1.0769183972681402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(21.753751624814218, 0.82839876712915328, 0.0)
    viewCenter188 = NXOpen.Point3d(-21.753751624814647, -0.8283987671293721, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(17.403001299851336, 0.50366645041448688, 0.0)
    viewCenter189 = NXOpen.Point3d(-17.403001299851759, -0.50366645041469915, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(21.753751624814218, 0.59644711233297121, 0.0)
    viewCenter190 = NXOpen.Point3d(-21.753751624814647, -0.59644711233317094, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(27.192189531017828, 0.74555889041623113, 0.0)
    viewCenter191 = NXOpen.Point3d(-27.192189531018254, -0.74555889041644308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(33.990236913772335, 0.93194861302031451, 0.0)
    viewCenter192 = NXOpen.Point3d(-33.990236913772762, -0.93194861302052823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(42.487796142215466, 1.1649357662754196, 0.0)
    viewCenter193 = NXOpen.Point3d(-42.487796142215892, -1.1649357662756332, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(53.109745177769391, 1.4561697078443081, 0.0)
    viewCenter194 = NXOpen.Point3d(-53.109745177769824, -1.4561697078445086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(73.566907115055741, -0.70786027464668511, 0.0)
    viewCenter195 = NXOpen.Point3d(-73.566907115056168, 0.70786027464647649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(52.267897065421835, -9.227464294500253, 0.0)
    viewCenter196 = NXOpen.Point3d(-52.267897065422254, 9.2274642945000434, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(63.280812499097536, -12.166348470488296, 0.0)
    viewCenter197 = NXOpen.Point3d(-63.280812499097955, 12.166348470488101, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(133.41507129569433, -12.442856390272148, 0.0)
    viewCenter198 = NXOpen.Point3d(-133.41507129569473, 12.442856390271935, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    scaleAboutPoint199 = NXOpen.Point3d(106.73205703655542, -9.9542851122177307, 0.0)
    viewCenter199 = NXOpen.Point3d(-106.73205703655584, 9.9542851122175229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(78.180639262305817, -3.4128977527604412, 0.0)
    viewCenter200 = NXOpen.Point3d(-78.180639262306244, 3.4128977527602116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(62.544511409844631, -2.7303182022083785, 0.0)
    viewCenter201 = NXOpen.Point3d(-62.544511409845036, 2.7303182022081529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(50.844592298900338, -1.3752713907420455, 0.0)
    viewCenter202 = NXOpen.Point3d(-50.844592298900736, 1.3752713907418386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(63.55574037362544, -1.7190892384275231, 0.0)
    viewCenter203 = NXOpen.Point3d(-63.555740373625873, 1.7190892384273229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(79.444675467031843, -2.1488615480343931, 0.0)
    viewCenter204 = NXOpen.Point3d(-79.444675467032269, 2.1488615480341737, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint204, viewCenter204)
    
    scaleAboutPoint205 = NXOpen.Point3d(63.555740373625426, -1.7190892384275223, 0.0)
    viewCenter205 = NXOpen.Point3d(-63.55574037362581, 1.719089238427322, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(50.844592298900331, -1.3752713907420315, 0.0)
    viewCenter206 = NXOpen.Point3d(-50.844592298900729, 1.3752713907418446, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(40.675673839120208, -1.1002171125936517, 0.0)
    viewCenter207 = NXOpen.Point3d(-40.675673839120591, 1.1002171125934541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(32.540539071296124, -0.88017369007492985, 0.0)
    viewCenter208 = NXOpen.Point3d(-32.540539071296514, 0.88017369007474611, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(26.032431257036858, -0.70413895205997112, 0.0)
    viewCenter209 = NXOpen.Point3d(-26.032431257037242, 0.70413895205977284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint209, viewCenter209)
    
    edge4 = extrude2.FindObject("EDGE * 130 * 170 {(54,-60,65)(56.95,-60,65)(59.9,-60,65) EXTRUDE(2)}")
    point1_41 = NXOpen.Point3d(59.899999999999984, -60.0, 64.999999999999986)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    point1_42 = NXOpen.Point3d(58.468697901731659, -108.85714285714286, 4.9999999999999964)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(59.899999999999984, -60.0, 64.999999999999986)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(58.468697901731659, -108.85714285714286, 4.9999999999999964)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line10, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(59.899999999999984, -60.0, 64.999999999999986)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge4, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point42 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point42
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point43 = NXOpen.Point3d(49.673100576514003, -75.672284128580543, 4.9999999999999947)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point43)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject16 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId88, None)
    
    theSession.SetUndoMarkName(markId87, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId87, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines97 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines100)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId89, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression42 = workPart.Expressions.FindObject("p15")
    expression42.SetFormula("50")
    
    theSession.SetUndoMarkVisibility(markId89, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId90, None)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId89, "Edit Driving Value")
    
    sketchRapidDimensionBuilder19.Destroy()
    
    theSession.UndoToMark(markId91, None)
    
    theSession.DeleteUndoMark(markId91, None)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    scaleAboutPoint210 = NXOpen.Point3d(7.8366523370425947, 2.6508760548135268, 0.0)
    viewCenter210 = NXOpen.Point3d(-7.8366523370429908, -2.6508760548137267, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(6.2958306301821727, 2.0676833227545339, 0.0)
    viewCenter211 = NXOpen.Point3d(-6.2958306301825688, -2.0676833227547262, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(5.036664504145695, 1.6541466582036057, 0.0)
    viewCenter212 = NXOpen.Point3d(-5.0366645041460938, -1.6541466582038036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(6.0143075931609618, 0.22055288776039472, 0.0)
    viewCenter213 = NXOpen.Point3d(-6.0143075931613543, -0.22055288776059359, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(7.5178844914512482, 0.27569110970051602, 0.0)
    viewCenter214 = NXOpen.Point3d(-7.5178844914516398, -0.27569110970072086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(9.3973556143141082, 0.34461388712566676, 0.0)
    viewCenter215 = NXOpen.Point3d(-9.397355614314499, -0.34461388712587904, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(11.74669451789268, 0.43076735890711082, 0.0)
    viewCenter216 = NXOpen.Point3d(-11.746694517893076, -0.43076735890731593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint216, viewCenter216)
    
    scaleAboutPoint217 = NXOpen.Point3d(14.641948209009424, 0.53845919863391922, 0.0)
    viewCenter217 = NXOpen.Point3d(-14.641948209009835, -0.53845919863411751, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(18.302435261261842, 0.62129907534684448, 0.0)
    viewCenter218 = NXOpen.Point3d(-18.302435261262247, -0.62129907534703677, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(22.878044076577346, 0.77662384418357688, 0.0)
    viewCenter219 = NXOpen.Point3d(-22.878044076577751, -0.77662384418378527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(28.597555095721738, 0.97077980522949125, 0.0)
    viewCenter220 = NXOpen.Point3d(-28.597555095722146, -0.97077980522970497, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(50.409763844474291, -20.123456379238689, 0.0)
    viewCenter221 = NXOpen.Point3d(-50.409763844474739, 20.123456379238455, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(63.012204805592923, -25.407127714993536, 0.0)
    viewCenter222 = NXOpen.Point3d(-63.012204805593363, 25.407127714993305, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(83.663396300304612, -34.286982053193974, 0.0)
    viewCenter223 = NXOpen.Point3d(-83.663396300305024, 34.286982053193739, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(105.17176234634613, -43.846255851434663, 0.0)
    viewCenter224 = NXOpen.Point3d(-105.17176234634658, 43.846255851434449, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(132.94599536034605, -57.029758455413294, 0.0)
    viewCenter225 = NXOpen.Point3d(-132.94599536034653, 57.029758455413067, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(167.10830196756595, -74.0646213706666, 0.0)
    viewCenter226 = NXOpen.Point3d(-167.1083019675664, 74.064621370666373, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(238.20262341867954, -118.04049030949979, 0.0)
    viewCenter227 = NXOpen.Point3d(-238.20262341868016, 118.04049030949956, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(190.56209873494365, -95.3582000147332, 0.0)
    viewCenter228 = NXOpen.Point3d(-190.56209873494416, 95.358200014732958, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(152.44967898795485, -80.236673151555451, 0.0)
    viewCenter229 = NXOpen.Point3d(-152.44967898795542, 80.236673151555209, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(121.95974319036382, -64.979361149198169, 0.0)
    viewCenter230 = NXOpen.Point3d(-121.95974319036441, 64.979361149197928, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    scaleAboutPoint231 = NXOpen.Point3d(89.03555017039028, -45.979316946909876, 0.0)
    viewCenter231 = NXOpen.Point3d(-89.03555017039082, 45.979316946909641, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(111.29443771298786, -57.474146183637302, 0.0)
    viewCenter232 = NXOpen.Point3d(-111.29443771298844, 57.474146183637068, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(139.11804714123494, -71.84268272954661, 0.0)
    viewCenter233 = NXOpen.Point3d(-139.11804714123545, 71.842682729546382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(191.79650909112141, -106.77649580937759, 0.0)
    viewCenter234 = NXOpen.Point3d(-191.79650909112192, 106.77649580937739, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(245.14618167217967, -133.47061976172199, 0.0)
    viewCenter235 = NXOpen.Point3d(-245.14618167218018, 133.47061976172176, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint235, viewCenter235)
    
    scaleAboutPoint236 = NXOpen.Point3d(343.07928453925228, -169.24923242906218, 0.0)
    viewCenter236 = NXOpen.Point3d(-343.07928453925274, 169.24923242906192, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(274.84918086770733, -135.39938594324977, 0.0)
    viewCenter237 = NXOpen.Point3d(-274.84918086770784, 135.39938594324954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(220.18794728321035, -108.62811134364429, 0.0)
    viewCenter238 = NXOpen.Point3d(-220.18794728321078, 108.62811134364406, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(171.70648054432826, -86.408724932444343, 0.0)
    viewCenter239 = NXOpen.Point3d(-171.70648054432874, 86.40872493244413, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(136.1801504935319, -68.731968631978617, 0.0)
    viewCenter240 = NXOpen.Point3d(-136.18015049353235, 68.73196863197839, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(108.3121022924625, -54.353556803219917, 0.0)
    viewCenter241 = NXOpen.Point3d(-108.31210229246294, 54.353556803219689, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint241, viewCenter241)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines105 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines108)
    
    theSession.SetUndoMarkName(markId92, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint242 = NXOpen.Point3d(-3.9817140448872572, -19.339753932308557, 0.0)
    viewCenter242 = NXOpen.Point3d(3.9817140448867985, 19.33975393230833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(-3.1853712359098396, -15.471803145846874, 0.0)
    viewCenter243 = NXOpen.Point3d(3.1853712359093973, 15.471803145846639, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint243, viewCenter243)
    
    point44 = NXOpen.Point3d(105.51831170261713, -64.671428571428507, 5.0000000000000018)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(line14, workPart.ModelingViews.WorkView, point44)
    
    point1_46 = NXOpen.Point3d(107.04285714285709, -64.671428571428507, 5.0000000000000018)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line14, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(101.04285714285709, -64.671428571428507, 5.0000000000000009)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line14, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint244 = NXOpen.Point3d(53.999626665896272, -9.7886963693985525, 0.0)
    viewCenter244 = NXOpen.Point3d(-53.999626665896699, 9.7886963693983713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint244, viewCenter244)
    
    scaleAboutPoint245 = NXOpen.Point3d(67.398410435992304, -12.438116254504331, 0.0)
    viewCenter245 = NXOpen.Point3d(-67.398410435992773, 12.43811625450418, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(84.248013044990458, -15.547645318130392, 0.0)
    viewCenter246 = NXOpen.Point3d(-84.248013044990913, 15.547645318130236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint246, viewCenter246)
    
    point1_48 = NXOpen.Point3d(120.0, 0.0, 5.0000000000000036)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    point1_49 = NXOpen.Point3d(105.51831170261713, -64.671428571428507, 5.0000000000000018)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line14, workPart.ModelingViews.WorkView, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(120.0, 0.0, 5.0000000000000036)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    point1_51 = NXOpen.Point3d(105.51831170261713, -64.671428571428507, 5.0000000000000018)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line14, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(120.0, 0.0, 5.0000000000000036)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line3, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point45 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point45
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder20.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point46 = NXOpen.Point3d(108.10705784989602, -30.589650954103831, 5.0000000000000018)
    sketchRapidDimensionBuilder20.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point46)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.TextCentered = True
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject17 = sketchRapidDimensionBuilder20.Commit()
    
    theSession.DeleteUndoMark(markId93, None)
    
    theSession.SetUndoMarkName(markId92, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId92, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId94, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    expression43 = workPart.Expressions.FindObject("p16")
    expression43.SetFormula("54")
    
    theSession.SetUndoMarkVisibility(markId94, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId95, None)
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId94, "Edit Driving Value")
    
    scaleAboutPoint247 = NXOpen.Point3d(57.276640526648549, -19.434556647662976, 0.0)
    viewCenter247 = NXOpen.Point3d(-57.276640526649018, 19.43455664766282, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint247, viewCenter247)
    
    scaleAboutPoint248 = NXOpen.Point3d(45.821312421318787, -15.547645318130401, 0.0)
    viewCenter248 = NXOpen.Point3d(-45.821312421319249, 15.547645318130224, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(36.657049937055007, -12.438116254504356, 0.0)
    viewCenter249 = NXOpen.Point3d(-36.65704993705544, 12.438116254504155, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint249, viewCenter249)
    
    point47 = NXOpen.Point3d(101.04285714285707, -55.484844006183209, 5.0000000000000009)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(line13, workPart.ModelingViews.WorkView, point47)
    
    point1_53 = NXOpen.Point3d(101.04285714285707, -54.000000000000014, 5.0000000000000009)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line13, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    point1_54 = NXOpen.Point3d(101.04285714285707, -59.90000000000002, 5.0000000000000009)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line13, workPart.ModelingViews.WorkView, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint250 = NXOpen.Point3d(23.986351020881155, 20.952664129538761, 0.0)
    viewCenter250 = NXOpen.Point3d(-23.986351020881571, -20.952664129538974, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(19.189080816704891, 16.762131303630976, 0.0)
    viewCenter251 = NXOpen.Point3d(-19.1890808167053, -16.762131303631207, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(15.351264653363868, 13.461479965850335, 0.0)
    viewCenter252 = NXOpen.Point3d(-15.351264653364279, -13.461479965850561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(12.281011722691062, 10.769183972680247, 0.0)
    viewCenter253 = NXOpen.Point3d(-12.281011722691462, -10.769183972680477, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(9.824809378152807, 8.847298832940373, 0.0)
    viewCenter254 = NXOpen.Point3d(-9.8248093781532067, -8.847298832940595, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(12.281011722691062, 11.141963417888414, 0.0)
    viewCenter255 = NXOpen.Point3d(-12.281011722691458, -11.141963417888649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint255, viewCenter255)
    
    scaleAboutPoint256 = NXOpen.Point3d(15.351264653363883, 14.031004118251706, 0.0)
    viewCenter256 = NXOpen.Point3d(-15.351264653364289, -14.031004118251934, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint256, viewCenter256)
    
    scaleAboutPoint257 = NXOpen.Point3d(19.189080816704898, 17.797629762542552, 0.0)
    viewCenter257 = NXOpen.Point3d(-19.189080816705303, -17.797629762542783, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint257, viewCenter257)
    
    scaleAboutPoint258 = NXOpen.Point3d(23.986351020881173, 22.732427105793025, 0.0)
    viewCenter258 = NXOpen.Point3d(-23.986351020881575, -22.732427105793253, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(33.926731734846769, 38.426700623671564, 0.0)
    viewCenter259 = NXOpen.Point3d(-33.926731734847166, -38.426700623671799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint259, viewCenter259)
    
    scaleAboutPoint260 = NXOpen.Point3d(42.408414668558514, 48.033375779589477, 0.0)
    viewCenter260 = NXOpen.Point3d(-42.408414668558891, -48.033375779589704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint260, viewCenter260)
    
    scaleAboutPoint261 = NXOpen.Point3d(58.066663154602338, 58.303669942988556, 0.0)
    viewCenter261 = NXOpen.Point3d(-58.066663154602708, -58.30366994298879, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(72.780834600241405, 72.682081771747278, 0.0)
    viewCenter262 = NXOpen.Point3d(-72.780834600241761, -72.682081771747505, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(90.729161179066239, 82.705493863910803, 0.0)
    viewCenter263 = NXOpen.Point3d(-90.729161179066651, -82.70549386391103, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(113.41145147383283, 103.07326474084407, 0.0)
    viewCenter264 = NXOpen.Point3d(-113.41145147383324, -103.07326474084432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint264, viewCenter264)
    
    scaleAboutPoint265 = NXOpen.Point3d(133.66349637987452, 147.35773626872174, 0.0)
    viewCenter265 = NXOpen.Point3d(-133.66349637987489, -147.35773626872199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint265, viewCenter265)
    
    scaleAboutPoint266 = NXOpen.Point3d(106.93079710389955, 117.88618901497733, 0.0)
    viewCenter266 = NXOpen.Point3d(-106.93079710389991, -117.88618901497765, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint266, viewCenter266)
    
    scaleAboutPoint267 = NXOpen.Point3d(85.544637683119703, 94.308951211981878, 0.0)
    viewCenter267 = NXOpen.Point3d(-85.544637683120015, -94.308951211982162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint267, viewCenter267)
    
    scaleAboutPoint268 = NXOpen.Point3d(78.113487338929488, 76.829700568504578, 0.0)
    viewCenter268 = NXOpen.Point3d(-78.113487338929758, -76.829700568504876, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint268, viewCenter268)
    
    scaleAboutPoint269 = NXOpen.Point3d(62.806798922325029, 61.147751403622138, 0.0)
    viewCenter269 = NXOpen.Point3d(-62.806798922325321, -61.147751403622401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint269, viewCenter269)
    
    scaleAboutPoint270 = NXOpen.Point3d(44.051661734702435, 39.817140448870198, 0.0)
    viewCenter270 = NXOpen.Point3d(-44.051661734702705, -39.817140448870447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint270, viewCenter270)
    
    scaleAboutPoint271 = NXOpen.Point3d(35.241329387761901, 31.853712359096122, 0.0)
    viewCenter271 = NXOpen.Point3d(-35.241329387762164, -31.853712359096363, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint271, viewCenter271)
    
    scaleAboutPoint272 = NXOpen.Point3d(28.193063510209491, 25.482969887276877, 0.0)
    viewCenter272 = NXOpen.Point3d(-28.193063510209758, -25.482969887277111, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint272, viewCenter272)
    
    scaleAboutPoint273 = NXOpen.Point3d(22.295576193439672, 23.298715325510276, 0.0)
    viewCenter273 = NXOpen.Point3d(-22.295576193439949, -23.298715325510521, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint273, viewCenter273)
    
    edge5 = extrude2.FindObject("EDGE * 130 * 140 {(59.9,-60,65)(59.9,-57,65)(59.9,-54,65) EXTRUDE(2)}")
    point1_55 = NXOpen.Point3d(59.899999999999984, -57.0, 64.999999999999986)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge5, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(101.04285714285707, -55.484844006183209, 5.0000000000000009)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(59.899999999999984, -57.0, 64.999999999999986)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge5, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    point1_58 = NXOpen.Point3d(101.04285714285707, -55.484844006183209, 5.0000000000000009)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(59.899999999999984, -57.0, 64.999999999999986)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge5, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point48 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point48
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point49 = NXOpen.Point3d(68.636919134704712, -69.179594150895213, 4.9999999999999973)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point49)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = False
    
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject18 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId97, None)
    
    theSession.SetUndoMarkName(markId96, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId96, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines113 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines116)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId98, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    expression44 = workPart.Expressions.FindObject("p17")
    expression44.SetFormula("50")
    
    theSession.SetUndoMarkVisibility(markId98, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId99, None)
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId98, "Edit Driving Value")
    
    sketchRapidDimensionBuilder22.Destroy()
    
    theSession.UndoToMark(markId100, None)
    
    theSession.DeleteUndoMark(markId100, None)
    
    sketchRapidDimensionBuilder22.Destroy()
    
    scaleAboutPoint274 = NXOpen.Point3d(-3.287707607044386, 1.3461479965849226, 0.0)
    viewCenter274 = NXOpen.Point3d(3.2877076070440912, -1.3461479965851619, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint274, viewCenter274)
    
    scaleAboutPoint275 = NXOpen.Point3d(-4.1096345088054402, 1.6826849957311909, 0.0)
    viewCenter275 = NXOpen.Point3d(4.1096345088051569, -1.6826849957314152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint275, viewCenter275)
    
    scaleAboutPoint276 = NXOpen.Point3d(-5.1370431360067723, 2.1033562446640151, 0.0)
    viewCenter276 = NXOpen.Point3d(5.1370431360064917, -2.1033562446642353, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint276, viewCenter276)
    
    scaleAboutPoint277 = NXOpen.Point3d(-6.421303920008433, 2.6291953058300437, 0.0)
    viewCenter277 = NXOpen.Point3d(6.4213039200081239, -2.6291953058302608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint277, viewCenter277)
    
    scaleAboutPoint278 = NXOpen.Point3d(-7.9002262795378915, 3.286494132287586, 0.0)
    viewCenter278 = NXOpen.Point3d(7.9002262795375886, -3.2864941322878156, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint278, viewCenter278)
    
    scaleAboutPoint279 = NXOpen.Point3d(-9.875282849422339, 4.1081176653595088, 0.0)
    viewCenter279 = NXOpen.Point3d(9.8752828494220122, -4.1081176653597442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint279, viewCenter279)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch7 = theSession.ActiveSketch
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId102, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies15)
    
    targetBodies16 = []
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies16)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature6
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section5.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(59.900000000000006, -113.45197318959728, 4.9999999999999929)
    section5.AddToSection(rules3, line11, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId104, None)
    
    direction7 = workPart.Directions.CreateDirection(sketch7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction7
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies18)
    
    expression46 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression47 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId103, None)
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder5.ParentFeatureInternal = False
    
    feature7 = extrudeBuilder5.CommitFeature()
    
    theSession.DeleteUndoMark(markId105, None)
    
    theSession.SetUndoMarkName(markId102, "Extrude")
    
    expression48 = extrudeBuilder5.Limits.StartExtend.Value
    expression49 = extrudeBuilder5.Limits.EndExtend.Value
    extrudeBuilder5.Destroy()
    
    workPart.Expressions.Delete(expression45)
    
    workPart.Expressions.Delete(expression46)
    
    workPart.Expressions.Delete(expression47)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId106, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression50)
    
    theSession.UndoToMark(markId106, None)
    
    theSession.DeleteUndoMark(markId106, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin10, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane10
    
    expression51 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression52 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId107, "Create Sketch Dialog")
    
    scalar6 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge6 = extrude2.FindObject("EDGE * 140 * 150 {(59.9,-54,65)(59.9,-54,35)(59.9,-54,5) EXTRUDE(2)}")
    point50 = workPart.Points.CreatePoint(edge6, scalar6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction8 = workPart.Directions.CreateDirection(edge3, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude2.FindObject("FACE 140 {(59.9,-57,35) EXTRUDE(2)}")
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction8, point50, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin11, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom11 = [NXOpen.NXObject.Null] * 1 
    geom11[0] = face2
    plane11.SetGeometry(geom11)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin12, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    scalar7 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point51 = workPart.Points.CreatePoint(edge6, scalar7, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face2
    plane12.SetGeometry(geom12)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId108, None)
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject19 = sketchInPlaceBuilder5.Commit()
    
    sketch8 = nXObject19
    feature8 = sketch8.Feature
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId110)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId109, None)
    
    theSession.SetUndoMarkName(markId107, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression52)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point51)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression51)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression54)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression53)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint280 = NXOpen.Point3d(60.94901133627814, -17.281744986488995, 0.0)
    viewCenter280 = NXOpen.Point3d(-60.94901133627814, 17.281744986488995, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint280, viewCenter280)
    
    scaleAboutPoint281 = NXOpen.Point3d(76.186264170347613, -21.602181233111235, 0.0)
    viewCenter281 = NXOpen.Point3d(-76.186264170347613, 21.602181233111235, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint281, viewCenter281)
    
    scaleAboutPoint282 = NXOpen.Point3d(95.232830212934559, -27.002726541389041, 0.0)
    viewCenter282 = NXOpen.Point3d(-95.232830212934559, 27.002726541389041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint282, viewCenter282)
    
    scaleAboutPoint283 = NXOpen.Point3d(119.04103776616815, -33.753408176736251, 0.0)
    viewCenter283 = NXOpen.Point3d(-119.04103776616815, 33.753408176736301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint283, viewCenter283)
    
    scaleAboutPoint284 = NXOpen.Point3d(148.80129720771004, -42.191760220920372, 0.0)
    viewCenter284 = NXOpen.Point3d(-148.80129720771029, 42.191760220920372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint284, viewCenter284)
    
    scaleAboutPoint285 = NXOpen.Point3d(186.00162150963754, -52.739700276150465, 0.0)
    viewCenter285 = NXOpen.Point3d(-186.00162150963786, 52.739700276150465, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint285, viewCenter285)
    
    scaleAboutPoint286 = NXOpen.Point3d(223.08422326630566, -31.785087220001358, 0.0)
    viewCenter286 = NXOpen.Point3d(-223.08422326630603, 31.785087220001358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint286, viewCenter286)
    
    scaleAboutPoint287 = NXOpen.Point3d(178.46737861304453, -22.602728689778726, 0.0)
    viewCenter287 = NXOpen.Point3d(-178.46737861304484, 22.602728689778726, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint287, viewCenter287)
    
    scaleAboutPoint288 = NXOpen.Point3d(142.77390289043564, -17.328758662163725, 0.0)
    viewCenter288 = NXOpen.Point3d(-142.77390289043586, 17.328758662163725, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint288, viewCenter288)
    
    scaleAboutPoint289 = NXOpen.Point3d(114.2191223123485, -12.657528066276125, 0.0)
    viewCenter289 = NXOpen.Point3d(-114.2191223123487, 12.657528066276125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint289, viewCenter289)
    
    scaleAboutPoint290 = NXOpen.Point3d(91.857489395260686, -7.7150647261111649, 0.0)
    viewCenter290 = NXOpen.Point3d(-91.857489395260913, 7.7150647261111649, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint290, viewCenter290)
    
    scaleAboutPoint291 = NXOpen.Point3d(107.04652307479208, 8.8723244350278119, 0.0)
    viewCenter291 = NXOpen.Point3d(-107.04652307479233, -8.8723244350278119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint291, viewCenter291)
    
    scaleAboutPoint292 = NXOpen.Point3d(84.711410692700241, 5.5548466028000325, 0.0)
    viewCenter292 = NXOpen.Point3d(-84.711410692700497, -5.5548466028000325, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint292, viewCenter292)
    
    scaleAboutPoint293 = NXOpen.Point3d(67.02848234045355, 3.2094669260622428, 0.0)
    viewCenter293 = NXOpen.Point3d(-67.028482340453792, -3.2094669260622428, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint293, viewCenter293)
    
    scaleAboutPoint294 = NXOpen.Point3d(49.277661418617036, -1.1850339419306795, 0.0)
    viewCenter294 = NXOpen.Point3d(-49.277661418617242, 1.1850339419306795, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint294, viewCenter294)
    
    scaleAboutPoint295 = NXOpen.Point3d(7.1892059143793023, -21.646620005933652, 0.0)
    viewCenter295 = NXOpen.Point3d(-7.1892059143795368, 21.646620005933613, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint295, viewCenter295)
    
    scaleAboutPoint296 = NXOpen.Point3d(1.2008343944896318, -20.22457927561684, 0.0)
    viewCenter296 = NXOpen.Point3d(-1.2008343944898614, 20.224579275616811, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint296, viewCenter296)
    
    scaleAboutPoint297 = NXOpen.Point3d(-3.0842483395316833, -17.999875555298971, 0.0)
    viewCenter297 = NXOpen.Point3d(3.0842483395314497, 17.999875555298946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint297, viewCenter297)
    
    scaleAboutPoint298 = NXOpen.Point3d(-8.8583657227202863, -16.422358371800872, 0.0)
    viewCenter298 = NXOpen.Point3d(8.8583657227200447, 16.42235837180084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint298, viewCenter298)
    
    scaleAboutPoint299 = NXOpen.Point3d(-9.7401573791371785, -13.72035458057846, 0.0)
    viewCenter299 = NXOpen.Point3d(9.7401573791369387, 13.720354580578434, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint299, viewCenter299)
    
    scaleAboutPoint300 = NXOpen.Point3d(-8.8276243622213464, -10.976283664462771, 0.0)
    viewCenter300 = NXOpen.Point3d(8.8276243622211155, 10.976283664462738, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint300, viewCenter300)
    
    scaleAboutPoint301 = NXOpen.Point3d(-12.717215448507964, -14.108666502670292, 0.0)
    viewCenter301 = NXOpen.Point3d(12.71721544850773, 14.108666502670266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint301, viewCenter301)
    
    scaleAboutPoint302 = NXOpen.Point3d(-23.824554386676724, -20.305477592719289, 0.0)
    viewCenter302 = NXOpen.Point3d(23.824554386676475, 20.305477592719264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint302, viewCenter302)
    
    scaleAboutPoint303 = NXOpen.Point3d(-33.522240149334976, -26.797567540192283, 0.0)
    viewCenter303 = NXOpen.Point3d(33.522240149334742, 26.797567540192251, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint303, viewCenter303)
    
    scaleAboutPoint304 = NXOpen.Point3d(-44.304468975648177, -34.634592009493808, 0.0)
    viewCenter304 = NXOpen.Point3d(44.30446897564795, 34.63459200949378, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint304, viewCenter304)
    
    scaleAboutPoint305 = NXOpen.Point3d(-82.24135556998877, -50.719452714632794, 0.0)
    viewCenter305 = NXOpen.Point3d(82.241355569988571, 50.719452714632766, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint305, viewCenter305)
    
    scaleAboutPoint306 = NXOpen.Point3d(-55.301583956764851, -42.724423719740528, 0.0)
    viewCenter306 = NXOpen.Point3d(55.301583956764595, 42.724423719740507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint306, viewCenter306)
    
    scaleAboutPoint307 = NXOpen.Point3d(-44.34239006178997, -34.280661872170512, 0.0)
    viewCenter307 = NXOpen.Point3d(44.342390061789736, 34.280661872170484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint307, viewCenter307)
    
    scaleAboutPoint308 = NXOpen.Point3d(-36.040200269149274, -23.86500354522784, 0.0)
    viewCenter308 = NXOpen.Point3d(36.040200269149047, 23.865003545227818, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint308, viewCenter308)
    
    scaleAboutPoint309 = NXOpen.Point3d(-28.443848293227589, -17.668192455178851, 0.0)
    viewCenter309 = NXOpen.Point3d(28.443848293227365, 17.668192455178833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint309, viewCenter309)
    
    scaleAboutPoint310 = NXOpen.Point3d(-21.25360586916031, -3.5724696832449658, 0.0)
    viewCenter310 = NXOpen.Point3d(21.253605869160079, 3.5724696832449401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint310, viewCenter310)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId112, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(59.899999999999984, -57.399999999999999, 60.399999999999984)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 2.1406501494533545, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = arc1
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(59.899999999999984, -57.399999999999999, 60.869643395537835)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension9 = sketchDimensionalConstraint9.AssociatedDimension
    
    expression55 = sketchDimensionalConstraint9.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines121 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines124)
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    point1_60 = NXOpen.Point3d(59.899999999999984, -55.388803647084295, 61.133125018242609)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc1, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    point1_61 = NXOpen.Point3d(59.899999999999984, -55.388803647084295, 61.133125018242609)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point52 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point52
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point53 = NXOpen.Point3d(59.899999999999984, -49.412488816412271, 63.498409784946183)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point53)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject20 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId114, None)
    
    theSession.SetUndoMarkName(markId113, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines125 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines128)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId115, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    expression56 = workPart.Expressions.FindObject("p20")
    expression56.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId115, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.70072169447300547)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId116, None)
    
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId115, "Edit Driving Value")
    
    scaleAboutPoint311 = NXOpen.Point3d(-11.204093325423417, -12.425981506938985, 0.0)
    viewCenter311 = NXOpen.Point3d(11.204093325423187, 12.425981506938959, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint311, viewCenter311)
    
    scaleAboutPoint312 = NXOpen.Point3d(-14.231890819280874, -9.9739211562363632, 0.0)
    viewCenter312 = NXOpen.Point3d(14.231890819280656, 9.9739211562363295, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint312, viewCenter312)
    
    scaleAboutPoint313 = NXOpen.Point3d(-11.438530176521001, -7.9261194038928178, 0.0)
    viewCenter313 = NXOpen.Point3d(11.438530176520773, 7.9261194038927894, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint313, viewCenter313)
    
    point1_63 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 61.776680205424157)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 61.776680205424157)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    point1_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point54 = NXOpen.Point3d(59.899999999999984, -56.617901292902616, 64.999999999999986)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(perpendicularDimension1, workPart.ModelingViews.WorkView, point54)
    
    line17 = theSession.ActiveSketch.FindObject("Curve DATUM5")
    point1_66 = NXOpen.Point3d(59.899999999999984, -39.712499999999999, 64.999999999999986)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, NXOpen.View.Null, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 61.776680205424157)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    point1_68 = NXOpen.Point3d(59.899999999999984, -39.712499999999999, 64.999999999999986)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line17, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 61.776680205424157)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point55 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point55
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point56 = NXOpen.Point3d(59.899999999999984, -61.431892208444197, 63.787686634427736)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point56)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = False
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId118, None)
    
    theSession.SetUndoMarkName(markId117, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId117, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines129 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines129)
    
    lines130 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines130)
    
    lines131 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines131)
    
    lines132 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines132)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId119, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression57 = workPart.Expressions.FindObject("p21")
    expression57.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId119, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId120, None)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId119, "Edit Driving Value")
    
    point1_70 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 60.999999999999986)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    point1_71 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 60.999999999999986)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    point57 = NXOpen.Point3d(59.899999999999984, -54.0, 61.158017588052601)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(edge6, workPart.ModelingViews.WorkView, point57)
    
    point1_73 = NXOpen.Point3d(59.899999999999984, -54.0, 61.158017588052601)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    point1_74 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 60.999999999999986)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(59.899999999999984, -54.0, 61.158017588052601)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(59.899999999999984, -56.382453761208218, 60.999999999999986)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point58 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point58
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder25.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point59 = NXOpen.Point3d(59.899999999999984, -55.112203693768464, 67.647362170236406)
    sketchRapidDimensionBuilder25.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point59)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.TextCentered = True
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject22 = sketchRapidDimensionBuilder25.Commit()
    
    theSession.DeleteUndoMark(markId122, None)
    
    theSession.SetUndoMarkName(markId121, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId121, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines133 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines133)
    
    lines134 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines134)
    
    lines135 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines135)
    
    lines136 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines136)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId123, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    expression58 = workPart.Expressions.FindObject("p22")
    expression58.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId123, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId124, None)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId123, "Edit Driving Value")
    
    sketchRapidDimensionBuilder26.Destroy()
    
    theSession.UndoToMark(markId125, None)
    
    theSession.DeleteUndoMark(markId125, None)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch9 = theSession.ActiveSketch
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("20")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId127, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint314 = NXOpen.Point3d(-3.8575323630555514, 26.84842524686681, 0.0)
    viewCenter314 = NXOpen.Point3d(3.8575323630555514, -26.84842524686681, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint314, viewCenter314)
    
    scaleAboutPoint315 = NXOpen.Point3d(-4.8219154538194697, 33.560531558583499, 0.0)
    viewCenter315 = NXOpen.Point3d(4.8219154538194697, -33.560531558583499, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint315, viewCenter315)
    
    scaleAboutPoint316 = NXOpen.Point3d(-6.0273943172742968, 41.950664448229375, 0.0)
    viewCenter316 = NXOpen.Point3d(6.0273943172742968, -41.950664448229375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint316, viewCenter316)
    
    scaleAboutPoint317 = NXOpen.Point3d(-7.5342428965929207, 52.438330560286715, 0.0)
    viewCenter317 = NXOpen.Point3d(7.5342428965929207, -52.438330560286715, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint317, viewCenter317)
    
    scaleAboutPoint318 = NXOpen.Point3d(-6.0273943172742968, 41.950664448229375, 0.0)
    viewCenter318 = NXOpen.Point3d(6.0273943172742968, -41.950664448229375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint318, viewCenter318)
    
    scaleAboutPoint319 = NXOpen.Point3d(-2.8931492722916494, 28.931492722916797, 0.0)
    viewCenter319 = NXOpen.Point3d(2.8931492722916494, -28.931492722916797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint319, viewCenter319)
    
    scaleAboutPoint320 = NXOpen.Point3d(-0.77150647261108951, 19.441963109800088, 0.0)
    viewCenter320 = NXOpen.Point3d(0.77150647261111494, -19.441963109800088, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint320, viewCenter320)
    
    scaleAboutPoint321 = NXOpen.Point3d(-0.37032310685330661, 14.319160131662287, 0.0)
    viewCenter321 = NXOpen.Point3d(0.37032310685334741, -14.319160131662287, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint321, viewCenter321)
    
    scaleAboutPoint322 = NXOpen.Point3d(-0.29625848548266165, 11.257822448341372, 0.0)
    viewCenter322 = NXOpen.Point3d(0.29625848548269429, -11.257822448341404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint322, viewCenter322)
    
    scaleAboutPoint323 = NXOpen.Point3d(-0.23700678838611627, 9.0062579586731086, 0.0)
    viewCenter323 = NXOpen.Point3d(0.23700678838616843, -9.0062579586731228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint323, viewCenter323)
    
    scaleAboutPoint324 = NXOpen.Point3d(-0.18960543070889302, 7.2050063669384876, 0.0)
    viewCenter324 = NXOpen.Point3d(0.18960543070895564, -7.2050063669384983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint324, viewCenter324)
    
    scaleAboutPoint325 = NXOpen.Point3d(-0.15168434456710608, 5.7640050935507743, 0.0)
    viewCenter325 = NXOpen.Point3d(0.15168434456715615, -5.7640050935508071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint325, viewCenter325)
    
    scaleAboutPoint326 = NXOpen.Point3d(-0.12134747565367152, 4.6112040748406198, 0.0)
    viewCenter326 = NXOpen.Point3d(0.12134747565373162, -4.6112040748406464, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint326, viewCenter326)
    
    scaleAboutPoint327 = NXOpen.Point3d(-5.2745702750808308, 11.390483048027365, 0.0)
    viewCenter327 = NXOpen.Point3d(5.2745702750808841, -11.390483048027397, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint327, viewCenter327)
    
    scaleAboutPoint328 = NXOpen.Point3d(-4.2196562200646603, 9.1123864384219004, 0.0)
    viewCenter328 = NXOpen.Point3d(4.2196562200647163, -9.1123864384219218, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint328, viewCenter328)
    
    scaleAboutPoint329 = NXOpen.Point3d(-3.3757249760517221, 7.2899091507375147, 0.0)
    viewCenter329 = NXOpen.Point3d(3.3757249760517802, -7.2899091507375422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint329, viewCenter329)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature8
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section7.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint4 = NXOpen.Point3d(59.899999999999984, -55.875273046967706, 60.010490576480883)
    section7.AddToSection(rules4, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId129, None)
    
    direction9 = workPart.Directions.CreateDirection(sketch9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction9
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies24)
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId128, None)
    
    direction10 = extrudeBuilder7.Direction
    
    success1 = direction10.ReverseDirection()
    
    extrudeBuilder7.Direction = direction10
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("15.5")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body1
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies27)
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    feature9 = extrudeBuilder7.CommitFeature()
    
    theSession.DeleteUndoMark(markId130, None)
    
    theSession.SetUndoMarkName(markId127, "Extrude")
    
    expression61 = extrudeBuilder7.Limits.StartExtend.Value
    expression62 = extrudeBuilder7.Limits.EndExtend.Value
    extrudeBuilder7.Destroy()
    
    workPart.Expressions.Delete(expression59)
    
    workPart.Expressions.Delete(expression60)
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("15.5")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies29)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId131, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder8.Destroy()
    
    section8.Destroy()
    
    workPart.Expressions.Delete(expression63)
    
    theSession.UndoToMark(markId131, None)
    
    theSession.DeleteUndoMark(markId131, None)
    
    scaleAboutPoint330 = NXOpen.Point3d(0.51360723562017196, 1.3917099287771504, 0.0)
    viewCenter330 = NXOpen.Point3d(-0.51360723562011457, -1.3917099287771777, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint330, viewCenter330)
    
    scaleAboutPoint331 = NXOpen.Point3d(0.41088578849614205, 1.1133679430217183, 0.0)
    viewCenter331 = NXOpen.Point3d(-0.41088578849608515, -1.1133679430217467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint331, viewCenter331)
    
    scaleAboutPoint332 = NXOpen.Point3d(0.32870863079692064, 0.8906943544173711, 0.0)
    viewCenter332 = NXOpen.Point3d(-0.32870863079686286, -0.89069435441739919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint332, viewCenter332)
    
    scaleAboutPoint333 = NXOpen.Point3d(0.22903569113592909, 0.66165866328147038, 0.0)
    viewCenter333 = NXOpen.Point3d(-0.22903569113587169, -0.66165866328150125, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint333, viewCenter333)
    
    scaleAboutPoint334 = NXOpen.Point3d(0.22267358860437472, 0.76345230378631623, 0.0)
    viewCenter334 = NXOpen.Point3d(-0.22267358860431696, -0.76345230378634421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint334, viewCenter334)
    
    scaleAboutPoint335 = NXOpen.Point3d(0.27834198575545965, 0.92780661918476348, 0.0)
    viewCenter335 = NXOpen.Point3d(-0.27834198575540275, -0.9278066191847919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint335, viewCenter335)
    
    scaleAboutPoint336 = NXOpen.Point3d(0.34792748219431907, 1.159758273980954, 0.0)
    viewCenter336 = NXOpen.Point3d(-0.34792748219426162, -1.1597582739809842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint336, viewCenter336)
    
    scaleAboutPoint337 = NXOpen.Point3d(0.43490935274288856, 1.4496978424761995, 0.0)
    viewCenter337 = NXOpen.Point3d(-0.43490935274283382, -1.4496978424762268, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint337, viewCenter337)
    
    scaleAboutPoint338 = NXOpen.Point3d(0.44008684503744488, 1.6567975342585155, 0.0)
    viewCenter338 = NXOpen.Point3d(-0.44008684503740214, -1.656797534258541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint338, viewCenter338)
    
    scaleAboutPoint339 = NXOpen.Point3d(0.48538990261482484, 1.9415596104592032, 0.0)
    viewCenter339 = NXOpen.Point3d(-0.4853899026147821, -1.9415596104592245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint339, viewCenter339)
    
    scaleAboutPoint340 = NXOpen.Point3d(0.52583906116606116, 2.4269495130740042, 0.0)
    viewCenter340 = NXOpen.Point3d(-0.52583906116602108, -2.4269495130740308, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint340, viewCenter340)
    
    scaleAboutPoint341 = NXOpen.Point3d(0.55617593007948052, 3.0336868913425046, 0.0)
    viewCenter341 = NXOpen.Point3d(-0.55617593007943045, -3.0336868913425379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint341, viewCenter341)
    
    scaleAboutPoint342 = NXOpen.Point3d(0.69521991259935068, 3.6657049937055315, 0.0)
    viewCenter342 = NXOpen.Point3d(-0.6952199125992985, -3.6657049937055524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint342, viewCenter342)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin13, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane13
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId132, "Create Sketch Dialog")
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature7
    edge7 = extrude3.FindObject("EDGE * 200 * 210 {(59.9,-110,25)(59.9,-110,15)(59.9,-110,5) EXTRUDE(2)}")
    point60 = workPart.Points.CreatePoint(edge7, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge8 = extrude3.FindObject("EDGE * 200 EXTRUDE(2) 140 {(59.9,-116,5)(59.9,-113,5)(59.9,-110,5) EXTRUDE(2)}")
    direction11 = workPart.Directions.CreateDirection(edge8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude3.FindObject("FACE 200 {(59.9,-113,15) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction11, point60, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem6
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin14, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face3
    plane14.SetGeometry(geom13)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin15, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression67 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point61 = workPart.Points.CreatePoint(edge7, scalar9, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom14 = [NXOpen.NXObject.Null] * 1 
    geom14[0] = face3
    plane15.SetGeometry(geom14)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId133, None)
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject23 = sketchInPlaceBuilder6.Commit()
    
    sketch10 = nXObject23
    feature10 = sketch10.Feature
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId135)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId132, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression65)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point61)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression67)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression66)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin16, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane16
    
    expression68 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression69 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId136, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId137, None)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject24 = sketchInPlaceBuilder7.Commit()
    
    sketch11 = nXObject24
    feature11 = sketch11.Feature
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId140)
    
    sketch11.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId138, None)
    
    theSession.SetUndoMarkName(markId136, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression69)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression68)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint343 = NXOpen.Point3d(-26.307753510860884, -27.650791978382369, 0.0)
    viewCenter343 = NXOpen.Point3d(26.307753510860948, 27.650791978382344, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint343, viewCenter343)
    
    scaleAboutPoint344 = NXOpen.Point3d(-21.046202808688712, -22.120633582705899, 0.0)
    viewCenter344 = NXOpen.Point3d(21.046202808688765, 22.120633582705882, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint344, viewCenter344)
    
    scaleAboutPoint345 = NXOpen.Point3d(-16.836962246950957, -17.696506866164725, 0.0)
    viewCenter345 = NXOpen.Point3d(16.836962246951025, 17.696506866164693, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint345, viewCenter345)
    
    scaleAboutPoint346 = NXOpen.Point3d(-13.469569797560775, -14.157205492931782, 0.0)
    viewCenter346 = NXOpen.Point3d(13.469569797560814, 14.157205492931748, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint346, viewCenter346)
    
    scaleAboutPoint347 = NXOpen.Point3d(-10.775655838048621, -11.325764394345432, 0.0)
    viewCenter347 = NXOpen.Point3d(10.775655838048648, 11.325764394345406, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint347, viewCenter347)
    
    scaleAboutPoint348 = NXOpen.Point3d(-8.6205246704388951, -9.060611515476344, 0.0)
    viewCenter348 = NXOpen.Point3d(8.62052467043892, 9.0606115154763138, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint348, viewCenter348)
    
    scaleAboutPoint349 = NXOpen.Point3d(12.778050982968916, -10.603504219254596, 0.0)
    viewCenter349 = NXOpen.Point3d(-12.778050982968882, 10.603504219254569, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint349, viewCenter349)
    
    scaleAboutPoint350 = NXOpen.Point3d(15.972563728711146, -13.254380274068243, 0.0)
    viewCenter350 = NXOpen.Point3d(-15.972563728711103, 13.254380274068213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint350, viewCenter350)
    
    scaleAboutPoint351 = NXOpen.Point3d(19.965704660888925, -16.567975342585303, 0.0)
    viewCenter351 = NXOpen.Point3d(-19.965704660888882, 16.567975342585271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint351, viewCenter351)
    
    scaleAboutPoint352 = NXOpen.Point3d(24.957130826111143, -20.709969178231621, 0.0)
    viewCenter352 = NXOpen.Point3d(-24.957130826111104, 20.709969178231585, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint352, viewCenter352)
    
    scaleAboutPoint353 = NXOpen.Point3d(31.196413532638921, -25.07847830176485, 0.0)
    viewCenter353 = NXOpen.Point3d(-31.196413532638903, 25.078478301764818, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint353, viewCenter353)
    
    scaleAboutPoint354 = NXOpen.Point3d(38.99551691579866, -31.348097877206065, 0.0)
    viewCenter354 = NXOpen.Point3d(-38.995516915798639, 31.348097877206023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint354, viewCenter354)
    
    scaleAboutPoint355 = NXOpen.Point3d(48.744396144748293, -39.185122346507562, 0.0)
    viewCenter355 = NXOpen.Point3d(-48.744396144748293, 39.185122346507526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint355, viewCenter355)
    
    scaleAboutPoint356 = NXOpen.Point3d(60.93049518093536, -48.981402933134447, 0.0)
    viewCenter356 = NXOpen.Point3d(-60.93049518093536, 48.981402933134419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint356, viewCenter356)
    
    scaleAboutPoint357 = NXOpen.Point3d(74.434944477520332, -63.201810236302521, 0.0)
    viewCenter357 = NXOpen.Point3d(-74.434944477520332, 63.201810236302499, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint357, viewCenter357)
    
    scaleAboutPoint358 = NXOpen.Point3d(93.043680596900415, -79.002262795378158, 0.0)
    viewCenter358 = NXOpen.Point3d(-93.043680596900415, 79.00226279537813, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint358, viewCenter358)
    
    scaleAboutPoint359 = NXOpen.Point3d(116.30460074612553, -98.752828494222697, 0.0)
    viewCenter359 = NXOpen.Point3d(-116.30460074612553, 98.752828494222626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint359, viewCenter359)
    
    scaleAboutPoint360 = NXOpen.Point3d(145.38075093265689, -123.44103561777837, 0.0)
    viewCenter360 = NXOpen.Point3d(-145.38075093265689, 123.44103561777828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint360, viewCenter360)
    
    scaleAboutPoint361 = NXOpen.Point3d(181.72593866582119, -154.30129452222295, 0.0)
    viewCenter361 = NXOpen.Point3d(-181.72593866582119, 154.30129452222286, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint361, viewCenter361)
    
    scaleAboutPoint362 = NXOpen.Point3d(227.15742333227652, -192.87661815277869, 0.0)
    viewCenter362 = NXOpen.Point3d(-227.15742333227627, 192.87661815277855, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint362, viewCenter362)
    
    scaleAboutPoint363 = NXOpen.Point3d(283.94677916534562, -241.09577269097338, 0.0)
    viewCenter363 = NXOpen.Point3d(-283.94677916534545, 241.09577269097321, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint363, viewCenter363)
    
    scaleAboutPoint364 = NXOpen.Point3d(354.93347395668184, -301.36971586371669, 0.0)
    viewCenter364 = NXOpen.Point3d(-354.93347395668184, 301.36971586371658, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint364, viewCenter364)
    
    scaleAboutPoint365 = NXOpen.Point3d(443.66684244585224, -376.71214482964564, 0.0)
    viewCenter365 = NXOpen.Point3d(-443.66684244585224, 376.71214482964564, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint365, viewCenter365)
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.26131608454654542
    rotMatrix1.Xy = 0.50237172162619015
    rotMatrix1.Xz = -0.82421875571209868
    rotMatrix1.Yx = 0.6472604658023593
    rotMatrix1.Yy = 0.5422630608610709
    rotMatrix1.Yz = 0.53572816076336194
    rotMatrix1.Zx = 0.71607806373786842
    rotMatrix1.Zy = -0.67347860109725777
    rotMatrix1.Zz = -0.18346329468726133
    translation1 = NXOpen.Point3d(664.195458132927, -522.42931017422802, -44.910842812771598)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.1438410399302911)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.15405811403947761
    rotMatrix2.Xy = 0.56265162123159951
    rotMatrix2.Xz = -0.81221256492623373
    rotMatrix2.Yx = -0.30263104097832927
    rotMatrix2.Yy = 0.80938882763845144
    rotMatrix2.Yz = 0.50329333269021692
    rotMatrix2.Zx = 0.94057458531206883
    rotMatrix2.Zy = 0.16826431237640715
    rotMatrix2.Zz = 0.29496876215206713
    translation2 = NXOpen.Point3d(673.85752913913507, -448.35414184836696, -23.425101146081886)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.1438410399302911)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.97996579295013164
    rotMatrix3.Xy = -0.081362906998276335
    rotMatrix3.Xz = 0.181788674048763
    rotMatrix3.Yx = -0.15310157702523447
    rotMatrix3.Yy = 0.27604608620133508
    rotMatrix3.Yz = 0.94887220709920228
    rotMatrix3.Zx = -0.12738505312635287
    rotMatrix3.Zy = -0.95769443752050365
    rotMatrix3.Zz = 0.25805893238227834
    translation3 = NXOpen.Point3d(553.35715644401546, -503.8077875900716, -25.705478366073102)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 0.1438410399302911)
    
    theSession.DeleteUndoMark(markId141, "Curve")
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.54236554860088904
    rotMatrix4.Xy = 0.70993833579379451
    rotMatrix4.Xz = -0.44925179027043682
    rotMatrix4.Yx = -0.19044645156728585
    rotMatrix4.Yy = 0.62470426259734091
    rotMatrix4.Yz = 0.75728114553192194
    rotMatrix4.Zx = 0.81827242454837978
    rotMatrix4.Zy = -0.32516479462427506
    rotMatrix4.Zz = 0.47402330698043421
    translation4 = NXOpen.Point3d(827.59546146537627, -443.41677529296311, -310.13380613783733)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.1438410399302911)
    
    scaleAboutPoint366 = NXOpen.Point3d(826.81693896936417, -367.88295393520093, 0.0)
    viewCenter366 = NXOpen.Point3d(-826.8169389693636, 367.88295393520093, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint366, viewCenter366)
    
    scaleAboutPoint367 = NXOpen.Point3d(671.75427388567709, -323.73699946297683, 0.0)
    viewCenter367 = NXOpen.Point3d(-671.75427388567653, 323.73699946297683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint367, viewCenter367)
    
    scaleAboutPoint368 = NXOpen.Point3d(550.35289908706045, -289.59746133779009, 0.0)
    viewCenter368 = NXOpen.Point3d(-550.35289908706034, 289.59746133779004, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint368, viewCenter368)
    
    scaleAboutPoint369 = NXOpen.Point3d(445.93300144209314, -279.70876753601198, 0.0)
    viewCenter369 = NXOpen.Point3d(-445.9330014420928, 279.70876753601186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint369, viewCenter369)
    
    scaleAboutPoint370 = NXOpen.Point3d(356.74640115367447, -223.76701402880957, 0.0)
    viewCenter370 = NXOpen.Point3d(-356.74640115367424, 223.76701402880946, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint370, viewCenter370)
    
    scaleAboutPoint371 = NXOpen.Point3d(151.58896707944956, -109.69857657439286, 0.0)
    viewCenter371 = NXOpen.Point3d(-151.5889670794493, 109.69857657439276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint371, viewCenter371)
    
    scaleAboutPoint372 = NXOpen.Point3d(121.27117366355965, -87.758861259514276, 0.0)
    viewCenter372 = NXOpen.Point3d(-121.27117366355934, 87.758861259514191, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint372, viewCenter372)
    
    scaleAboutPoint373 = NXOpen.Point3d(97.016938930847786, -70.207089007611458, 0.0)
    viewCenter373 = NXOpen.Point3d(-97.016938930847473, 70.20708900761133, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint373, viewCenter373)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.54236554860088904
    rotMatrix5.Xy = 0.70993833579379451
    rotMatrix5.Xz = -0.44925179027043682
    rotMatrix5.Yx = -0.19044645156728585
    rotMatrix5.Yy = 0.62470426259734091
    rotMatrix5.Yz = 0.75728114553192194
    rotMatrix5.Zx = 0.81827242454837978
    rotMatrix5.Zy = -0.32516479462427506
    rotMatrix5.Zz = 0.47402330698043421
    translation5 = NXOpen.Point3d(209.22797224052852, -111.208368811884, -310.13380613783733)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.6743064811876408)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.64824752362964322
    rotMatrix6.Xy = 0.66390058779779826
    rotMatrix6.Xz = -0.37284200089283315
    rotMatrix6.Yx = -0.36240873144404556
    rotMatrix6.Yy = 0.69965965579414835
    rotMatrix6.Yz = 0.61574043023593061
    rotMatrix6.Zx = 0.66965293957478478
    rotMatrix6.Zy = -0.26403101252646149
    rotMatrix6.Zz = 0.69415600908088326
    translation6 = NXOpen.Point3d(197.62947070427137, -91.793235180350251, -304.7029229318174)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 0.6743064811876408)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.66069679114134461
    rotMatrix7.Xy = 0.65062157067660542
    rotMatrix7.Xz = -0.37439460726062251
    rotMatrix7.Yx = -0.33795441657409819
    rotMatrix7.Yy = 0.7031682678151856
    rotMatrix7.Yz = 0.62557269717903363
    rotMatrix7.Zx = 0.67027349827782212
    rotMatrix7.Zy = -0.2867855625865709
    rotMatrix7.Zz = 0.68446145150644755
    translation7 = NXOpen.Point3d(196.13623333325083, -93.369526026935745, -305.79035633643713)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 0.6743064811876408)
    
    scaleAboutPoint374 = NXOpen.Point3d(171.27319434419366, -108.2964527812083, 0.0)
    viewCenter374 = NXOpen.Point3d(-171.2731943441932, 108.29645278120807, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint374, viewCenter374)
    
    scaleAboutPoint375 = NXOpen.Point3d(136.39074995198567, -86.323259463282, 0.0)
    viewCenter375 = NXOpen.Point3d(-136.39074995198521, 86.323259463281801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint375, viewCenter375)
    
    scaleAboutPoint376 = NXOpen.Point3d(98.063222750288475, -62.278307918236933, 0.0)
    viewCenter376 = NXOpen.Point3d(-98.06322275028802, 62.278307918236706, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint376, viewCenter376)
    
    scaleAboutPoint377 = NXOpen.Point3d(24.00728321364311, -31.340051726596712, 0.0)
    viewCenter377 = NXOpen.Point3d(-24.00728321364268, 31.340051726596482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint377, viewCenter377)
    
    scaleAboutPoint378 = NXOpen.Point3d(30.009104017053886, -39.175064658245851, 0.0)
    viewCenter378 = NXOpen.Point3d(-30.009104017053367, 39.175064658245638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint378, viewCenter378)
    
    scaleAboutPoint379 = NXOpen.Point3d(36.88357449794799, -48.654928061122646, 0.0)
    viewCenter379 = NXOpen.Point3d(-36.883574497947471, 48.654928061122462, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint379, viewCenter379)
    
    scaleAboutPoint380 = NXOpen.Point3d(44.534954314011593, -59.641524720085812, 0.0)
    viewCenter380 = NXOpen.Point3d(-44.534954314011138, 59.641524720085584, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint380, viewCenter380)
    
    scaleAboutPoint381 = NXOpen.Point3d(246.95318829410499, -166.76084214497646, 0.0)
    viewCenter381 = NXOpen.Point3d(-246.95318829410451, 166.76084214497627, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint381, viewCenter381)
    
    scaleAboutPoint382 = NXOpen.Point3d(300.10820672781625, -202.32013936706704, 0.0)
    viewCenter382 = NXOpen.Point3d(-300.10820672781597, 202.3201393670669, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint382, viewCenter382)
    
    scaleAboutPoint383 = NXOpen.Point3d(372.06980175269325, -251.36744588029535, 0.0)
    viewCenter383 = NXOpen.Point3d(-372.06980175269314, 251.36744588029524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint383, viewCenter383)
    
    scaleAboutPoint384 = NXOpen.Point3d(471.79293862822186, -344.86387392113693, 0.0)
    viewCenter384 = NXOpen.Point3d(-471.79293862822169, 344.8638739211367, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint384, viewCenter384)
    
    scaleAboutPoint385 = NXOpen.Point3d(377.43435090257742, -275.89109913690953, 0.0)
    viewCenter385 = NXOpen.Point3d(-377.43435090257742, 275.89109913690925, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint385, viewCenter385)
    
    scaleAboutPoint386 = NXOpen.Point3d(301.94748072206175, -220.71287930952758, 0.0)
    viewCenter386 = NXOpen.Point3d(-301.94748072206187, 220.71287930952738, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint386, viewCenter386)
    
    scaleAboutPoint387 = NXOpen.Point3d(241.55798457764953, -176.57030344762214, 0.0)
    viewCenter387 = NXOpen.Point3d(-241.55798457764962, 176.57030344762188, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint387, viewCenter387)
    
    scaleAboutPoint388 = NXOpen.Point3d(193.24638766211959, -141.25624275809773, 0.0)
    viewCenter388 = NXOpen.Point3d(-193.2463876621197, 141.2562427580975, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint388, viewCenter388)
    
    scaleAboutPoint389 = NXOpen.Point3d(154.59711012969566, -113.0049942064782, 0.0)
    viewCenter389 = NXOpen.Point3d(-154.59711012969578, 113.00499420647797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint389, viewCenter389)
    
    scaleAboutPoint390 = NXOpen.Point3d(123.67768810375654, -90.40399536518261, 0.0)
    viewCenter390 = NXOpen.Point3d(-123.67768810375662, 90.403995365182354, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint390, viewCenter390)
    
    scaleAboutPoint391 = NXOpen.Point3d(66.396712151539518, -65.291774430409689, 0.0)
    viewCenter391 = NXOpen.Point3d(-66.39671215153966, 65.291774430409475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint391, viewCenter391)
    
    scaleAboutPoint392 = NXOpen.Point3d(51.992342223353752, -52.233419544327774, 0.0)
    viewCenter392 = NXOpen.Point3d(-51.992342223353909, 52.233419544327553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint392, viewCenter392)
    
    scaleAboutPoint393 = NXOpen.Point3d(41.208150065124904, -41.786735635462229, 0.0)
    viewCenter393 = NXOpen.Point3d(-41.208150065125039, 41.78673563546203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint393, viewCenter393)
    
    scaleAboutPoint394 = NXOpen.Point3d(32.452221767355759, -33.429388508369833, 0.0)
    viewCenter394 = NXOpen.Point3d(-32.452221767355908, 33.429388508369598, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint394, viewCenter394)
    
    scaleAboutPoint395 = NXOpen.Point3d(-3.6618037873784117, -18.350162799671367, 0.0)
    viewCenter395 = NXOpen.Point3d(3.6618037873782758, 18.350162799671136, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint395, viewCenter395)
    
    scaleAboutPoint396 = NXOpen.Point3d(-4.577254734222997, -22.937703499589173, 0.0)
    viewCenter396 = NXOpen.Point3d(4.5772547342228531, 22.937703499588942, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint396, viewCenter396)
    
    scaleAboutPoint397 = NXOpen.Point3d(-6.6215904160809842, -28.157831089742295, 0.0)
    viewCenter397 = NXOpen.Point3d(6.6215904160808456, 28.157831089742064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint397, viewCenter397)
    
    scaleAboutPoint398 = NXOpen.Point3d(-5.2972723328648046, -22.526264871793874, 0.0)
    viewCenter398 = NXOpen.Point3d(5.2972723328646607, 22.526264871793618, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint398, viewCenter398)
    
    scaleAboutPoint399 = NXOpen.Point3d(-4.2378178662918566, -17.938724171876057, 0.0)
    viewCenter399 = NXOpen.Point3d(4.2378178662917207, 17.938724171875805, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint399, viewCenter399)
    
    scaleAboutPoint400 = NXOpen.Point3d(-10.763234503125632, -12.112753202294336, 0.0)
    viewCenter400 = NXOpen.Point3d(10.763234503125492, 12.112753202294074, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint400, viewCenter400)
    
    scaleAboutPoint401 = NXOpen.Point3d(-13.618618580025148, -15.058653777308821, 0.0)
    viewCenter401 = NXOpen.Point3d(13.618618580025013, 15.058653777308562, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint401, viewCenter401)
    
    scaleAboutPoint402 = NXOpen.Point3d(-17.3318521958779, -18.617597907738332, 0.0)
    viewCenter402 = NXOpen.Point3d(17.331852195877779, 18.617597907738077, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint402, viewCenter402)
    
    scaleAboutPoint403 = NXOpen.Point3d(-26.164925236358659, -21.986251672812507, 0.0)
    viewCenter403 = NXOpen.Point3d(26.164925236358531, 21.986251672812241, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint403, viewCenter403)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin17, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane17
    
    expression70 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression71 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId142, "Create Sketch Dialog")
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge9 = extrude3.FindObject("EDGE * 150 * 200 {(59.9,-116,25)(59.9,-113,25)(59.9,-110,25) EXTRUDE(2)}")
    point62 = workPart.Points.CreatePoint(edge9, scalar10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction12 = workPart.Directions.CreateDirection(edge8, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction12, point62, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem7
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin18, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane18.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face3
    plane18.SetGeometry(geom15)
    
    plane18.SetFlip(False)
    
    plane18.SetExpression(None)
    
    plane18.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane18.Evaluate()
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin19, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression72 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane19.SynchronizeToPlane(plane18)
    
    scalar11 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point63 = workPart.Points.CreatePoint(edge9, scalar11, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane19.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom16 = [NXOpen.NXObject.Null] * 1 
    geom16[0] = face3
    plane19.SetGeometry(geom16)
    
    plane19.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane19.Evaluate()
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId143, None)
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject25 = sketchInPlaceBuilder8.Commit()
    
    sketch12 = nXObject25
    feature12 = sketch12.Feature
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId146)
    
    sketch12.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId144, None)
    
    theSession.SetUndoMarkName(markId142, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression71)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point63)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression70)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression73)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression72)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint404 = NXOpen.Point3d(11.491352299752029, -0.96430928389541803, 0.0)
    viewCenter404 = NXOpen.Point3d(-11.491352299752148, 0.96430928389515269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint404, viewCenter404)
    
    scaleAboutPoint405 = NXOpen.Point3d(9.1930818398016214, -0.90002199830239704, 0.0)
    viewCenter405 = NXOpen.Point3d(-9.1930818398016854, 0.90002199830212104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint405, viewCenter405)
    
    scaleAboutPoint406 = NXOpen.Point3d(7.3544654718413138, -0.72001759864194315, 0.0)
    viewCenter406 = NXOpen.Point3d(-7.3544654718413645, 0.72001759864166293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint406, viewCenter406)
    
    scaleAboutPoint407 = NXOpen.Point3d(4.402393317409893, -1.8103299622995466, 0.0)
    viewCenter407 = NXOpen.Point3d(-4.4023933174099472, 1.8103299622992612, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint407, viewCenter407)
    
    scaleAboutPoint408 = NXOpen.Point3d(3.5219146539278929, -1.4482639698396647, 0.0)
    viewCenter408 = NXOpen.Point3d(-3.5219146539279853, 1.4482639698393767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint408, viewCenter408)
    
    scaleAboutPoint409 = NXOpen.Point3d(2.8175317231423058, -1.1586111758717621, 0.0)
    viewCenter409 = NXOpen.Point3d(-2.8175317231423929, 1.1586111758714797, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint409, viewCenter409)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId148, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(59.899999999999999, -113.40000000000001, 21.499999999999996)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 2.2861203065924038, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = arc2
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(59.899999999999999, -113.40000000000001, 21.977709403938473)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension10 = sketchDimensionalConstraint10.AssociatedDimension
    
    expression74 = sketchDimensionalConstraint10.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder27 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines137 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines137)
    
    lines138 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines138)
    
    lines139 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines139)
    
    lines140 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines140)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder27.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines141 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBefore(lines141)
    
    lines142 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAfter(lines142)
    
    lines143 = []
    sketchRapidDimensionBuilder27.AppendedText.SetAbove(lines143)
    
    lines144 = []
    sketchRapidDimensionBuilder27.AppendedText.SetBelow(lines144)
    
    theSession.SetUndoMarkName(markId149, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder27.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder27.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    point1_77 = NXOpen.Point3d(59.899999999999999, -113.40000000000001, 21.499999999999996)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder27.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    point1_78 = NXOpen.Point3d(59.899999999999999, -113.40000000000001, 21.499999999999996)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder27.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    point1_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder27.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder27.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point64 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point64
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder27.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point65 = NXOpen.Point3d(59.899999999999999, -103.79899835502661, 28.908234953496198)
    sketchRapidDimensionBuilder27.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point65)
    
    sketchRapidDimensionBuilder27.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder27.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder27.Style.DimensionStyle.TextCentered = False
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject26 = sketchRapidDimensionBuilder27.Commit()
    
    theSession.DeleteUndoMark(markId150, None)
    
    theSession.SetUndoMarkName(markId149, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId149, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder27.Destroy()
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder28 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines145 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBefore(lines145)
    
    lines146 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAfter(lines146)
    
    lines147 = []
    sketchRapidDimensionBuilder28.AppendedText.SetAbove(lines147)
    
    lines148 = []
    sketchRapidDimensionBuilder28.AppendedText.SetBelow(lines148)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder28.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId151, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder28.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder28.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    expression75 = workPart.Expressions.FindObject("p31")
    expression75.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId151, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.65613344830369624)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId152, None)
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId151, "Edit Driving Value")
    
    point1_80 = NXOpen.Point3d(59.899999999999999, -114.2940530344104, 22.703532930937058)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    point1_81 = NXOpen.Point3d(59.899999999999999, -114.2940530344104, 22.703532930937058)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    point1_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    point66 = NXOpen.Point3d(59.899999999999999, -110.0, 22.462143684101374)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(edge7, workPart.ModelingViews.WorkView, point66)
    
    point1_83 = NXOpen.Point3d(59.899999999999999, -110.0, 22.462143684101374)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge7, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    point1_84 = NXOpen.Point3d(59.899999999999999, -114.2940530344104, 22.703532930937058)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(59.899999999999999, -110.0, 22.462143684101374)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge7, workPart.ModelingViews.WorkView, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    point1_86 = NXOpen.Point3d(59.899999999999999, -114.2940530344104, 22.703532930937058)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder28.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder28.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point67 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point67
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder28.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point68 = NXOpen.Point3d(59.899999999999999, -110.96132198768753, 27.475770226964013)
    sketchRapidDimensionBuilder28.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point68)
    
    sketchRapidDimensionBuilder28.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder28.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder28.Style.DimensionStyle.TextCentered = False
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject27 = sketchRapidDimensionBuilder28.Commit()
    
    theSession.DeleteUndoMark(markId154, None)
    
    theSession.SetUndoMarkName(markId153, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId153, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder28.Destroy()
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder29 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines149 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBefore(lines149)
    
    lines150 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAfter(lines150)
    
    lines151 = []
    sketchRapidDimensionBuilder29.AppendedText.SetAbove(lines151)
    
    lines152 = []
    sketchRapidDimensionBuilder29.AppendedText.SetBelow(lines152)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder29.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId155, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder29.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder29.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    expression76 = workPart.Expressions.FindObject("p32")
    expression76.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId155, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId156, None)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId155, "Edit Driving Value")
    
    point1_87 = NXOpen.Point3d(59.899999999999999, -113.0, 22.703532930937058)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    point1_88 = NXOpen.Point3d(59.899999999999999, -113.0, 22.703532930937058)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    point1_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension2 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point69 = NXOpen.Point3d(59.899999999999999, -111.08818480702112, 24.999999999999996)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(perpendicularDimension2, workPart.ModelingViews.WorkView, point69)
    
    line18 = theSession.ActiveSketch.FindObject("Curve DATUM7")
    point1_90 = NXOpen.Point3d(59.899999999999999, -101.71250000000001, 24.999999999999996)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, NXOpen.View.Null, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(59.899999999999999, -113.0, 22.703532930937058)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    point1_92 = NXOpen.Point3d(59.899999999999999, -101.71250000000001, 24.999999999999996)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line18, workPart.ModelingViews.WorkView, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    point1_93 = NXOpen.Point3d(59.899999999999999, -113.0, 22.703532930937058)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder29.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder29.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point70 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point70
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder29.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point71 = NXOpen.Point3d(59.899999999999999, -121.78907006765139, 23.473295255771149)
    sketchRapidDimensionBuilder29.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point71)
    
    sketchRapidDimensionBuilder29.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder29.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder29.Style.DimensionStyle.TextCentered = False
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject28 = sketchRapidDimensionBuilder29.Commit()
    
    theSession.DeleteUndoMark(markId158, None)
    
    theSession.SetUndoMarkName(markId157, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId157, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder29.Destroy()
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder30 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines153 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBefore(lines153)
    
    lines154 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAfter(lines154)
    
    lines155 = []
    sketchRapidDimensionBuilder30.AppendedText.SetAbove(lines155)
    
    lines156 = []
    sketchRapidDimensionBuilder30.AppendedText.SetBelow(lines156)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder30.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId159, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder30.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder30.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder30.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder30.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits833 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits834 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits835 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits836 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits837 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits838 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits839 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits840 = sketchRapidDimensionBuilder30.Style.UnitsStyle.DimensionLinearUnits
    
    expression77 = workPart.Expressions.FindObject("p33")
    expression77.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId159, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId159, "Edit Driving Value")
    
    sketchRapidDimensionBuilder30.Destroy()
    
    theSession.UndoToMark(markId161, None)
    
    theSession.DeleteUndoMark(markId161, None)
    
    sketchRapidDimensionBuilder30.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch13 = theSession.ActiveSketch
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies30 = [NXOpen.Body.Null] * 1 
    targetBodies30[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies30)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("15.5")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies31 = [NXOpen.Body.Null] * 1 
    targetBodies31[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies31)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId163, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature12
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section9.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint5 = NXOpen.Point3d(59.899999999999999, -113.11307330107005, 19.50923374455364)
    section9.AddToSection(rules5, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId165, None)
    
    direction13 = workPart.Directions.CreateDirection(sketch13, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction13
    
    targetBodies32 = [NXOpen.Body.Null] * 1 
    targetBodies32[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies32)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies33 = [NXOpen.Body.Null] * 1 
    targetBodies33[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies33)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId164, None)
    
    direction14 = extrudeBuilder9.Direction
    
    success2 = direction14.ReverseDirection()
    
    extrudeBuilder9.Direction = direction14
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies34 = [NXOpen.Body.Null] * 1 
    targetBodies34[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies34)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies35 = [NXOpen.Body.Null] * 1 
    targetBodies35[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies35)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies36 = [NXOpen.Body.Null] * 1 
    targetBodies36[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies36)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies37 = [NXOpen.Body.Null] * 1 
    targetBodies37[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies37)
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies38 = [NXOpen.Body.Null] * 1 
    targetBodies38[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies38)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("31")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies39 = [NXOpen.Body.Null] * 1 
    targetBodies39[0] = body1
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies39)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    feature13 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId166, None)
    
    theSession.SetUndoMarkName(markId163, "Extrude")
    
    expression80 = extrudeBuilder9.Limits.StartExtend.Value
    expression81 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression78)
    
    workPart.Expressions.Delete(expression79)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder10 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section10 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder10.Section = section10
    
    extrudeBuilder10.AllowSelfIntersectingSection(True)
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder10.DistanceTolerance = 0.01
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies40 = [NXOpen.Body.Null] * 1 
    targetBodies40[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies40)
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("31")
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies41 = [NXOpen.Body.Null] * 1 
    targetBodies41[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies41)
    
    extrudeBuilder10.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder10.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder10 = extrudeBuilder10.SmartVolumeProfile
    
    smartVolumeProfileBuilder10.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder10.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId167, "Extrude Dialog")
    
    section10.DistanceTolerance = 0.01
    
    section10.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section10.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder10.Destroy()
    
    section10.Destroy()
    
    workPart.Expressions.Delete(expression82)
    
    theSession.UndoToMark(markId167, None)
    
    theSession.DeleteUndoMark(markId167, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal20 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane20 = workPart.Planes.CreatePlane(origin20, normal20, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.PlaneReference = plane20
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression84 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId168, "Create Sketch Dialog")
    
    scalar12 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge10 = extrude3.FindObject("EDGE * 230 EXTRUDE(2) 140 {(54,-116,5)(56.95,-116,5)(59.9,-116,5) EXTRUDE(2)}")
    point72 = workPart.Points.CreatePoint(edge10, scalar12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction15 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face4 = extrude3.FindObject("FACE 230 {(56.95,-116,15) EXTRUDE(2)}")
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction15, point72, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9.Csystem = cartesianCoordinateSystem8
    
    origin21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal21 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin21, normal21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane21.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom17 = [NXOpen.NXObject.Null] * 1 
    geom17[0] = face4
    plane21.SetGeometry(geom17)
    
    plane21.SetFlip(False)
    
    plane21.SetExpression(None)
    
    plane21.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane21.Evaluate()
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal22 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin22, normal22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression85 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane22.SynchronizeToPlane(plane21)
    
    scalar13 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point73 = workPart.Points.CreatePoint(edge10, scalar13, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane22.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face4
    plane22.SetGeometry(geom18)
    
    plane22.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane22.Evaluate()
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId169, None)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject29 = sketchInPlaceBuilder9.Commit()
    
    sketch14 = nXObject29
    feature14 = sketch14.Feature
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId171)
    
    sketch14.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId170, None)
    
    theSession.SetUndoMarkName(markId168, "Create Sketch")
    
    sketchInPlaceBuilder9.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression84)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point73)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression83)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane20.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression86)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression85)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane22.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint410 = NXOpen.Point3d(23.545218348443029, 17.357567110114903, 0.0)
    viewCenter410 = NXOpen.Point3d(-23.54521834844315, -17.35756711011517, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint410, viewCenter410)
    
    scaleAboutPoint411 = NXOpen.Point3d(18.836174678754379, 13.886053688091888, 0.0)
    viewCenter411 = NXOpen.Point3d(-18.836174678754503, -13.886053688092165, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint411, viewCenter411)
    
    scaleAboutPoint412 = NXOpen.Point3d(15.068939743003501, 11.108842950473486, 0.0)
    viewCenter412 = NXOpen.Point3d(-15.068939743003638, -11.108842950473758, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint412, viewCenter412)
    
    scaleAboutPoint413 = NXOpen.Point3d(12.055151794402807, 8.8870743603787652, 0.0)
    viewCenter413 = NXOpen.Point3d(-12.055151794402915, -8.887074360379037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint413, viewCenter413)
    
    scaleAboutPoint414 = NXOpen.Point3d(3.6535750148223669, 5.7930558793579658, 0.0)
    viewCenter414 = NXOpen.Point3d(-3.6535750148224868, -5.7930558793582323, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint414, viewCenter414)
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId173, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint17 = NXOpen.Point3d(55.59743618732945, -116.0, 24.999999999999993)
    endPoint17 = NXOpen.Point3d(58.17797926086169, -116.0, 24.999999999999993)
    line19 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    startPoint18 = NXOpen.Point3d(58.17797926086169, -116.0, 24.999999999999993)
    endPoint18 = NXOpen.Point3d(58.17797926086169, -116.0, 4.9999999999999956)
    line20 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(58.17797926086169, -116.0, 4.9999999999999956)
    endPoint19 = NXOpen.Point3d(55.59743618732945, -116.0, 4.9999999999999956)
    line21 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(55.59743618732945, -116.0, 4.9999999999999956)
    endPoint20 = NXOpen.Point3d(55.59743618732945, -116.0, 24.999999999999993)
    line22 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line19
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_18.Geometry = line20
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line20
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = line21
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line21
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_20.Geometry = line22
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = line22
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line19
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    geom19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom19.Geometry = line19
    geom19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateHorizontalConstraint(geom19)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line19
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = line20
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint43 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_17, conGeom2_17)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line20
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line21
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line21
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line22
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint45 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line22
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line19
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line19
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    edge11 = extrude3.FindObject("EDGE * 150 * 230 {(54,-116,25)(56.95,-116,25)(59.9,-116,25) EXTRUDE(2)}")
    conGeom2_21.Geometry = edge11
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 55.59743618732945
    help1.Point.Y = -116.0
    help1.Point.Z = 24.999999999999993
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_21, conGeom2_21, help1)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line21
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_22.SplineDefiningPointIndex = 0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    edge12 = extrude1.FindObject("EDGE * 130 * 140 {(0,-120,5)(60,-120,5)(120,-120,5) EXTRUDE(2)}")
    conGeom2_22.Geometry = edge12
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 58.17797926086169
    help2.Point.Y = -116.0
    help2.Point.Z = 4.9999999999999964
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_22, conGeom2_22, help2)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = line20
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line20
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(56.3865689960924, -116.0, 14.999999999999995)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_11, dimObject2_9, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint11
    dimension11 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression87 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line19
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line19
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(56.88770772409557, -116.0, 23.208589735230703)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_10, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint12
    dimension12 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression88 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line19
    geoms9[1] = line20
    geoms9[2] = line21
    geoms9[3] = line22
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line19
    geoms10[1] = line20
    geoms10[2] = line21
    geoms10[3] = line22
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder31 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines157 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBefore(lines157)
    
    lines158 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAfter(lines158)
    
    lines159 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAbove(lines159)
    
    lines160 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBelow(lines160)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder31.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines161 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBefore(lines161)
    
    lines162 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAfter(lines162)
    
    lines163 = []
    sketchRapidDimensionBuilder31.AppendedText.SetAbove(lines163)
    
    lines164 = []
    sketchRapidDimensionBuilder31.AppendedText.SetBelow(lines164)
    
    theSession.SetUndoMarkName(markId174, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder31.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits841 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits842 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits843 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits844 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits845 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits846 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits847 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits848 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits849 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits850 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder31.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits851 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits852 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits853 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits854 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits855 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits856 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits857 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits858 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits859 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits860 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    point74 = NXOpen.Point3d(58.17797926086169, -116.0, 21.146291789885463)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(line20, workPart.ModelingViews.WorkView, point74)
    
    point1_94 = NXOpen.Point3d(58.17797926086169, -116.0, 24.999999999999993)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line20, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    point1_95 = NXOpen.Point3d(58.17797926086169, -116.0, 4.9999999999999964)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line20, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    dimensionlinearunits861 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits862 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits863 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits864 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits865 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits866 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    edge13 = extrude3.FindObject("EDGE * 200 * 230 {(59.9,-116,25)(59.9,-116,15)(59.9,-116,5) EXTRUDE(2)}")
    point1_96 = NXOpen.Point3d(59.899999999999999, -116.0, 14.999999999999996)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    point1_97 = NXOpen.Point3d(58.17797926086169, -116.0, 21.146291789885463)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line20, workPart.ModelingViews.WorkView, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(59.899999999999999, -116.0, 14.999999999999996)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    point1_99 = NXOpen.Point3d(58.17797926086169, -116.0, 21.146291789885463)
    point2_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line20, workPart.ModelingViews.WorkView, point1_99, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_99)
    
    point1_100 = NXOpen.Point3d(59.899999999999999, -116.0, 14.999999999999996)
    point2_100 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder31.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge13, workPart.ModelingViews.WorkView, point1_100, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_100)
    
    dimensionlinearunits867 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits868 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits869 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits870 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits871 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits872 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits873 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits874 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits875 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits876 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits877 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits878 = sketchRapidDimensionBuilder31.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin21 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin21.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin21.View = NXOpen.View.Null
    assocOrigin21.ViewOfGeometry = workPart.ModelingViews.WorkView
    point75 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin21.PointOnGeometry = point75
    assocOrigin21.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.DimensionLine = 0
    assocOrigin21.AssociatedView = NXOpen.View.Null
    assocOrigin21.AssociatedPoint = NXOpen.Point.Null
    assocOrigin21.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.XOffsetFactor = 0.0
    assocOrigin21.YOffsetFactor = 0.0
    assocOrigin21.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder31.Origin.SetAssociativeOrigin(assocOrigin21)
    
    point76 = NXOpen.Point3d(58.388635838292899, -116.0, 28.413943711261982)
    sketchRapidDimensionBuilder31.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point76)
    
    sketchRapidDimensionBuilder31.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder31.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder31.Style.DimensionStyle.TextCentered = False
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject30 = sketchRapidDimensionBuilder31.Commit()
    
    theSession.DeleteUndoMark(markId175, None)
    
    theSession.SetUndoMarkName(markId174, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId174, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder31.Destroy()
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder32 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines165 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBefore(lines165)
    
    lines166 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAfter(lines166)
    
    lines167 = []
    sketchRapidDimensionBuilder32.AppendedText.SetAbove(lines167)
    
    lines168 = []
    sketchRapidDimensionBuilder32.AppendedText.SetBelow(lines168)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder32.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId176, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder32.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits879 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits880 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits881 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits882 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits883 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits884 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits885 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits886 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits887 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits888 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder32.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder32.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder32.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits889 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits890 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits891 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits892 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits893 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits894 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits895 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits896 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits897 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits898 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    expression89 = workPart.Expressions.FindObject("p36")
    expression89.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId176, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId177, None)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId176, "Edit Driving Value")
    
    point77 = NXOpen.Point3d(55.819456926467765, -116.0, 11.982730671628119)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(line22, workPart.ModelingViews.WorkView, point77)
    
    point1_101 = NXOpen.Point3d(55.819456926467765, -116.0, 4.9999999999999991)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line22, workPart.ModelingViews.WorkView, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(55.819456926467758, -116.0, 24.999999999999993)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line22, workPart.ModelingViews.WorkView, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    dimensionlinearunits899 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits900 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits901 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits902 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits903 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits904 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    edge14 = extrude3.FindObject("EDGE * 220 * 230 {(54,-116,25)(54,-116,15)(54,-116,5) EXTRUDE(2)}")
    point1_103 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    point1_104 = NXOpen.Point3d(55.819456926467765, -116.0, 11.982730671628119)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, workPart.ModelingViews.WorkView, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    point1_105 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_105 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_105, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_105)
    
    point1_106 = NXOpen.Point3d(55.819456926467765, -116.0, 11.982730671628119)
    point2_106 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, workPart.ModelingViews.WorkView, point1_106, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_106)
    
    point1_107 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder32.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    dimensionlinearunits905 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits906 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits907 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits908 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits909 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits910 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits911 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits912 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits913 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits914 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits915 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits916 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits917 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits918 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits919 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits920 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits921 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits922 = sketchRapidDimensionBuilder32.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder32.Destroy()
    
    theSession.UndoToMark(markId178, None)
    
    theSession.DeleteUndoMark(markId178, None)
    
    sketchRapidDimensionBuilder32.Destroy()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder33 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines169 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBefore(lines169)
    
    lines170 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAfter(lines170)
    
    lines171 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAbove(lines171)
    
    lines172 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBelow(lines172)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder33.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines173 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBefore(lines173)
    
    lines174 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAfter(lines174)
    
    lines175 = []
    sketchRapidDimensionBuilder33.AppendedText.SetAbove(lines175)
    
    lines176 = []
    sketchRapidDimensionBuilder33.AppendedText.SetBelow(lines176)
    
    theSession.SetUndoMarkName(markId179, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder33.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits923 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits924 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits925 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits926 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits927 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits928 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits929 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits930 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits931 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits932 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder33.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits933 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits934 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits935 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits936 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits937 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits938 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits939 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits940 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits941 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits942 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    point78 = NXOpen.Point3d(55.819456926467765, -116.0, 13.404662569288739)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(line22, workPart.ModelingViews.WorkView, point78)
    
    point1_108 = NXOpen.Point3d(55.819456926467765, -116.0, 4.9999999999999991)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line22, workPart.ModelingViews.WorkView, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    point1_109 = NXOpen.Point3d(55.819456926467758, -116.0, 24.999999999999993)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line22, workPart.ModelingViews.WorkView, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    dimensionlinearunits943 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits944 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits945 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits946 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits947 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits948 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    point1_110 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    point1_111 = NXOpen.Point3d(55.819456926467765, -116.0, 13.404662569288739)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, workPart.ModelingViews.WorkView, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    point1_113 = NXOpen.Point3d(55.819456926467765, -116.0, 13.404662569288739)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line22, workPart.ModelingViews.WorkView, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(54.0, -116.0, 14.999999999999995)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder33.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge14, workPart.ModelingViews.WorkView, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    dimensionlinearunits949 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits950 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits951 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits952 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits953 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits954 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits955 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits956 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits957 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits958 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits959 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits960 = sketchRapidDimensionBuilder33.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin22 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin22.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin22.View = NXOpen.View.Null
    assocOrigin22.ViewOfGeometry = workPart.ModelingViews.WorkView
    point79 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin22.PointOnGeometry = point79
    assocOrigin22.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.DimensionLine = 0
    assocOrigin22.AssociatedView = NXOpen.View.Null
    assocOrigin22.AssociatedPoint = NXOpen.Point.Null
    assocOrigin22.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin22.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin22.XOffsetFactor = 0.0
    assocOrigin22.YOffsetFactor = 0.0
    assocOrigin22.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder33.Origin.SetAssociativeOrigin(assocOrigin22)
    
    point80 = NXOpen.Point3d(54.649481588889046, -116.0, 27.571317401537168)
    sketchRapidDimensionBuilder33.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point80)
    
    sketchRapidDimensionBuilder33.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder33.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder33.Style.DimensionStyle.TextCentered = True
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject31 = sketchRapidDimensionBuilder33.Commit()
    
    theSession.DeleteUndoMark(markId180, None)
    
    theSession.SetUndoMarkName(markId179, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId179, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder33.Destroy()
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder34 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines177 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBefore(lines177)
    
    lines178 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAfter(lines178)
    
    lines179 = []
    sketchRapidDimensionBuilder34.AppendedText.SetAbove(lines179)
    
    lines180 = []
    sketchRapidDimensionBuilder34.AppendedText.SetBelow(lines180)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder34.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId181, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder34.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits961 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits962 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits963 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits964 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits965 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits966 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits967 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits968 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits969 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits970 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder34.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder34.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder34.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits971 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits972 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits973 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits974 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits975 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits976 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits977 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits978 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits979 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits980 = sketchRapidDimensionBuilder34.Style.UnitsStyle.DimensionLinearUnits
    
    expression90 = workPart.Expressions.FindObject("p37")
    expression90.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId181, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId182, None)
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId181, "Edit Driving Value")
    
    sketchRapidDimensionBuilder34.Destroy()
    
    theSession.UndoToMark(markId183, None)
    
    theSession.DeleteUndoMark(markId183, None)
    
    sketchRapidDimensionBuilder34.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch15 = theSession.ActiveSketch
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder11 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section11 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder11.Section = section11
    
    extrudeBuilder11.AllowSelfIntersectingSection(True)
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder11.DistanceTolerance = 0.01
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies42 = [NXOpen.Body.Null] * 1 
    targetBodies42[0] = NXOpen.Body.Null
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies42)
    
    extrudeBuilder11.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder11.Limits.EndExtend.Value.SetFormula("31")
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies43 = [NXOpen.Body.Null] * 1 
    targetBodies43[0] = NXOpen.Body.Null
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies43)
    
    extrudeBuilder11.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder11.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder11.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder11.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder11 = extrudeBuilder11.SmartVolumeProfile
    
    smartVolumeProfileBuilder11.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder11.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId185, "Extrude Dialog")
    
    section11.DistanceTolerance = 0.01
    
    section11.ChainingTolerance = 0.0094999999999999998
    
    section11.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features6 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature6 = feature14
    features6[0] = sketchFeature6
    curveFeatureRule6 = workPart.ScRuleFactory.CreateRuleCurveFeature(features6)
    
    section11.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = curveFeatureRule6
    helpPoint6 = NXOpen.Point3d(58.399999999999871, -115.9999999999997, 11.131907165624341)
    section11.AddToSection(rules6, line20, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId187, None)
    
    direction16 = workPart.Directions.CreateDirection(sketch15, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder11.Direction = direction16
    
    targetBodies44 = [NXOpen.Body.Null] * 1 
    targetBodies44[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies44)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies45 = [NXOpen.Body.Null] * 1 
    targetBodies45[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies45)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId186, None)
    
    scaleAboutPoint415 = NXOpen.Point3d(-96.029132854571685, -54.483474540083449, 0.0)
    viewCenter415 = NXOpen.Point3d(96.029132854571557, 54.483474540083186, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint415, viewCenter415)
    
    scaleAboutPoint416 = NXOpen.Point3d(-76.823306283657345, -43.843928774438858, 0.0)
    viewCenter416 = NXOpen.Point3d(76.823306283657246, 43.843928774438581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint416, viewCenter416)
    
    scaleAboutPoint417 = NXOpen.Point3d(-62.075802968618852, -35.178002676499936, 0.0)
    viewCenter417 = NXOpen.Point3d(62.075802968618753, 35.178002676499652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint417, viewCenter417)
    
    scaleAboutPoint418 = NXOpen.Point3d(-77.72332828195961, -43.972503345624887, 0.0)
    viewCenter418 = NXOpen.Point3d(77.723328281959482, 43.972503345624609, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint418, viewCenter418)
    
    scaleAboutPoint419 = NXOpen.Point3d(-97.15416035244948, -54.965629182031051, 0.0)
    viewCenter419 = NXOpen.Point3d(97.154160352449381, 54.965629182030817, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint419, viewCenter419)
    
    scaleAboutPoint420 = NXOpen.Point3d(-122.24629151047458, -68.707036477538821, 0.0)
    viewCenter420 = NXOpen.Point3d(122.24629151047445, 68.707036477538551, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint420, viewCenter420)
    
    scaleAboutPoint421 = NXOpen.Point3d(-153.56123101613639, -86.637162224966673, 0.0)
    viewCenter421 = NXOpen.Point3d(153.56123101613628, 86.637162224966389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint421, viewCenter421)
    
    scaleAboutPoint422 = NXOpen.Point3d(-192.89324705522446, -108.61035554289298, 0.0)
    viewCenter422 = NXOpen.Point3d(192.89324705522438, 108.61035554289269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint422, viewCenter422)
    
    scaleAboutPoint423 = NXOpen.Point3d(-243.4708295316656, -149.88856870442598, 0.0)
    viewCenter423 = NXOpen.Point3d(243.47082953166534, 149.88856870442564, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint423, viewCenter423)
    
    scaleAboutPoint424 = NXOpen.Point3d(-304.82900997971416, -187.36071088053242, 0.0)
    viewCenter424 = NXOpen.Point3d(304.82900997971393, 187.36071088053205, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint424, viewCenter424)
    
    scaleAboutPoint425 = NXOpen.Point3d(-381.03626247464268, -234.20088860066548, 0.0)
    viewCenter425 = NXOpen.Point3d(381.03626247464246, 234.20088860066511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint425, viewCenter425)
    
    scaleAboutPoint426 = NXOpen.Point3d(-476.29532809330334, -293.51747491510093, 0.0)
    viewCenter426 = NXOpen.Point3d(476.29532809330311, 293.51747491510054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint426, viewCenter426)
    
    scaleAboutPoint427 = NXOpen.Point3d(-381.03626247464263, -234.81397993208068, 0.0)
    viewCenter427 = NXOpen.Point3d(381.03626247464251, 234.8139799320804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint427, viewCenter427)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.94401308858623045
    rotMatrix8.Xy = 0.32590435264471013
    rotMatrix8.Xz = -0.051241013896256189
    rotMatrix8.Yx = -0.16126907418966874
    rotMatrix8.Yy = 0.59135928549684813
    rotMatrix8.Yz = 0.79011801723961672
    rotMatrix8.Zx = 0.28780475028722324
    rotMatrix8.Zy = -0.73761815893040938
    rotMatrix8.Zz = 0.61080919879142292
    translation8 = NXOpen.Point3d(-337.88906078429761, -103.5287640822588, -305.13361705929753)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 0.53944518495011295)
    
    scaleAboutPoint428 = NXOpen.Point3d(-209.6772353440511, -53.461564099418993, 0.0)
    viewCenter428 = NXOpen.Point3d(209.67723534405104, 53.461564099418673, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint428, viewCenter428)
    
    scaleAboutPoint429 = NXOpen.Point3d(-262.09654418006397, -66.826955124273795, 0.0)
    viewCenter429 = NXOpen.Point3d(262.09654418006374, 66.826955124273439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint429, viewCenter429)
    
    scaleAboutPoint430 = NXOpen.Point3d(-327.62068022507992, -83.533693905342162, 0.0)
    viewCenter430 = NXOpen.Point3d(327.6206802250797, 83.533693905341778, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint430, viewCenter430)
    
    scaleAboutPoint431 = NXOpen.Point3d(-406.65198466534036, -105.37507258701413, 0.0)
    viewCenter431 = NXOpen.Point3d(406.65198466534002, 105.37507258701373, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint431, viewCenter431)
    
    scaleAboutPoint432 = NXOpen.Point3d(-509.51242483834596, -136.50861676045008, 0.0)
    viewCenter432 = NXOpen.Point3d(509.51242483834574, 136.50861676044968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint432, viewCenter432)
    
    scaleAboutPoint433 = NXOpen.Point3d(-648.86497111463825, -194.5846510839749, 0.0)
    viewCenter433 = NXOpen.Point3d(648.86497111463802, 194.58465108397439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint433, viewCenter433)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.57408210721027952
    rotMatrix9.Xy = 0.71154442430038223
    rotMatrix9.Xz = -0.40513487436659945
    rotMatrix9.Yx = -0.15750678358638584
    rotMatrix9.Yy = 0.58151852675917615
    rotMatrix9.Yz = 0.79814022336936985
    rotMatrix9.Zx = 0.80350566102876597
    rotMatrix9.Zy = -0.39438653030101328
    rotMatrix9.Zz = 0.44591245487410597
    translation9 = NXOpen.Point3d(-825.57215800702932, -265.61349865460454, -306.40232518170177)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 0.14141231856356248)
    
    scaleAboutPoint434 = NXOpen.Point3d(-957.01970220627913, -435.94445867851999, 0.0)
    viewCenter434 = NXOpen.Point3d(957.01970220627845, 435.94445867851954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint434, viewCenter434)
    
    scaleAboutPoint435 = NXOpen.Point3d(-765.61576176502342, -351.74917695949267, 0.0)
    viewCenter435 = NXOpen.Point3d(765.61576176502285, 351.74917695949244, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint435, viewCenter435)
    
    scaleAboutPoint436 = NXOpen.Point3d(-612.49260941201874, -281.39934156759415, 0.0)
    viewCenter436 = NXOpen.Point3d(612.49260941201828, 281.39934156759398, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint436, viewCenter436)
    
    scaleAboutPoint437 = NXOpen.Point3d(-489.99408752961511, -225.11947325407525, 0.0)
    viewCenter437 = NXOpen.Point3d(489.99408752961449, 225.11947325407507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint437, viewCenter437)
    
    scaleAboutPoint438 = NXOpen.Point3d(-376.66798673830806, -166.30102364641476, 0.0)
    viewCenter438 = NXOpen.Point3d(376.66798673830783, 166.30102364641462, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint438, viewCenter438)
    
    scaleAboutPoint439 = NXOpen.Point3d(-301.33438939064649, -132.42772758571644, 0.0)
    viewCenter439 = NXOpen.Point3d(301.33438939064627, 132.42772758571624, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint439, viewCenter439)
    
    scaleAboutPoint440 = NXOpen.Point3d(-241.06751151251711, -105.94218206857317, 0.0)
    viewCenter440 = NXOpen.Point3d(241.06751151251697, 105.94218206857296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint440, viewCenter440)
    
    scaleAboutPoint441 = NXOpen.Point3d(-192.85400921001371, -84.753745654858605, 0.0)
    viewCenter441 = NXOpen.Point3d(192.85400921001357, 84.753745654858378, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint441, viewCenter441)
    
    scaleAboutPoint442 = NXOpen.Point3d(-136.07684719030058, -29.506859598358236, 0.0)
    viewCenter442 = NXOpen.Point3d(136.0768471903005, 29.506859598358027, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint442, viewCenter442)
    
    scaleAboutPoint443 = NXOpen.Point3d(-108.86147775224052, -23.605487678686607, 0.0)
    viewCenter443 = NXOpen.Point3d(108.86147775224039, 23.605487678686401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint443, viewCenter443)
    
    scaleAboutPoint444 = NXOpen.Point3d(-87.089182201792426, -18.68349237547115, 0.0)
    viewCenter444 = NXOpen.Point3d(87.089182201792283, 18.683492375470934, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint444, viewCenter444)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies46 = [NXOpen.Body.Null] * 1 
    targetBodies46[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies46)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies47 = [NXOpen.Body.Null] * 1 
    targetBodies47[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies47)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies48 = [NXOpen.Body.Null] * 1 
    targetBodies48[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies48)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies49 = [NXOpen.Body.Null] * 1 
    targetBodies49[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies49)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies50 = [NXOpen.Body.Null] * 1 
    targetBodies50[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies50)
    
    direction17 = extrudeBuilder11.Direction
    
    success3 = direction17.ReverseDirection()
    
    extrudeBuilder11.Direction = direction17
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies51 = [NXOpen.Body.Null] * 1 
    targetBodies51[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies51)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies52 = [NXOpen.Body.Null] * 1 
    targetBodies52[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies52)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies53 = [NXOpen.Body.Null] * 1 
    targetBodies53[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies53)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies54 = [NXOpen.Body.Null] * 1 
    targetBodies54[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies54)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies55 = [NXOpen.Body.Null] * 1 
    targetBodies55[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies55)
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies56 = [NXOpen.Body.Null] * 1 
    targetBodies56[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies56)
    
    extrudeBuilder11.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder11.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies57 = [NXOpen.Body.Null] * 1 
    targetBodies57[0] = body1
    extrudeBuilder11.BooleanOperation.SetTargetBodies(targetBodies57)
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder11.ParentFeatureInternal = False
    
    feature15 = extrudeBuilder11.CommitFeature()
    
    theSession.DeleteUndoMark(markId188, None)
    
    theSession.SetUndoMarkName(markId185, "Extrude")
    
    expression93 = extrudeBuilder11.Limits.StartExtend.Value
    expression94 = extrudeBuilder11.Limits.EndExtend.Value
    extrudeBuilder11.Destroy()
    
    workPart.Expressions.Delete(expression91)
    
    workPart.Expressions.Delete(expression92)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder12 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section12 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder12.Section = section12
    
    extrudeBuilder12.AllowSelfIntersectingSection(True)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder12.DistanceTolerance = 0.01
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies58 = [NXOpen.Body.Null] * 1 
    targetBodies58[0] = NXOpen.Body.Null
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies58)
    
    extrudeBuilder12.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder12.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder12.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies59 = [NXOpen.Body.Null] * 1 
    targetBodies59[0] = NXOpen.Body.Null
    extrudeBuilder12.BooleanOperation.SetTargetBodies(targetBodies59)
    
    extrudeBuilder12.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder12.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder12.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder12.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder12 = extrudeBuilder12.SmartVolumeProfile
    
    smartVolumeProfileBuilder12.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder12.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId189, "Extrude Dialog")
    
    section12.DistanceTolerance = 0.01
    
    section12.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section12.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder12.Destroy()
    
    section12.Destroy()
    
    workPart.Expressions.Delete(expression95)
    
    theSession.UndoToMark(markId189, None)
    
    theSession.DeleteUndoMark(markId189, None)
    
    scaleAboutPoint445 = NXOpen.Point3d(82.046648238089901, 37.286625643950671, 0.0)
    viewCenter445 = NXOpen.Point3d(-82.046648238090057, -37.286625643950899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint445, viewCenter445)
    
    scaleAboutPoint446 = NXOpen.Point3d(65.123020305727778, 29.186427659230318, 0.0)
    viewCenter446 = NXOpen.Point3d(-65.123020305727906, -29.186427659230542, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint446, viewCenter446)
    
    scaleAboutPoint447 = NXOpen.Point3d(51.789837273735699, 23.14342281348658, 0.0)
    viewCenter447 = NXOpen.Point3d(-51.789837273735834, -23.143422813486801, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint447, viewCenter447)
    
    scaleAboutPoint448 = NXOpen.Point3d(31.557342751900851, 22.629124528742423, 0.0)
    viewCenter448 = NXOpen.Point3d(-31.557342751901015, -22.629124528742654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint448, viewCenter448)
    
    scaleAboutPoint449 = NXOpen.Point3d(24.982553479731671, 18.169129803441166, 0.0)
    viewCenter449 = NXOpen.Point3d(-24.982553479731834, -18.169129803441393, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint449, viewCenter449)
    
    scaleAboutPoint450 = NXOpen.Point3d(19.828050350711958, 14.535303842752919, 0.0)
    viewCenter450 = NXOpen.Point3d(-19.82805035071209, -14.535303842753144, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint450, viewCenter450)
    
    scaleAboutPoint451 = NXOpen.Point3d(14.935551339872244, 11.712505705174786, 0.0)
    viewCenter451 = NXOpen.Point3d(-14.935551339872385, -11.712505705175019, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint451, viewCenter451)
    
    scaleAboutPoint452 = NXOpen.Point3d(18.66943917484031, 14.640632131468514, 0.0)
    viewCenter452 = NXOpen.Point3d(-18.669439174840459, -14.64063213146874, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint452, viewCenter452)
    
    scaleAboutPoint453 = NXOpen.Point3d(23.336798968550394, 18.300790164335666, 0.0)
    viewCenter453 = NXOpen.Point3d(-23.336798968550546, -18.300790164335893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint453, viewCenter453)
    
    scaleAboutPoint454 = NXOpen.Point3d(29.170998710688046, 22.875987705419625, 0.0)
    viewCenter454 = NXOpen.Point3d(-29.170998710688188, -22.875987705419849, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint454, viewCenter454)
    
    scaleAboutPoint455 = NXOpen.Point3d(35.949450103615924, 28.800703945672204, 0.0)
    viewCenter455 = NXOpen.Point3d(-35.949450103616066, -28.800703945672431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint455, viewCenter455)
    
    scaleAboutPoint456 = NXOpen.Point3d(44.936812629519892, 36.000879932090278, 0.0)
    viewCenter456 = NXOpen.Point3d(-44.936812629520063, -36.000879932090513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint456, viewCenter456)
    
    scaleAboutPoint457 = NXOpen.Point3d(56.171015786899879, 45.001099915112867, 0.0)
    viewCenter457 = NXOpen.Point3d(-56.171015786900057, -45.001099915113109, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint457, viewCenter457)
    
    scaleAboutPoint458 = NXOpen.Point3d(70.213769733624815, 56.251374893891104, 0.0)
    viewCenter458 = NXOpen.Point3d(-70.213769733625085, -56.251374893891352, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint458, viewCenter458)
    
    scaleAboutPoint459 = NXOpen.Point3d(87.76721216703109, 70.314218617363906, 0.0)
    viewCenter459 = NXOpen.Point3d(-87.767212167031275, -70.314218617364133, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint459, viewCenter459)
    
    scaleAboutPoint460 = NXOpen.Point3d(109.7090152087889, 87.892773271704925, 0.0)
    viewCenter460 = NXOpen.Point3d(-109.70901520878905, -87.892773271705153, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint460, viewCenter460)
    
    scaleAboutPoint461 = NXOpen.Point3d(137.13626901098601, 109.86596658963114, 0.0)
    viewCenter461 = NXOpen.Point3d(-137.13626901098621, -109.86596658963137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint461, viewCenter461)
    
    scaleAboutPoint462 = NXOpen.Point3d(171.42033626373257, 137.33245823703891, 0.0)
    viewCenter462 = NXOpen.Point3d(-171.42033626373276, -137.33245823703916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint462, viewCenter462)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = -0.45859162434634704
    rotMatrix10.Xy = 0.49136671514594732
    rotMatrix10.Xz = -0.74044072911074998
    rotMatrix10.Yx = -0.88817399751332526
    rotMatrix10.Yy = -0.28062368001405896
    rotMatrix10.Yz = 0.36386439830871598
    rotMatrix10.Zx = -0.028994348079840755
    rotMatrix10.Zy = 0.82450536775817707
    rotMatrix10.Zz = 0.565110808883865
    translation10 = NXOpen.Point3d(232.67843339259608, 242.45590082154612, -187.19275725695138)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 0.43155614796009112)
    
    scaleAboutPoint463 = NXOpen.Point3d(116.7938986346246, 162.46920282506838, 0.0)
    viewCenter463 = NXOpen.Point3d(-116.7938986346248, -162.46920282506863, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint463, viewCenter463)
    
    scaleAboutPoint464 = NXOpen.Point3d(145.99237329328074, 204.61923185987385, 0.0)
    viewCenter464 = NXOpen.Point3d(-145.99237329328099, -204.61923185987411, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint464, viewCenter464)
    
    scaleAboutPoint465 = NXOpen.Point3d(91.484722109634461, 354.44342597450071, 0.0)
    viewCenter465 = NXOpen.Point3d(-91.484722109634774, -354.44342597450094, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint465, viewCenter465)
    
    scaleAboutPoint466 = NXOpen.Point3d(73.187777687707452, 283.55474077960054, 0.0)
    viewCenter466 = NXOpen.Point3d(-73.18777768770795, -283.55474077960076, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint466, viewCenter466)
    
    scaleAboutPoint467 = NXOpen.Point3d(61.61567880724273, 229.29615794934179, 0.0)
    viewCenter467 = NXOpen.Point3d(-61.615678807243135, -229.29615794934205, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint467, viewCenter467)
    
    scaleAboutPoint468 = NXOpen.Point3d(205.75345082299216, 56.894875555344612, 0.0)
    viewCenter468 = NXOpen.Point3d(-205.75345082299265, -56.894875555344854, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint468, viewCenter468)
    
    scaleAboutPoint469 = NXOpen.Point3d(164.60276065839378, 45.515900444275665, 0.0)
    viewCenter469 = NXOpen.Point3d(-164.60276065839415, -45.515900444275893, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint469, viewCenter469)
    
    scaleAboutPoint470 = NXOpen.Point3d(131.68220852671496, 36.412720355420532, 0.0)
    viewCenter470 = NXOpen.Point3d(-131.68220852671539, -36.412720355420767, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint470, viewCenter470)
    
    scaleAboutPoint471 = NXOpen.Point3d(105.34576682137191, 29.130176284336383, 0.0)
    viewCenter471 = NXOpen.Point3d(-105.34576682137234, -29.130176284336631, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint471, viewCenter471)
    
    scaleAboutPoint472 = NXOpen.Point3d(84.276613457097497, 23.30414102746909, 0.0)
    viewCenter472 = NXOpen.Point3d(-84.276613457097895, -23.304141027469321, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint472, viewCenter472)
    
    scaleAboutPoint473 = NXOpen.Point3d(67.421290765677981, 18.643312821975261, 0.0)
    viewCenter473 = NXOpen.Point3d(-67.42129076567835, -18.643312821975474, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint473, viewCenter473)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal23 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin23, normal23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.PlaneReference = plane23
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression97 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder9 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder9.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId190, "Create Sketch Dialog")
    
    scalar14 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge15 = extrude3.FindObject("EDGE * 130 * 180 {(115.9,-54,25)(112.9,-54,25)(109.9,-54,25) EXTRUDE(2)}")
    point81 = workPart.Points.CreatePoint(edge15, scalar14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge16 = extrude3.FindObject("EDGE * 180 * 190 {(109.9,-54,25)(109.9,-54,15)(109.9,-54,5) EXTRUDE(2)}")
    direction18 = workPart.Directions.CreateDirection(edge16, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face5 = extrude3.FindObject("FACE 180 {(112.9,-54,15) EXTRUDE(2)}")
    xform9 = workPart.Xforms.CreateXformByPlaneXDirPoint(face5, direction18, point81, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem9 = workPart.CoordinateSystems.CreateCoordinateSystem(xform9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem9
    
    origin24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal24 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin24, normal24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane24.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom20 = [NXOpen.NXObject.Null] * 1 
    geom20[0] = face5
    plane24.SetGeometry(geom20)
    
    plane24.SetFlip(False)
    
    plane24.SetExpression(None)
    
    plane24.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane24.Evaluate()
    
    origin25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal25 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane25 = workPart.Planes.CreatePlane(origin25, normal25, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane25.SynchronizeToPlane(plane24)
    
    scalar15 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point82 = workPart.Points.CreatePoint(edge15, scalar15, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane25.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom21 = [NXOpen.NXObject.Null] * 1 
    geom21[0] = face5
    plane25.SetGeometry(geom21)
    
    plane25.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane25.Evaluate()
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId191, None)
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject32 = sketchInPlaceBuilder10.Commit()
    
    sketch16 = nXObject32
    feature16 = sketch16.Feature
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId193)
    
    sketch16.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId192, None)
    
    theSession.SetUndoMarkName(markId190, "Create Sketch")
    
    sketchInPlaceBuilder10.Destroy()
    
    sketchAlongPathBuilder9.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression97)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point82)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression96)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane23.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression99)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression98)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane25.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint474 = NXOpen.Point3d(9.4502309821735366, 2.4429168525345886, 0.0)
    viewCenter474 = NXOpen.Point3d(-9.4502309821739292, -2.4429168525348222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint474, viewCenter474)
    
    scaleAboutPoint475 = NXOpen.Point3d(11.009197657804215, 3.0536460656682753, 0.0)
    viewCenter475 = NXOpen.Point3d(-11.009197657804586, -3.0536460656684876, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint475, viewCenter475)
    
    scaleAboutPoint476 = NXOpen.Point3d(12.757008234864418, 3.8170575820853596, 0.0)
    viewCenter476 = NXOpen.Point3d(-12.757008234864816, -3.817057582085575, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint476, viewCenter476)
    
    scaleAboutPoint477 = NXOpen.Point3d(14.690649246841922, 5.022444186954468, 0.0)
    viewCenter477 = NXOpen.Point3d(-14.690649246842337, -5.022444186954675, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint477, viewCenter477)
    
    scaleAboutPoint478 = NXOpen.Point3d(18.363311558552454, 6.2780552336931352, 0.0)
    viewCenter478 = NXOpen.Point3d(-18.363311558552866, -6.2780552336933173, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint478, viewCenter478)
    
    scaleAboutPoint479 = NXOpen.Point3d(22.954139448190624, 7.8475690421163851, 0.0)
    viewCenter479 = NXOpen.Point3d(-22.954139448191015, -7.8475690421166124, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint479, viewCenter479)
    
    scaleAboutPoint480 = NXOpen.Point3d(36.049770287222593, 2.4523653256613298, 0.0)
    viewCenter480 = NXOpen.Point3d(-36.04977028722292, -2.4523653256614919, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint480, viewCenter480)
    
    scaleAboutPoint481 = NXOpen.Point3d(28.839816229778013, 1.9618922605290641, 0.0)
    viewCenter481 = NXOpen.Point3d(-28.8398162297784, -1.9618922605292259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint481, viewCenter481)
    
    scaleAboutPoint482 = NXOpen.Point3d(23.071852983822357, 1.5695138084231992, 0.0)
    viewCenter482 = NXOpen.Point3d(-23.071852983822719, -1.5695138084233806, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint482, viewCenter482)
    
    scaleAboutPoint483 = NXOpen.Point3d(18.457482387057887, 1.2556110467385388, 0.0)
    viewCenter483 = NXOpen.Point3d(-18.457482387058217, -1.255611046738746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint483, viewCenter483)
    
    scaleAboutPoint484 = NXOpen.Point3d(14.765985909646277, 1.0044888373907979, 0.0)
    viewCenter484 = NXOpen.Point3d(-14.765985909646609, -1.0044888373910301, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint484, viewCenter484)
    
    scaleAboutPoint485 = NXOpen.Point3d(11.812788727716995, 0.80359106991259854, 0.0)
    viewCenter485 = NXOpen.Point3d(-11.812788727717313, -0.80359106991285056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint485, viewCenter485)
    
    scaleAboutPoint486 = NXOpen.Point3d(9.4502309821735739, 0.64287285593004695, 0.0)
    viewCenter486 = NXOpen.Point3d(-9.4502309821738812, -0.64287285593032295, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint486, viewCenter486)
    
    scaleAboutPoint487 = NXOpen.Point3d(7.5601847857388265, 0.51429828474400363, 0.0)
    viewCenter487 = NXOpen.Point3d(-7.560184785739132, -0.51429828474429229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint487, viewCenter487)
    
    scaleAboutPoint488 = NXOpen.Point3d(4.3201055918506945, 3.8675231012758697, 0.0)
    viewCenter488 = NXOpen.Point3d(-4.3201055918510001, -3.8675231012761211, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint488, viewCenter488)
    
    scaleAboutPoint489 = NXOpen.Point3d(3.2585939321387523, 3.2915090223624386, 0.0)
    viewCenter489 = NXOpen.Point3d(-3.2585939321390787, -3.2915090223626509, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint489, viewCenter489)
    
    scaleAboutPoint490 = NXOpen.Point3d(2.5542110013531731, 2.6858713622477248, 0.0)
    viewCenter490 = NXOpen.Point3d(-2.5542110013535124, -2.6858713622479513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint490, viewCenter490)
    
    scaleAboutPoint491 = NXOpen.Point3d(1.9591061701100128, 2.2750910362568764, 0.0)
    viewCenter491 = NXOpen.Point3d(-1.9591061701103605, -2.2750910362571024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint491, viewCenter491)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId195, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(112.69999999999999, -54.000000000000014, 23.099999999999998)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 1.3922754471189234, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = arc3
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(112.3178324768492, -54.000000000000014, 23.099999999999998)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_13, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension13 = sketchDimensionalConstraint13.AssociatedDimension
    
    expression100 = sketchDimensionalConstraint13.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder35 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines181 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBefore(lines181)
    
    lines182 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAfter(lines182)
    
    lines183 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAbove(lines183)
    
    lines184 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBelow(lines184)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder35.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines185 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBefore(lines185)
    
    lines186 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAfter(lines186)
    
    lines187 = []
    sketchRapidDimensionBuilder35.AppendedText.SetAbove(lines187)
    
    lines188 = []
    sketchRapidDimensionBuilder35.AppendedText.SetBelow(lines188)
    
    theSession.SetUndoMarkName(markId196, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder35.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits981 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits982 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits983 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits984 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits985 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits986 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits987 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits988 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits989 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits990 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder35.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits991 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits992 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits993 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits994 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits995 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits996 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits997 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits998 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits999 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1000 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    point1_115 = NXOpen.Point3d(112.69999999999999, -54.000000000000014, 23.099999999999998)
    point2_115 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_115, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_115)
    
    point1_116 = NXOpen.Point3d(112.69999999999999, -54.000000000000014, 23.099999999999998)
    point2_116 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_116, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_116)
    
    point1_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_117 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder35.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_117, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_117)
    
    dimensionlinearunits1001 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1002 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1003 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1004 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1005 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1006 = sketchRapidDimensionBuilder35.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin23 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin23.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin23.View = NXOpen.View.Null
    assocOrigin23.ViewOfGeometry = workPart.ModelingViews.WorkView
    point83 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin23.PointOnGeometry = point83
    assocOrigin23.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.DimensionLine = 0
    assocOrigin23.AssociatedView = NXOpen.View.Null
    assocOrigin23.AssociatedPoint = NXOpen.Point.Null
    assocOrigin23.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin23.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin23.XOffsetFactor = 0.0
    assocOrigin23.YOffsetFactor = 0.0
    assocOrigin23.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder35.Origin.SetAssociativeOrigin(assocOrigin23)
    
    point84 = NXOpen.Point3d(107.32671419293395, -54.000000000000014, 19.183502663981649)
    sketchRapidDimensionBuilder35.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point84)
    
    sketchRapidDimensionBuilder35.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder35.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder35.Style.DimensionStyle.TextCentered = False
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject33 = sketchRapidDimensionBuilder35.Commit()
    
    theSession.DeleteUndoMark(markId197, None)
    
    theSession.SetUndoMarkName(markId196, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder35.Destroy()
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder36 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines189 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBefore(lines189)
    
    lines190 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAfter(lines190)
    
    lines191 = []
    sketchRapidDimensionBuilder36.AppendedText.SetAbove(lines191)
    
    lines192 = []
    sketchRapidDimensionBuilder36.AppendedText.SetBelow(lines192)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder36.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId198, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder36.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1007 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1008 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1009 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1010 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1011 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1012 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1013 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1014 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1015 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1016 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder36.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1017 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1018 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1019 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1020 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1021 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1022 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1023 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1024 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1025 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1026 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    expression101 = workPart.Expressions.FindObject("p40")
    expression101.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId198, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(1.0773730177479135)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId199, None)
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId198, "Edit Driving Value")
    
    point1_118 = NXOpen.Point3d(112.45240634320666, -54.000000000000014, 22.952991266278961)
    point2_118 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_118, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_118)
    
    point1_119 = NXOpen.Point3d(112.45240634320666, -54.000000000000014, 22.952991266278961)
    point2_119 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_119, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_119)
    
    point1_120 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_120 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_120, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_120)
    
    dimensionlinearunits1027 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1028 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1029 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1030 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1031 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1032 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    point85 = NXOpen.Point3d(109.89999999999999, -54.000000000000014, 22.351777588546945)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(edge16, workPart.ModelingViews.WorkView, point85)
    
    point1_121 = NXOpen.Point3d(109.89999999999999, -54.000000000000014, 22.351777588546945)
    point2_121 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge16, workPart.ModelingViews.WorkView, point1_121, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_121)
    
    point1_122 = NXOpen.Point3d(112.45240634320666, -54.000000000000014, 22.952991266278961)
    point2_122 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_122, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_122)
    
    point1_123 = NXOpen.Point3d(109.89999999999999, -54.000000000000014, 22.351777588546945)
    point2_123 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge16, workPart.ModelingViews.WorkView, point1_123, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_123)
    
    point1_124 = NXOpen.Point3d(112.45240634320666, -54.000000000000014, 22.952991266278961)
    point2_124 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder36.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_124, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_124)
    
    dimensionlinearunits1033 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1034 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1035 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1036 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1037 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1038 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1039 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1040 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1041 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1042 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1043 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1044 = sketchRapidDimensionBuilder36.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin24 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin24.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin24.View = NXOpen.View.Null
    assocOrigin24.ViewOfGeometry = workPart.ModelingViews.WorkView
    point86 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin24.PointOnGeometry = point86
    assocOrigin24.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.DimensionLine = 0
    assocOrigin24.AssociatedView = NXOpen.View.Null
    assocOrigin24.AssociatedPoint = NXOpen.Point.Null
    assocOrigin24.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin24.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin24.XOffsetFactor = 0.0
    assocOrigin24.YOffsetFactor = 0.0
    assocOrigin24.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder36.Origin.SetAssociativeOrigin(assocOrigin24)
    
    point87 = NXOpen.Point3d(110.86574469377817, -54.000000000000014, 29.90170932368126)
    sketchRapidDimensionBuilder36.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point87)
    
    sketchRapidDimensionBuilder36.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder36.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder36.Style.DimensionStyle.TextCentered = False
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject34 = sketchRapidDimensionBuilder36.Commit()
    
    theSession.DeleteUndoMark(markId201, None)
    
    theSession.SetUndoMarkName(markId200, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder36.Destroy()
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder37 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines193 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBefore(lines193)
    
    lines194 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAfter(lines194)
    
    lines195 = []
    sketchRapidDimensionBuilder37.AppendedText.SetAbove(lines195)
    
    lines196 = []
    sketchRapidDimensionBuilder37.AppendedText.SetBelow(lines196)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder37.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId202, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder37.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1045 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1046 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1047 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1048 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1049 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1050 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1051 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1052 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1053 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1054 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder37.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1055 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1056 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1057 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1058 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1059 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1060 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1061 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1062 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1063 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1064 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    expression102 = workPart.Expressions.FindObject("p41")
    expression102.SetFormula("3")
    
    theSession.SetUndoMarkVisibility(markId202, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId203, None)
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId202, "Edit Driving Value")
    
    point1_125 = NXOpen.Point3d(112.89999999999999, -54.000000000000014, 22.952991266278961)
    point2_125 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_125, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_125)
    
    point1_126 = NXOpen.Point3d(112.89999999999999, -54.000000000000014, 22.952991266278961)
    point2_126 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_126, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_126)
    
    point1_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_127 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_127, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_127)
    
    dimensionlinearunits1065 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1066 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1067 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1068 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1069 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1070 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point88 = NXOpen.Point3d(112.13644701547841, -54.000000000000014, 25.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(perpendicularDimension3, workPart.ModelingViews.WorkView, point88)
    
    line23 = theSession.ActiveSketch.FindObject("Curve DATUM14")
    point1_128 = NXOpen.Point3d(101.61249999999998, -54.000000000000014, 25.0)
    point2_128 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, NXOpen.View.Null, point1_128, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_128)
    
    point1_129 = NXOpen.Point3d(112.89999999999999, -54.000000000000014, 22.952991266278961)
    point2_129 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_129, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_129)
    
    point1_130 = NXOpen.Point3d(101.61249999999998, -54.000000000000014, 25.0)
    point2_130 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line23, workPart.ModelingViews.WorkView, point1_130, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_130)
    
    point1_131 = NXOpen.Point3d(112.89999999999999, -54.000000000000014, 22.952991266278961)
    point2_131 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder37.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_131, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_131)
    
    dimensionlinearunits1071 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1072 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1073 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1074 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1075 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1076 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1077 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1078 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1079 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1080 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1081 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1082 = sketchRapidDimensionBuilder37.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin25 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin25.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin25.View = NXOpen.View.Null
    assocOrigin25.ViewOfGeometry = workPart.ModelingViews.WorkView
    point89 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin25.PointOnGeometry = point89
    assocOrigin25.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.DimensionLine = 0
    assocOrigin25.AssociatedView = NXOpen.View.Null
    assocOrigin25.AssociatedPoint = NXOpen.Point.Null
    assocOrigin25.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin25.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin25.XOffsetFactor = 0.0
    assocOrigin25.YOffsetFactor = 0.0
    assocOrigin25.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder37.Origin.SetAssociativeOrigin(assocOrigin25)
    
    point90 = NXOpen.Point3d(121.68506651064475, -54.000000000000014, 23.767389788884628)
    sketchRapidDimensionBuilder37.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point90)
    
    sketchRapidDimensionBuilder37.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder37.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder37.Style.DimensionStyle.TextCentered = False
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject35 = sketchRapidDimensionBuilder37.Commit()
    
    theSession.DeleteUndoMark(markId205, None)
    
    theSession.SetUndoMarkName(markId204, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId204, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder37.Destroy()
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder38 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines197 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBefore(lines197)
    
    lines198 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAfter(lines198)
    
    lines199 = []
    sketchRapidDimensionBuilder38.AppendedText.SetAbove(lines199)
    
    lines200 = []
    sketchRapidDimensionBuilder38.AppendedText.SetBelow(lines200)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder38.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId206, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder38.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1083 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1084 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1085 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1086 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1087 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1088 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1089 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1090 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1091 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1092 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder38.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder38.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder38.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1093 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1094 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1095 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1096 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1097 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1098 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1099 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1100 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1101 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1102 = sketchRapidDimensionBuilder38.Style.UnitsStyle.DimensionLinearUnits
    
    expression103 = workPart.Expressions.FindObject("p42")
    expression103.SetFormula("4")
    
    theSession.SetUndoMarkVisibility(markId206, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId207, None)
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId206, "Edit Driving Value")
    
    sketchRapidDimensionBuilder38.Destroy()
    
    theSession.UndoToMark(markId208, None)
    
    theSession.DeleteUndoMark(markId208, None)
    
    sketchRapidDimensionBuilder38.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch17 = theSession.ActiveSketch
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder13 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section13 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder13.Section = section13
    
    extrudeBuilder13.AllowSelfIntersectingSection(True)
    
    expression104 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder13.DistanceTolerance = 0.01
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies60 = [NXOpen.Body.Null] * 1 
    targetBodies60[0] = NXOpen.Body.Null
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies60)
    
    extrudeBuilder13.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies61 = [NXOpen.Body.Null] * 1 
    targetBodies61[0] = NXOpen.Body.Null
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies61)
    
    extrudeBuilder13.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder13.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder13.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder13.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder13 = extrudeBuilder13.SmartVolumeProfile
    
    smartVolumeProfileBuilder13.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder13.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId210, "Extrude Dialog")
    
    section13.DistanceTolerance = 0.01
    
    section13.ChainingTolerance = 0.0094999999999999998
    
    section13.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features7 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature7 = feature16
    features7[0] = sketchFeature7
    curveFeatureRule7 = workPart.ScRuleFactory.CreateRuleCurveFeature(features7)
    
    section13.AllowSelfIntersection(True)
    
    rules7 = [None] * 1 
    rules7[0] = curveFeatureRule7
    helpPoint7 = NXOpen.Point3d(113.83437677011908, -54.000000000000014, 19.834958756408952)
    section13.AddToSection(rules7, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId212, None)
    
    direction19 = workPart.Directions.CreateDirection(sketch17, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder13.Direction = direction19
    
    targetBodies62 = [NXOpen.Body.Null] * 1 
    targetBodies62[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies62)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies63 = [NXOpen.Body.Null] * 1 
    targetBodies63[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies63)
    
    expression105 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId211, None)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies64 = [NXOpen.Body.Null] * 1 
    targetBodies64[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies64)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies65 = [NXOpen.Body.Null] * 1 
    targetBodies65[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies65)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies66 = [NXOpen.Body.Null] * 1 
    targetBodies66[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies66)
    
    direction20 = extrudeBuilder13.Direction
    
    success4 = direction20.ReverseDirection()
    
    extrudeBuilder13.Direction = direction20
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies67 = [NXOpen.Body.Null] * 1 
    targetBodies67[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies67)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies68 = [NXOpen.Body.Null] * 1 
    targetBodies68[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies68)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies69 = [NXOpen.Body.Null] * 1 
    targetBodies69[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies69)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies70 = [NXOpen.Body.Null] * 1 
    targetBodies70[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies70)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies71 = [NXOpen.Body.Null] * 1 
    targetBodies71[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies71)
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies72 = [NXOpen.Body.Null] * 1 
    targetBodies72[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies72)
    
    extrudeBuilder13.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder13.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies73 = [NXOpen.Body.Null] * 1 
    targetBodies73[0] = body1
    extrudeBuilder13.BooleanOperation.SetTargetBodies(targetBodies73)
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder13.ParentFeatureInternal = False
    
    feature17 = extrudeBuilder13.CommitFeature()
    
    theSession.DeleteUndoMark(markId213, None)
    
    theSession.SetUndoMarkName(markId210, "Extrude")
    
    expression106 = extrudeBuilder13.Limits.StartExtend.Value
    expression107 = extrudeBuilder13.Limits.EndExtend.Value
    extrudeBuilder13.Destroy()
    
    workPart.Expressions.Delete(expression104)
    
    workPart.Expressions.Delete(expression105)
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder14 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section14 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder14.Section = section14
    
    extrudeBuilder14.AllowSelfIntersectingSection(True)
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder14.DistanceTolerance = 0.01
    
    extrudeBuilder14.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies74 = [NXOpen.Body.Null] * 1 
    targetBodies74[0] = NXOpen.Body.Null
    extrudeBuilder14.BooleanOperation.SetTargetBodies(targetBodies74)
    
    extrudeBuilder14.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder14.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder14.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies75 = [NXOpen.Body.Null] * 1 
    targetBodies75[0] = NXOpen.Body.Null
    extrudeBuilder14.BooleanOperation.SetTargetBodies(targetBodies75)
    
    extrudeBuilder14.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder14.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder14.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder14.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder14 = extrudeBuilder14.SmartVolumeProfile
    
    smartVolumeProfileBuilder14.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder14.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId214, "Extrude Dialog")
    
    section14.DistanceTolerance = 0.01
    
    section14.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section14.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder14.Destroy()
    
    section14.Destroy()
    
    workPart.Expressions.Delete(expression108)
    
    theSession.UndoToMark(markId214, None)
    
    theSession.DeleteUndoMark(markId214, None)
    
    scaleAboutPoint492 = NXOpen.Point3d(8.9359326974293722, 18.257589108417143, 0.0)
    viewCenter492 = NXOpen.Point3d(-8.9359326974297648, -18.257589108417378, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint492, viewCenter492)
    
    scaleAboutPoint493 = NXOpen.Point3d(7.1487461579434646, 14.606071286733691, 0.0)
    viewCenter493 = NXOpen.Point3d(-7.1487461579438714, -14.606071286733929, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint493, viewCenter493)
    
    scaleAboutPoint494 = NXOpen.Point3d(5.7189969263547153, 11.684857029386929, 0.0)
    viewCenter494 = NXOpen.Point3d(-5.718996926355123, -11.684857029387167, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint494, viewCenter494)
    
    scaleAboutPoint495 = NXOpen.Point3d(4.57519754108373, 9.3478856235095229, 0.0)
    viewCenter495 = NXOpen.Point3d(-4.575197541084143, -9.3478856235097521, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint495, viewCenter495)
    
    scaleAboutPoint496 = NXOpen.Point3d(3.6601580328669501, 7.5836367875231998, 0.0)
    viewCenter496 = NXOpen.Point3d(-3.6601580328673542, -7.5836367875234254, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint496, viewCenter496)
    
    scaleAboutPoint497 = NXOpen.Point3d(4.5751975410837193, 9.4795459844040248, 0.0)
    viewCenter497 = NXOpen.Point3d(-4.5751975410841323, -9.4795459844042522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint497, viewCenter497)
    
    scaleAboutPoint498 = NXOpen.Point3d(5.7189969263547047, 11.849432480505069, 0.0)
    viewCenter498 = NXOpen.Point3d(-5.7189969263551461, -11.849432480505293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint498, viewCenter498)
    
    scaleAboutPoint499 = NXOpen.Point3d(7.1487461579434299, 14.81179060063134, 0.0)
    viewCenter499 = NXOpen.Point3d(-7.1487461579438971, -14.811790600631594, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint499, viewCenter499)
    
    scaleAboutPoint500 = NXOpen.Point3d(8.9359326974293278, 18.514738250789215, 0.0)
    viewCenter500 = NXOpen.Point3d(-8.935932697429795, -18.514738250789435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint500, viewCenter500)
    
    scaleAboutPoint501 = NXOpen.Point3d(13.580689081524906, 30.054306014736053, 0.0)
    viewCenter501 = NXOpen.Point3d(-13.580689081525383, -30.054306014736238, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint501, viewCenter501)
    
    scaleAboutPoint502 = NXOpen.Point3d(16.975861351906197, 37.56788251842007, 0.0)
    viewCenter502 = NXOpen.Point3d(-16.975861351906659, -37.567882518420269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint502, viewCenter502)
    
    scaleAboutPoint503 = NXOpen.Point3d(21.219826689882826, 46.959853148025111, 0.0)
    viewCenter503 = NXOpen.Point3d(-21.219826689883281, -46.959853148025296, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint503, viewCenter503)
    
    scaleAboutPoint504 = NXOpen.Point3d(26.524783362353531, 59.013719196716103, 0.0)
    viewCenter504 = NXOpen.Point3d(-26.524783362353997, -59.013719196716288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint504, viewCenter504)
    
    scaleAboutPoint505 = NXOpen.Point3d(33.155979202941978, 76.513798160635943, 0.0)
    viewCenter505 = NXOpen.Point3d(-33.155979202942497, -76.5137981606361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint505, viewCenter505)
    
    scaleAboutPoint506 = NXOpen.Point3d(48.802069980661784, 133.40867371598063, 0.0)
    viewCenter506 = NXOpen.Point3d(-48.802069980662267, -133.4086737159808, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint506, viewCenter506)
    
    scaleAboutPoint507 = NXOpen.Point3d(61.002587475827333, 166.76084214497587, 0.0)
    viewCenter507 = NXOpen.Point3d(-61.002587475827738, -166.76084214497595, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint507, viewCenter507)
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = -0.19324600166451197
    rotMatrix11.Xy = 0.86690900763851586
    rotMatrix11.Xz = -0.45948313931621143
    rotMatrix11.Yx = -0.45491238968825376
    rotMatrix11.Yy = 0.33576499087773204
    rotMatrix11.Yz = 0.8248130628263578
    rotMatrix11.Zx = 0.86931622586306179
    rotMatrix11.Zy = 0.36841639943965343
    rotMatrix11.Zz = 0.32948240632106801
    translation11 = NXOpen.Point3d(156.33105842415972, 257.14598558273468, -260.79880670934597)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 0.34524491836807308)
    
    scaleAboutPoint508 = NXOpen.Point3d(109.20689340835943, 213.04923766683493, 0.0)
    viewCenter508 = NXOpen.Point3d(-109.20689340835995, -213.04923766683507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint508, viewCenter508)
    
    scaleAboutPoint509 = NXOpen.Point3d(87.365514726687437, 170.43939013346787, 0.0)
    viewCenter509 = NXOpen.Point3d(-87.365514726687948, -170.43939013346804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint509, viewCenter509)
    
    scaleAboutPoint510 = NXOpen.Point3d(69.892411781349949, 136.35151210677435, 0.0)
    viewCenter510 = NXOpen.Point3d(-69.892411781350447, -136.35151210677446, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint510, viewCenter510)
    
    scaleAboutPoint511 = NXOpen.Point3d(41.395926697164398, 110.25834504173694, 0.0)
    viewCenter511 = NXOpen.Point3d(-41.395926697164782, -110.25834504173709, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint511, viewCenter511)
    
    scaleAboutPoint512 = NXOpen.Point3d(33.116741357731463, 88.206676033389556, 0.0)
    viewCenter512 = NXOpen.Point3d(-33.116741357731826, -88.206676033389684, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint512, viewCenter512)
    
    scaleAboutPoint513 = NXOpen.Point3d(26.242270876837395, 70.565340826711633, 0.0)
    viewCenter513 = NXOpen.Point3d(-26.242270876837768, -70.565340826711761, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint513, viewCenter513)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder11 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal26 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane26 = workPart.Planes.CreatePlane(origin26, normal26, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.PlaneReference = plane26
    
    expression109 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression110 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder10 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder10.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId215, "Create Sketch Dialog")
    
    scalar16 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge17 = extrude3.FindObject("EDGE * 170 * 180 {(115.9,-54,25)(115.9,-54,15)(115.9,-54,5) EXTRUDE(2)}")
    point91 = workPart.Points.CreatePoint(edge17, scalar16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge18 = extrude3.FindObject("EDGE * 170 EXTRUDE(2) 140 {(115.9,-59.9,5)(115.9,-56.95,5)(115.9,-54,5) EXTRUDE(2)}")
    direction21 = workPart.Directions.CreateDirection(edge18, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face6 = extrude3.FindObject("FACE 170 {(115.9,-56.95,15) EXTRUDE(2)}")
    xform10 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction21, point91, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem10 = workPart.CoordinateSystems.CreateCoordinateSystem(xform10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.Csystem = cartesianCoordinateSystem10
    
    origin27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal27 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane27 = workPart.Planes.CreatePlane(origin27, normal27, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane27.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom22 = [NXOpen.NXObject.Null] * 1 
    geom22[0] = face6
    plane27.SetGeometry(geom22)
    
    plane27.SetFlip(False)
    
    plane27.SetExpression(None)
    
    plane27.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane27.Evaluate()
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal28 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane28 = workPart.Planes.CreatePlane(origin28, normal28, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression111 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression112 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane28.SynchronizeToPlane(plane27)
    
    scalar17 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point92 = workPart.Points.CreatePoint(edge17, scalar17, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane28.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom23 = [NXOpen.NXObject.Null] * 1 
    geom23[0] = face6
    plane28.SetGeometry(geom23)
    
    plane28.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane28.Evaluate()
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId216, None)
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject36 = sketchInPlaceBuilder11.Commit()
    
    sketch18 = nXObject36
    feature18 = sketch18.Feature
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs11 = theSession.UpdateManager.DoUpdate(markId218)
    
    sketch18.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId217, None)
    
    theSession.SetUndoMarkName(markId215, "Create Sketch")
    
    sketchInPlaceBuilder11.Destroy()
    
    sketchAlongPathBuilder10.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression110)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point92)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression109)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane26.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression112)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression111)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane28.DestroyPlane()
    
    scaleAboutPoint514 = NXOpen.Point3d(-10.547132792604764, 4.0179553495636062, 0.0)
    viewCenter514 = NXOpen.Point3d(10.547132792604431, -4.0179553495636897, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint514, viewCenter514)
    
    scaleAboutPoint515 = NXOpen.Point3d(-3.892394244889962, 4.5201997682590758, 0.0)
    viewCenter515 = NXOpen.Point3d(3.8923942448896307, -4.5201997682591593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint515, viewCenter515)
    
    scaleAboutPoint516 = NXOpen.Point3d(20.246728128660429, 1.5695138084232776, 0.0)
    viewCenter516 = NXOpen.Point3d(-20.246728128660791, -1.5695138084233553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint516, viewCenter516)
    
    scaleAboutPoint517 = NXOpen.Point3d(28.447437777672185, 2.3542707126349036, 0.0)
    viewCenter517 = NXOpen.Point3d(-28.447437777672572, -2.3542707126349685, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint517, viewCenter517)
    
    scaleAboutPoint518 = NXOpen.Point3d(35.559297222090308, 2.9428383907936291, 0.0)
    viewCenter518 = NXOpen.Point3d(-35.559297222090628, -2.9428383907936695, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint518, viewCenter518)
    
    scaleAboutPoint519 = NXOpen.Point3d(44.449121527612874, 3.6785479884920864, 0.0)
    viewCenter519 = NXOpen.Point3d(-44.449121527613279, -3.6785479884920864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint519, viewCenter519)
    
    scaleAboutPoint520 = NXOpen.Point3d(55.5614019095161, 4.5981849856151085, 0.0)
    viewCenter520 = NXOpen.Point3d(-55.561401909516611, -4.5981849856151085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint520, viewCenter520)
    
    scaleAboutPoint521 = NXOpen.Point3d(69.451752386895279, 5.7477312320188858, 0.0)
    viewCenter521 = NXOpen.Point3d(-69.451752386895677, -5.7477312320188858, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint521, viewCenter521)
    
    scaleAboutPoint522 = NXOpen.Point3d(86.814690483619088, 7.1846640400236055, 0.0)
    viewCenter522 = NXOpen.Point3d(-86.814690483619486, -7.1846640400236055, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint522, viewCenter522)
    
    scaleAboutPoint523 = NXOpen.Point3d(70.409707592231641, 7.6636416426919265, 0.0)
    viewCenter523 = NXOpen.Point3d(-70.409707592232351, -7.6636416426919265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint523, viewCenter523)
    
    scaleAboutPoint524 = NXOpen.Point3d(57.860494402323489, 6.1309133141535401, 0.0)
    viewCenter524 = NXOpen.Point3d(-57.86049440232425, -6.1309133141535401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint524, viewCenter524)
    
    scaleAboutPoint525 = NXOpen.Point3d(47.514578184689441, 4.9047306513228328, 0.0)
    viewCenter525 = NXOpen.Point3d(-47.514578184690244, -4.9047306513228328, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint525, viewCenter525)
    
    scaleAboutPoint526 = NXOpen.Point3d(38.992608678016069, 3.9237845210582663, 0.0)
    viewCenter526 = NXOpen.Point3d(-38.992608678016751, -3.9237845210582254, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint526, viewCenter526)
    
    scaleAboutPoint527 = NXOpen.Point3d(32.371222298730309, 3.1390276168466777, 0.0)
    viewCenter527 = NXOpen.Point3d(-32.371222298730984, -3.1390276168465485, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint527, viewCenter527)
    
    scaleAboutPoint528 = NXOpen.Point3d(55.089934675657567, 2.5112220934773424, 0.0)
    viewCenter528 = NXOpen.Point3d(-55.089934675658291, -2.5112220934772389, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint528, viewCenter528)
    
    scaleAboutPoint529 = NXOpen.Point3d(44.071947740525964, 2.0089776747818737, 0.0)
    viewCenter529 = NXOpen.Point3d(-44.07194774052671, -2.0089776747817911, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint529, viewCenter529)
    
    scaleAboutPoint530 = NXOpen.Point3d(35.257558192420703, 1.20538660486912, 0.0)
    viewCenter530 = NXOpen.Point3d(-35.257558192421435, -1.2053866048690371, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint530, viewCenter530)
    
    scaleAboutPoint531 = NXOpen.Point3d(27.563173698006302, 0.32143642796514288, 0.0)
    viewCenter531 = NXOpen.Point3d(-27.563173698007045, -0.32143642796505001, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint531, viewCenter531)
    
    scaleAboutPoint532 = NXOpen.Point3d(20.379069532986506, -0.64287285593014243, 0.0)
    viewCenter532 = NXOpen.Point3d(-20.379069532987238, 0.64287285593022736, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint532, viewCenter532)
    
    scaleAboutPoint533 = NXOpen.Point3d(-51.481258302889579, -9.4630884392922798, 0.0)
    viewCenter533 = NXOpen.Point3d(51.481258302888833, 9.4630884392923722, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint533, viewCenter533)
    
    scaleAboutPoint534 = NXOpen.Point3d(-41.843308446784242, -7.9819093792291289, 0.0)
    viewCenter534 = NXOpen.Point3d(41.84330844678351, 7.9819093792292168, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint534, viewCenter534)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId220, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint21 = NXOpen.Point3d(115.89999999999999, -58.217163719845402, 25.0)
    endPoint21 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 25.0)
    line24 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    startPoint22 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 25.0)
    endPoint22 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 5.0000000000000036)
    line25 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    startPoint23 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 5.0000000000000036)
    endPoint23 = NXOpen.Point3d(115.89999999999999, -58.217163719845402, 5.0000000000000036)
    line26 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    startPoint24 = NXOpen.Point3d(115.89999999999999, -58.217163719845402, 5.0000000000000036)
    endPoint24 = NXOpen.Point3d(115.89999999999999, -58.217163719845402, 25.0)
    line27 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line24
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line25
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line25
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line26
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line26
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line27
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line27
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line24
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom24.Geometry = line24
    geom24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateHorizontalConstraint(geom24)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = line24
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_23.Geometry = line25
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_23, conGeom2_23)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line25
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line26
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line26
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line27
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line27
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line24
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line24
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    edge19 = extrude3.FindObject("EDGE * 130 * 170 {(115.9,-59.9,25)(115.9,-56.95,25)(115.9,-54,25) EXTRUDE(2)}")
    conGeom2_27.Geometry = edge19
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 115.89999999999999
    help3.Point.Y = -58.217163719845402
    help3.Point.Z = 25.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_27, conGeom2_27, help3)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line26
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    edge20 = extrude1.FindObject("EDGE * 140 * 150 {(120,-120,5)(120,-60,5)(120,0,5) EXTRUDE(2)}")
    conGeom2_28.Geometry = edge20
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 115.89999999999999
    help4.Point.Y = -55.71561686284987
    help4.Point.Z = 5.0000000000000036
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_28, conGeom2_28, help4)
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line25
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line25
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(115.89999999999999, -57.954879693811478, 15.000000000000002)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_11, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression113 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_15.Geometry = line24
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 0.0
    dimObject1_15.HelpPoint.Y = 0.0
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line24
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(115.89999999999999, -56.966390291347636, 22.760737169038393)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_15, dimObject2_12, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint15
    dimension15 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression114 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line24
    geoms11[1] = line25
    geoms11[2] = line26
    geoms11[3] = line27
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line24
    geoms12[1] = line25
    geoms12[2] = line26
    geoms12[3] = line27
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder39 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines201 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBefore(lines201)
    
    lines202 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAfter(lines202)
    
    lines203 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAbove(lines203)
    
    lines204 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBelow(lines204)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder39.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines205 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBefore(lines205)
    
    lines206 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAfter(lines206)
    
    lines207 = []
    sketchRapidDimensionBuilder39.AppendedText.SetAbove(lines207)
    
    lines208 = []
    sketchRapidDimensionBuilder39.AppendedText.SetBelow(lines208)
    
    theSession.SetUndoMarkName(markId221, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder39.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1103 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1104 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1105 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1106 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1107 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1108 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1109 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1110 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1111 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1112 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder39.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1113 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1114 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1115 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1116 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1117 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1118 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1119 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1120 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1121 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1122 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    point93 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 21.823872223597562)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(line25, workPart.ModelingViews.WorkView, point93)
    
    point1_132 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 25.0)
    point2_132 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line25, workPart.ModelingViews.WorkView, point1_132, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_132)
    
    point1_133 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 5.0000000000000036)
    point2_133 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder39.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line25, workPart.ModelingViews.WorkView, point1_133, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_133)
    
    dimensionlinearunits1123 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1124 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1125 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1126 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1127 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1128 = sketchRapidDimensionBuilder39.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin26 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin26.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin26.View = NXOpen.View.Null
    assocOrigin26.ViewOfGeometry = workPart.ModelingViews.WorkView
    point94 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin26.PointOnGeometry = point94
    assocOrigin26.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.DimensionLine = 0
    assocOrigin26.AssociatedView = NXOpen.View.Null
    assocOrigin26.AssociatedPoint = NXOpen.Point.Null
    assocOrigin26.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin26.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin26.XOffsetFactor = 0.0
    assocOrigin26.YOffsetFactor = 0.0
    assocOrigin26.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder39.Origin.SetAssociativeOrigin(assocOrigin26)
    
    point95 = NXOpen.Point3d(115.89999999999999, -41.693788427585417, 15.701665442003224)
    sketchRapidDimensionBuilder39.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point95)
    
    sketchRapidDimensionBuilder39.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder39.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder39.Style.DimensionStyle.TextCentered = True
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject37 = sketchRapidDimensionBuilder39.Commit()
    
    theSession.DeleteUndoMark(markId222, None)
    
    theSession.SetUndoMarkName(markId221, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId221, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder39.Destroy()
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder40 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines209 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBefore(lines209)
    
    lines210 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAfter(lines210)
    
    lines211 = []
    sketchRapidDimensionBuilder40.AppendedText.SetAbove(lines211)
    
    lines212 = []
    sketchRapidDimensionBuilder40.AppendedText.SetBelow(lines212)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder40.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId223, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder40.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1129 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1130 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1131 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1132 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1133 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1134 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1135 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1136 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1137 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1138 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder40.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1139 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1140 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1141 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1142 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1143 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1144 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1145 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1146 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1147 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1148 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    point96 = NXOpen.Point3d(115.89999999999999, -54.000000000000014, 17.808231216315253)
    sketchRapidDimensionBuilder40.FirstAssociativity.SetValue(edge17, workPart.ModelingViews.WorkView, point96)
    
    point1_134 = NXOpen.Point3d(115.89999999999999, -55.71561686284987, 15.000000000000002)
    point2_134 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder40.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line25, workPart.ModelingViews.WorkView, point1_134, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_134)
    
    dimensionlinearunits1149 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1150 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1151 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1152 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1153 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1154 = sketchRapidDimensionBuilder40.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin27 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin27.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin27.View = NXOpen.View.Null
    assocOrigin27.ViewOfGeometry = workPart.ModelingViews.WorkView
    point97 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin27.PointOnGeometry = point97
    assocOrigin27.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.DimensionLine = 0
    assocOrigin27.AssociatedView = NXOpen.View.Null
    assocOrigin27.AssociatedPoint = NXOpen.Point.Null
    assocOrigin27.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin27.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin27.XOffsetFactor = 0.0
    assocOrigin27.YOffsetFactor = 0.0
    assocOrigin27.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder40.Origin.SetAssociativeOrigin(assocOrigin27)
    
    point98 = NXOpen.Point3d(115.89999999999999, -56.373918667322378, 33.607474523655476)
    sketchRapidDimensionBuilder40.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point98)
    
    sketchRapidDimensionBuilder40.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder40.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder40.Style.DimensionStyle.TextCentered = False
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject38 = sketchRapidDimensionBuilder40.Commit()
    
    theSession.DeleteUndoMark(markId224, None)
    
    theSession.SetUndoMarkName(markId223, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId223, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder40.Destroy()
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder41 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines213 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBefore(lines213)
    
    lines214 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAfter(lines214)
    
    lines215 = []
    sketchRapidDimensionBuilder41.AppendedText.SetAbove(lines215)
    
    lines216 = []
    sketchRapidDimensionBuilder41.AppendedText.SetBelow(lines216)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder41.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId225, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder41.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1155 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1156 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1157 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1158 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1159 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1160 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1161 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1162 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1163 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1164 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder41.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1165 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1166 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1167 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1168 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1169 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1170 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1171 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1172 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1173 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1174 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    expression115 = workPart.Expressions.FindObject("p46")
    expression115.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId225, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId226, None)
    
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId225, "Edit Driving Value")
    
    point99 = NXOpen.Point3d(115.89999999999999, -58.001546856995546, 15.701665442003222)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point99)
    
    point1_135 = NXOpen.Point3d(115.89999999999999, -58.001546856995553, 25.0)
    point2_135 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_135, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_135)
    
    point1_136 = NXOpen.Point3d(115.89999999999999, -58.001546856995539, 5.0000000000000036)
    point2_136 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_136, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_136)
    
    dimensionlinearunits1175 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1176 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1177 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1178 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1179 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1180 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint535 = NXOpen.Point3d(-31.565571524457187, -6.7146784056195514, 0.0)
    viewCenter535 = NXOpen.Point3d(31.565571524456448, 6.7146784056196385, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint535, viewCenter535)
    
    scaleAboutPoint536 = NXOpen.Point3d(-25.252457219565812, -5.3717427244956326, 0.0)
    viewCenter536 = NXOpen.Point3d(25.252457219565084, 5.3717427244957197, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint536, viewCenter536)
    
    scaleAboutPoint537 = NXOpen.Point3d(-20.201965775652734, -4.2973941795964992, 0.0)
    viewCenter537 = NXOpen.Point3d(20.201965775651995, 4.2973941795965862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint537, viewCenter537)
    
    scaleAboutPoint538 = NXOpen.Point3d(-16.161572620522261, -3.4379153436771941, 0.0)
    viewCenter538 = NXOpen.Point3d(16.161572620521525, 3.4379153436772776, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint538, viewCenter538)
    
    scaleAboutPoint539 = NXOpen.Point3d(-12.929258096417886, -2.7503322749417425, 0.0)
    viewCenter539 = NXOpen.Point3d(12.929258096417147, 2.7503322749418291, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint539, viewCenter539)
    
    scaleAboutPoint540 = NXOpen.Point3d(-10.343406477134383, -2.2002658199533869, 0.0)
    viewCenter540 = NXOpen.Point3d(10.343406477133643, 2.2002658199534721, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint540, viewCenter540)
    
    scaleAboutPoint541 = NXOpen.Point3d(-8.2747251817075806, -1.7602126559627009, 0.0)
    viewCenter541 = NXOpen.Point3d(8.2747251817068399, 1.7602126559627864, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint541, viewCenter541)
    
    scaleAboutPoint542 = NXOpen.Point3d(-6.6197801453661382, -1.4081701247701539, 0.0)
    viewCenter542 = NXOpen.Point3d(6.6197801453653993, 1.408170124770237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint542, viewCenter542)
    
    scaleAboutPoint543 = NXOpen.Point3d(-5.2958241162929829, -1.1265360998161118, 0.0)
    viewCenter543 = NXOpen.Point3d(5.295824116292243, 1.1265360998161993, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint543, viewCenter543)
    
    scaleAboutPoint544 = NXOpen.Point3d(-4.2366592930344593, -0.90122887985287992, 0.0)
    viewCenter544 = NXOpen.Point3d(4.2366592930337212, 0.90122887985296884, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint544, viewCenter544)
    
    scaleAboutPoint545 = NXOpen.Point3d(-3.3893274344276292, -0.72098310388229492, 0.0)
    viewCenter545 = NXOpen.Point3d(3.3893274344269129, 0.72098310388238362, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint545, viewCenter545)
    
    scaleAboutPoint546 = NXOpen.Point3d(-2.7114619475421753, -0.57678648310582625, 0.0)
    viewCenter546 = NXOpen.Point3d(2.711461947541451, 0.57678648310591496, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint546, viewCenter546)
    
    edge21 = extrude2.FindObject("EDGE * 140 * 170 {(59.9,-60,65)(59.9,-60,35)(59.9,-60,5) EXTRUDE(2)}")
    point1_137 = NXOpen.Point3d(59.899999999999991, -60.0, 4.9999999999999964)
    point2_137 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge21, workPart.ModelingViews.WorkView, point1_137, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_137)
    
    point1_138 = NXOpen.Point3d(115.89999999999999, -58.001546856995546, 15.701665442003222)
    point2_138 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_138, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_138)
    
    point1_139 = NXOpen.Point3d(59.899999999999991, -60.0, 4.9999999999999964)
    point2_139 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge21, workPart.ModelingViews.WorkView, point1_139, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_139)
    
    point1_140 = NXOpen.Point3d(115.89999999999999, -58.001546856995546, 15.701665442003222)
    point2_140 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_140, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_140)
    
    point1_141 = NXOpen.Point3d(59.899999999999991, -60.0, 4.9999999999999964)
    point2_141 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder41.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge21, workPart.ModelingViews.WorkView, point1_141, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_141)
    
    dimensionlinearunits1181 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1182 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1183 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1184 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1185 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1186 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1187 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1188 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1189 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1190 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1191 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1192 = sketchRapidDimensionBuilder41.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint547 = NXOpen.Point3d(-1.0065489607145288, 0.208095515473535, 0.0)
    viewCenter547 = NXOpen.Point3d(1.0065489607138043, -0.20809551547344612, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint547, viewCenter547)
    
    scaleAboutPoint548 = NXOpen.Point3d(-0.80523916857169631, 0.17009546482185606, 0.0)
    viewCenter548 = NXOpen.Point3d(0.805239168570971, -0.17009546482176374, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint548, viewCenter548)
    
    scaleAboutPoint549 = NXOpen.Point3d(-0.64419133485743008, 0.14765733967514927, 0.0)
    viewCenter549 = NXOpen.Point3d(0.64419133485670543, -0.14765733967505704, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint549, viewCenter549)
    
    scaleAboutPoint550 = NXOpen.Point3d(-0.52693403570367237, 0.19456025933665305, 0.0)
    viewCenter550 = NXOpen.Point3d(0.52693403570294772, -0.19456025933656071, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint550, viewCenter550)
    
    scaleAboutPoint551 = NXOpen.Point3d(-0.65866754462949906, 0.2432003241708042, 0.0)
    viewCenter551 = NXOpen.Point3d(0.65866754462877442, -0.24320032417071194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint551, viewCenter551)
    
    scaleAboutPoint552 = NXOpen.Point3d(-0.82333443078678403, 0.30400040521349431, 0.0)
    viewCenter552 = NXOpen.Point3d(0.82333443078605961, -0.30400040521340199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint552, viewCenter552)
    
    scaleAboutPoint553 = NXOpen.Point3d(-1.0291680384833888, 0.38000050651685408, 0.0)
    viewCenter553 = NXOpen.Point3d(1.0291680384826638, -0.3800005065167652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint553, viewCenter553)
    
    scaleAboutPoint554 = NXOpen.Point3d(-1.2864600481041446, 0.47500063314605612, 0.0)
    viewCenter554 = NXOpen.Point3d(1.2864600481034196, -0.47500063314596741, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint554, viewCenter554)
    
    scaleAboutPoint555 = NXOpen.Point3d(-1.6080750601300857, 0.59375079143255882, 0.0)
    viewCenter555 = NXOpen.Point3d(1.6080750601293687, -0.59375079143247023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint555, viewCenter555)
    
    scaleAboutPoint556 = NXOpen.Point3d(-2.0189294024159752, 0.83054426182528851, 0.0)
    viewCenter556 = NXOpen.Point3d(2.0189294024152575, -0.83054426182519736, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint556, viewCenter556)
    
    scaleAboutPoint557 = NXOpen.Point3d(-2.5236617530198759, 1.0381803272815977, 0.0)
    viewCenter557 = NXOpen.Point3d(2.523661753019165, -1.0381803272815084, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint557, viewCenter557)
    
    scaleAboutPoint558 = NXOpen.Point3d(-3.1545771912747504, 1.2977254091019854, 0.0)
    viewCenter558 = NXOpen.Point3d(3.1545771912740483, -1.2977254091018964, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint558, viewCenter558)
    
    scaleAboutPoint559 = NXOpen.Point3d(-3.390997910752096, 3.14077160181591, 0.0)
    viewCenter559 = NXOpen.Point3d(3.3909979107513939, -3.1407716018158203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint559, viewCenter559)
    
    scaleAboutPoint560 = NXOpen.Point3d(-2.7127983286017563, 2.5126172814527346, 0.0)
    viewCenter560 = NXOpen.Point3d(2.7127983286010364, -2.5126172814526502, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint560, viewCenter560)
    
    scaleAboutPoint561 = NXOpen.Point3d(-2.1702386628814776, 2.010093825162198, 0.0)
    viewCenter561 = NXOpen.Point3d(2.1702386628807591, -2.0100938251621123, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint561, viewCenter561)
    
    scaleAboutPoint562 = NXOpen.Point3d(-1.7361909303052507, 1.6080750601297658, 0.0)
    viewCenter562 = NXOpen.Point3d(1.7361909303045389, -1.6080750601296825, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint562, viewCenter562)
    
    scaleAboutPoint563 = NXOpen.Point3d(-2.1702386628814749, 2.0100938251621989, 0.0)
    viewCenter563 = NXOpen.Point3d(2.1702386628807639, -2.0100938251621132, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint563, viewCenter563)
    
    scaleAboutPoint564 = NXOpen.Point3d(-2.7127983286017581, 2.5126172814527368, 0.0)
    viewCenter564 = NXOpen.Point3d(2.7127983286010413, -2.5126172814526537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint564, viewCenter564)
    
    scaleAboutPoint565 = NXOpen.Point3d(-3.3909979107521053, 3.1407716018159144, 0.0)
    viewCenter565 = NXOpen.Point3d(3.3909979107513961, -3.1407716018158292, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint565, viewCenter565)
    
    scaleAboutPoint566 = NXOpen.Point3d(-4.2387473884400473, 3.9259645022698835, 0.0)
    viewCenter566 = NXOpen.Point3d(4.238747388439335, -3.9259645022697978, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint566, viewCenter566)
    
    scaleAboutPoint567 = NXOpen.Point3d(-5.298434235549955, 4.9074556278373436, 0.0)
    viewCenter567 = NXOpen.Point3d(5.2984342355492675, -4.9074556278372565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint567, viewCenter567)
    
    scaleAboutPoint568 = NXOpen.Point3d(-6.6230427944373647, 6.134319534796667, 0.0)
    viewCenter568 = NXOpen.Point3d(6.6230427944366692, -6.1343195347965809, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint568, viewCenter568)
    
    scaleAboutPoint569 = NXOpen.Point3d(-8.2788034930466203, 7.6678994184958249, 0.0)
    viewCenter569 = NXOpen.Point3d(8.2788034930459187, -7.6678994184957352, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint569, viewCenter569)
    
    scaleAboutPoint570 = NXOpen.Point3d(-10.348504366308187, 9.5848742731197714, 0.0)
    viewCenter570 = NXOpen.Point3d(10.348504366307491, -9.5848742731196843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint570, viewCenter570)
    
    scaleAboutPoint571 = NXOpen.Point3d(-12.935630457885157, 11.981092841399702, 0.0)
    viewCenter571 = NXOpen.Point3d(12.935630457884439, -11.98109284139962, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint571, viewCenter571)
    
    scaleAboutPoint572 = NXOpen.Point3d(-16.169538072356357, 14.976366051749618, 0.0)
    viewCenter572 = NXOpen.Point3d(16.169538072355635, -14.97636605174953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint572, viewCenter572)
    
    scaleAboutPoint573 = NXOpen.Point3d(-20.211922590445354, 18.72045756468701, 0.0)
    viewCenter573 = NXOpen.Point3d(20.21192259044464, -18.720457564686924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint573, viewCenter573)
    
    scaleAboutPoint574 = NXOpen.Point3d(-25.264903238056597, 23.400571955858741, 0.0)
    viewCenter574 = NXOpen.Point3d(25.264903238055897, -23.400571955858656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint574, viewCenter574)
    
    assocOrigin28 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin28.OriginType = NXOpen.Annotations.AssociativeOriginType.Drag
    assocOrigin28.View = NXOpen.View.Null
    assocOrigin28.ViewOfGeometry = NXOpen.View.Null
    assocOrigin28.PointOnGeometry = NXOpen.Point.Null
    assocOrigin28.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.DimensionLine = 0
    assocOrigin28.AssociatedView = NXOpen.View.Null
    assocOrigin28.AssociatedPoint = NXOpen.Point.Null
    assocOrigin28.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin28.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin28.XOffsetFactor = 0.0
    assocOrigin28.YOffsetFactor = 0.0
    assocOrigin28.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder41.Origin.SetAssociativeOrigin(assocOrigin28)
    
    point100 = NXOpen.Point3d(115.89999999999999, -65.197405258035545, 37.727818502567239)
    sketchRapidDimensionBuilder41.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point100)
    
    sketchRapidDimensionBuilder41.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder41.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder41.Style.DimensionStyle.TextCentered = False
    
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject39 = sketchRapidDimensionBuilder41.Commit()
    
    theSession.DeleteUndoMark(markId228, None)
    
    theSession.SetUndoMarkName(markId227, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId227, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder41.Destroy()
    
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder42 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines217 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBefore(lines217)
    
    lines218 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAfter(lines218)
    
    lines219 = []
    sketchRapidDimensionBuilder42.AppendedText.SetAbove(lines219)
    
    lines220 = []
    sketchRapidDimensionBuilder42.AppendedText.SetBelow(lines220)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder42.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId229, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder42.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1193 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1194 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1195 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1196 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1197 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1198 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1199 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1200 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1201 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1202 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder42.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder42.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder42.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1203 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1204 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1205 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1206 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1207 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1208 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1209 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1210 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1211 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1212 = sketchRapidDimensionBuilder42.Style.UnitsStyle.DimensionLinearUnits
    
    expression116 = workPart.Expressions.FindObject("p47")
    expression116.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId229, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId230, None)
    
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId229, "Edit Driving Value")
    
    scaleAboutPoint575 = NXOpen.Point3d(-30.295383335710294, 49.501209906624226, 0.0)
    viewCenter575 = NXOpen.Point3d(30.295383335709602, -49.501209906624133, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint575, viewCenter575)
    
    scaleAboutPoint576 = NXOpen.Point3d(-24.236306668568272, 39.600967925299372, 0.0)
    viewCenter576 = NXOpen.Point3d(24.236306668567593, -39.600967925299287, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint576, viewCenter576)
    
    scaleAboutPoint577 = NXOpen.Point3d(-30.295383335710259, 49.501209906624211, 0.0)
    viewCenter577 = NXOpen.Point3d(30.295383335709595, -49.501209906624119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint577, viewCenter577)
    
    scaleAboutPoint578 = NXOpen.Point3d(-37.86922916963772, 61.876512383280229, 0.0)
    viewCenter578 = NXOpen.Point3d(37.869229169637059, -61.876512383280151, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint578, viewCenter578)
    
    scaleAboutPoint579 = NXOpen.Point3d(-47.336536462047029, 77.345640479100283, 0.0)
    viewCenter579 = NXOpen.Point3d(47.336536462046404, -77.345640479100197, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint579, viewCenter579)
    
    scaleAboutPoint580 = NXOpen.Point3d(-59.170670577558724, 96.682050598875321, 0.0)
    viewCenter580 = NXOpen.Point3d(59.170670577558099, -96.682050598875236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint580, viewCenter580)
    
    scaleAboutPoint581 = NXOpen.Point3d(-73.963338221948334, 120.85256324859415, 0.0)
    viewCenter581 = NXOpen.Point3d(73.96333822194768, -120.85256324859407, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint581, viewCenter581)
    
    scaleAboutPoint582 = NXOpen.Point3d(-92.454172777435332, 151.06570406074266, 0.0)
    viewCenter582 = NXOpen.Point3d(92.454172777434678, -151.06570406074258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint582, viewCenter582)
    
    scaleAboutPoint583 = NXOpen.Point3d(-115.56771597179406, 188.83213007592832, 0.0)
    viewCenter583 = NXOpen.Point3d(115.5677159717934, -188.83213007592823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint583, viewCenter583)
    
    scaleAboutPoint584 = NXOpen.Point3d(-144.45964496474244, 236.04016259491036, 0.0)
    viewCenter584 = NXOpen.Point3d(144.45964496474178, -236.04016259491024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint584, viewCenter584)
    
    scaleAboutPoint585 = NXOpen.Point3d(-115.56771597179396, 188.83213007592838, 0.0)
    viewCenter585 = NXOpen.Point3d(115.56771597179345, -188.83213007592818, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint585, viewCenter585)
    
    scaleAboutPoint586 = NXOpen.Point3d(-92.454172777435247, 151.06570406074266, 0.0)
    viewCenter586 = NXOpen.Point3d(92.454172777434763, -151.06570406074258, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint586, viewCenter586)
    
    scaleAboutPoint587 = NXOpen.Point3d(-73.963338221948263, 120.85256324859415, 0.0)
    viewCenter587 = NXOpen.Point3d(73.963338221947751, -120.85256324859402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint587, viewCenter587)
    
    scaleAboutPoint588 = NXOpen.Point3d(-59.17067057755866, 96.682050598875321, 0.0)
    viewCenter588 = NXOpen.Point3d(59.170670577558141, -96.682050598875236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint588, viewCenter588)
    
    scaleAboutPoint589 = NXOpen.Point3d(-47.336536462046979, 77.345640479100254, 0.0)
    viewCenter589 = NXOpen.Point3d(47.33653646204646, -77.345640479100183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint589, viewCenter589)
    
    scaleAboutPoint590 = NXOpen.Point3d(-37.869229169637649, 61.8765123832802, 0.0)
    viewCenter590 = NXOpen.Point3d(37.869229169637116, -61.876512383280136, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint590, viewCenter590)
    
    scaleAboutPoint591 = NXOpen.Point3d(-30.295383335710174, 49.50120990662419, 0.0)
    viewCenter591 = NXOpen.Point3d(30.295383335709641, -49.501209906624119, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint591, viewCenter591)
    
    scaleAboutPoint592 = NXOpen.Point3d(-24.236306668568179, 39.600967925299351, 0.0)
    viewCenter592 = NXOpen.Point3d(24.236306668567671, -39.600967925299287, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint592, viewCenter592)
    
    scaleAboutPoint593 = NXOpen.Point3d(-19.389045334854597, 31.680774340239491, 0.0)
    viewCenter593 = NXOpen.Point3d(19.389045334854089, -31.680774340239431, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint593, viewCenter593)
    
    scaleAboutPoint594 = NXOpen.Point3d(-15.017509914529354, 23.945728137687517, 0.0)
    viewCenter594 = NXOpen.Point3d(15.017509914528851, -23.94572813768745, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint594, viewCenter594)
    
    scaleAboutPoint595 = NXOpen.Point3d(-11.619026848940033, 18.366620344783009, 0.0)
    viewCenter595 = NXOpen.Point3d(11.619026848939511, -18.366620344782955, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint595, viewCenter595)
    
    scaleAboutPoint596 = NXOpen.Point3d(-8.9265724686474748, 14.008662399175003, 0.0)
    viewCenter596 = NXOpen.Point3d(8.9265724686469454, -14.008662399174947, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint596, viewCenter596)
    
    scaleAboutPoint597 = NXOpen.Point3d(-6.9306013974868383, 10.912010710936325, 0.0)
    viewCenter597 = NXOpen.Point3d(6.9306013974863028, -10.912010710936269, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint597, viewCenter597)
    
    scaleAboutPoint598 = NXOpen.Point3d(-5.4433659608225451, 8.5273782544151118, 0.0)
    viewCenter598 = NXOpen.Point3d(5.4433659608220024, -8.5273782544150567, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint598, viewCenter598)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.15643446504023095
    rotMatrix12.Xy = 0.98768834059513766
    rotMatrix12.Xz = 0.0
    rotMatrix12.Yx = 0.0
    rotMatrix12.Yy = 0.0
    rotMatrix12.Yz = 1.0
    rotMatrix12.Zx = 0.98768834059513766
    rotMatrix12.Zy = -0.15643446504023095
    rotMatrix12.Zz = 0.0
    translation12 = NXOpen.Point3d(41.755778998333874, -27.535278999774853, -124.5473683381222)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 9.8124507521809345)
    
    sketchRapidDimensionBuilder42.Destroy()
    
    theSession.UndoToMark(markId231, None)
    
    theSession.DeleteUndoMark(markId231, None)
    
    sketchRapidDimensionBuilder42.Destroy()
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    perpendicularDimension4 = nXObject39
    objects1[0] = perpendicularDimension4
    nErrs12 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs13 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId232, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder43 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines221 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBefore(lines221)
    
    lines222 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAfter(lines222)
    
    lines223 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAbove(lines223)
    
    lines224 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBelow(lines224)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder43.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines225 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBefore(lines225)
    
    lines226 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAfter(lines226)
    
    lines227 = []
    sketchRapidDimensionBuilder43.AppendedText.SetAbove(lines227)
    
    lines228 = []
    sketchRapidDimensionBuilder43.AppendedText.SetBelow(lines228)
    
    theSession.SetUndoMarkName(markId234, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder43.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1213 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1214 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1215 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1216 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1217 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1218 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1219 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1220 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1221 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1222 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder43.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1223 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1224 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1225 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1226 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1227 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1228 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1229 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1230 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1231 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1232 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    point101 = NXOpen.Point3d(115.89999999999999, -58.5, 21.522297653578633)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point101)
    
    point1_142 = NXOpen.Point3d(115.89999999999999, -58.5, 25.0)
    point2_142 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_142, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_142)
    
    point1_143 = NXOpen.Point3d(115.89999999999999, -58.5, 5.0000000000000036)
    point2_143 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_143, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_143)
    
    dimensionlinearunits1233 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1234 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1235 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1236 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1237 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1238 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    edge22 = extrude3.FindObject("EDGE * 160 * 170 {(115.9,-59.9,25)(115.9,-59.9,15)(115.9,-59.9,5) EXTRUDE(2)}")
    point1_144 = NXOpen.Point3d(115.89999999999999, -59.900000000000013, 25.0)
    point2_144 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_144, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_144)
    
    point1_145 = NXOpen.Point3d(115.89999999999999, -58.5, 21.522297653578633)
    point2_145 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_145, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_145)
    
    point1_146 = NXOpen.Point3d(115.89999999999999, -59.900000000000013, 25.0)
    point2_146 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_146, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_146)
    
    point1_147 = NXOpen.Point3d(115.89999999999999, -58.5, 21.522297653578633)
    point2_147 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line27, workPart.ModelingViews.WorkView, point1_147, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_147)
    
    point1_148 = NXOpen.Point3d(115.89999999999999, -59.900000000000013, 25.0)
    point2_148 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder43.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, edge22, workPart.ModelingViews.WorkView, point1_148, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_148)
    
    dimensionlinearunits1239 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1240 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1241 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1242 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1243 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1244 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1245 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1246 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1247 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1248 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1249 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1250 = sketchRapidDimensionBuilder43.Style.UnitsStyle.DimensionLinearUnits
    
    assocOrigin29 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin29.OriginType = NXOpen.Annotations.AssociativeOriginType.Drag
    assocOrigin29.View = NXOpen.View.Null
    assocOrigin29.ViewOfGeometry = NXOpen.View.Null
    assocOrigin29.PointOnGeometry = NXOpen.Point.Null
    assocOrigin29.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.DimensionLine = 0
    assocOrigin29.AssociatedView = NXOpen.View.Null
    assocOrigin29.AssociatedPoint = NXOpen.Point.Null
    assocOrigin29.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin29.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin29.XOffsetFactor = 0.0
    assocOrigin29.YOffsetFactor = 0.0
    assocOrigin29.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder43.Origin.SetAssociativeOrigin(assocOrigin29)
    
    point102 = NXOpen.Point3d(115.89999999999999, -59.200000000000003, 26.699393700527867)
    sketchRapidDimensionBuilder43.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point102)
    
    sketchRapidDimensionBuilder43.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder43.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder43.Style.DimensionStyle.TextCentered = True
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject40 = sketchRapidDimensionBuilder43.Commit()
    
    theSession.DeleteUndoMark(markId235, None)
    
    theSession.SetUndoMarkName(markId234, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId234, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder43.Destroy()
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder44 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines229 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBefore(lines229)
    
    lines230 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAfter(lines230)
    
    lines231 = []
    sketchRapidDimensionBuilder44.AppendedText.SetAbove(lines231)
    
    lines232 = []
    sketchRapidDimensionBuilder44.AppendedText.SetBelow(lines232)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder44.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId236, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder44.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1251 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1252 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1253 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1254 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1255 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1256 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1257 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1258 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1259 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1260 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder44.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder44.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder44.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits1261 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1262 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1263 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1264 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1265 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1266 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1267 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1268 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1269 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits1270 = sketchRapidDimensionBuilder44.Style.UnitsStyle.DimensionLinearUnits
    
    expression117 = workPart.Expressions.FindObject("p47")
    expression117.SetFormula("1.5")
    
    theSession.SetUndoMarkVisibility(markId236, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId237, None)
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId236, "Edit Driving Value")
    
    sketchRapidDimensionBuilder44.Destroy()
    
    theSession.UndoToMark(markId238, None)
    
    theSession.DeleteUndoMark(markId238, None)
    
    sketchRapidDimensionBuilder44.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch19 = theSession.ActiveSketch
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder15 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section15 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder15.Section = section15
    
    extrudeBuilder15.AllowSelfIntersectingSection(True)
    
    expression118 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder15.DistanceTolerance = 0.01
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies76 = [NXOpen.Body.Null] * 1 
    targetBodies76[0] = NXOpen.Body.Null
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies76)
    
    extrudeBuilder15.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder15.Limits.EndExtend.Value.SetFormula("60")
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies77 = [NXOpen.Body.Null] * 1 
    targetBodies77[0] = NXOpen.Body.Null
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies77)
    
    extrudeBuilder15.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder15.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder15.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder15.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder15 = extrudeBuilder15.SmartVolumeProfile
    
    smartVolumeProfileBuilder15.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder15.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId240, "Extrude Dialog")
    
    section15.DistanceTolerance = 0.01
    
    section15.ChainingTolerance = 0.0094999999999999998
    
    section15.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    scaleAboutPoint599 = NXOpen.Point3d(4.9219953032153265, 39.576860193201952, 0.0)
    viewCenter599 = NXOpen.Point3d(-4.9219953032156578, -39.576860193202037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint599, viewCenter599)
    
    scaleAboutPoint600 = NXOpen.Point3d(5.9013719196714636, 49.471075241502469, 0.0)
    viewCenter600 = NXOpen.Point3d(-5.9013719196717958, -49.471075241502554, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint600, viewCenter600)
    
    scaleAboutPoint601 = NXOpen.Point3d(7.3767148995893814, 61.838844051878091, 0.0)
    viewCenter601 = NXOpen.Point3d(-7.376714899589718, -61.838844051878169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint601, viewCenter601)
    
    scaleAboutPoint602 = NXOpen.Point3d(9.2208936244867274, 77.298555064847648, 0.0)
    viewCenter602 = NXOpen.Point3d(-9.2208936244871165, -77.298555064847719, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint602, viewCenter602)
    
    scaleAboutPoint603 = NXOpen.Point3d(11.526117030608489, 96.623193831059595, 0.0)
    viewCenter603 = NXOpen.Point3d(-11.526117030608813, -96.623193831059623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint603, viewCenter603)
    
    scaleAboutPoint604 = NXOpen.Point3d(14.407646288260608, 120.77899228882441, 0.0)
    viewCenter604 = NXOpen.Point3d(-14.407646288261013, -120.77899228882451, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint604, viewCenter604)
    
    scaleAboutPoint605 = NXOpen.Point3d(18.00955786032576, 150.97374036103056, 0.0)
    viewCenter605 = NXOpen.Point3d(-18.009557860326264, -150.97374036103056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint605, viewCenter605)
    
    scaleAboutPoint606 = NXOpen.Point3d(22.511947325407363, 188.71717545128826, 0.0)
    viewCenter606 = NXOpen.Point3d(-22.511947325407757, -188.71717545128826, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint606, viewCenter606)
    
    scaleAboutPoint607 = NXOpen.Point3d(28.139934156759196, 235.89646931411016, 0.0)
    viewCenter607 = NXOpen.Point3d(-28.13993415675959, -235.89646931411028, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint607, viewCenter607)
    
    scaleAboutPoint608 = NXOpen.Point3d(22.511947325407363, 188.71717545128826, 0.0)
    viewCenter608 = NXOpen.Point3d(-22.511947325407757, -188.71717545128826, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint608, viewCenter608)
    
    scaleAboutPoint609 = NXOpen.Point3d(18.00955786032576, 150.97374036103056, 0.0)
    viewCenter609 = NXOpen.Point3d(-18.009557860326264, -150.97374036103056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint609, viewCenter609)
    
    scaleAboutPoint610 = NXOpen.Point3d(14.407646288260608, 120.77899228882447, 0.0)
    viewCenter610 = NXOpen.Point3d(-14.407646288261065, -120.77899228882447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint610, viewCenter610)
    
    scaleAboutPoint611 = NXOpen.Point3d(11.526117030608406, 96.623193831059581, 0.0)
    viewCenter611 = NXOpen.Point3d(-11.526117030608892, -96.623193831059581, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint611, viewCenter611)
    
    scaleAboutPoint612 = NXOpen.Point3d(9.2208936244867257, 77.298555064847662, 0.0)
    viewCenter612 = NXOpen.Point3d(-9.2208936244871467, -77.298555064847662, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint612, viewCenter612)
    
    scaleAboutPoint613 = NXOpen.Point3d(7.3767148995892766, 61.838844051878134, 0.0)
    viewCenter613 = NXOpen.Point3d(-7.3767148995897953, -61.838844051878134, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint613, viewCenter613)
    
    scaleAboutPoint614 = NXOpen.Point3d(5.9013719196713792, 49.471075241502518, 0.0)
    viewCenter614 = NXOpen.Point3d(-5.9013719196718766, -49.471075241502476, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint614, viewCenter614)
    
    scaleAboutPoint615 = NXOpen.Point3d(4.7210975357370701, 39.576860193202016, 0.0)
    viewCenter615 = NXOpen.Point3d(-4.7210975357375347, -39.576860193202002, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint615, viewCenter615)
    
    scaleAboutPoint616 = NXOpen.Point3d(3.7768780285896031, 31.661488154561614, 0.0)
    viewCenter616 = NXOpen.Point3d(-3.7768780285900805, -31.661488154561575, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint616, viewCenter616)
    
    scaleAboutPoint617 = NXOpen.Point3d(3.0215024228716394, 25.329190523649284, 0.0)
    viewCenter617 = NXOpen.Point3d(-3.0215024228721066, -25.329190523649263, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint617, viewCenter617)
    
    scaleAboutPoint618 = NXOpen.Point3d(2.4172019382972607, 20.263352418919439, 0.0)
    viewCenter618 = NXOpen.Point3d(-2.4172019382977363, -20.263352418919414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint618, viewCenter618)
    
    scaleAboutPoint619 = NXOpen.Point3d(1.9337615506377273, 16.210681935135558, 0.0)
    viewCenter619 = NXOpen.Point3d(-1.9337615506382571, -16.210681935135526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint619, viewCenter619)
    
    scaleAboutPoint620 = NXOpen.Point3d(1.5470092405101492, 12.968545548108448, 0.0)
    viewCenter620 = NXOpen.Point3d(-1.5470092405106655, -12.96854554810842, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint620, viewCenter620)
    
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features8 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature8 = feature18
    features8[0] = sketchFeature8
    curveFeatureRule8 = workPart.ScRuleFactory.CreateRuleCurveFeature(features8)
    
    section15.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = curveFeatureRule8
    helpPoint8 = NXOpen.Point3d(115.89999999999948, -55.499999999999794, 16.040963771656124)
    section15.AddToSection(rules8, line25, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId242, None)
    
    direction22 = workPart.Directions.CreateDirection(sketch19, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder15.Direction = direction22
    
    targetBodies78 = [NXOpen.Body.Null] * 1 
    targetBodies78[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies78)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies79 = [NXOpen.Body.Null] * 1 
    targetBodies79[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies79)
    
    expression119 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId241, None)
    
    scaleAboutPoint621 = NXOpen.Point3d(-10.664489232454905, -10.848813737706941, 0.0)
    viewCenter621 = NXOpen.Point3d(10.664489232454388, 10.848813737706966, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint621, viewCenter621)
    
    scaleAboutPoint622 = NXOpen.Point3d(-13.330611540568565, -13.561017172133679, 0.0)
    viewCenter622 = NXOpen.Point3d(13.330611540568064, 13.561017172133701, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint622, viewCenter622)
    
    scaleAboutPoint623 = NXOpen.Point3d(-16.663264425710654, -16.951271465167096, 0.0)
    viewCenter623 = NXOpen.Point3d(16.663264425710139, 16.951271465167128, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint623, viewCenter623)
    
    scaleAboutPoint624 = NXOpen.Point3d(-20.829080532138246, -21.18908933145887, 0.0)
    viewCenter624 = NXOpen.Point3d(20.829080532137752, 21.189089331458913, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint624, viewCenter624)
    
    scaleAboutPoint625 = NXOpen.Point3d(-26.036350665172719, -26.486361664323589, 0.0)
    viewCenter625 = NXOpen.Point3d(26.036350665172254, 26.48636166432361, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint625, viewCenter625)
    
    scaleAboutPoint626 = NXOpen.Point3d(-35.277647969169124, -37.447343857933241, 0.0)
    viewCenter626 = NXOpen.Point3d(35.277647969168648, 37.447343857933284, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint626, viewCenter626)
    
    direction23 = extrudeBuilder15.Direction
    
    success5 = direction23.ReverseDirection()
    
    extrudeBuilder15.Direction = direction23
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies80 = [NXOpen.Body.Null] * 1 
    targetBodies80[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies80)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies81 = [NXOpen.Body.Null] * 1 
    targetBodies81[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies81)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies82 = [NXOpen.Body.Null] * 1 
    targetBodies82[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies82)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies83 = [NXOpen.Body.Null] * 1 
    targetBodies83[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies83)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies84 = [NXOpen.Body.Null] * 1 
    targetBodies84[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies84)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies85 = [NXOpen.Body.Null] * 1 
    targetBodies85[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies85)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies86 = [NXOpen.Body.Null] * 1 
    targetBodies86[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies86)
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies87 = [NXOpen.Body.Null] * 1 
    targetBodies87[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies87)
    
    extrudeBuilder15.Limits.EndExtend.Value.SetFormula("26")
    
    extrudeBuilder15.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies88 = [NXOpen.Body.Null] * 1 
    targetBodies88[0] = body1
    extrudeBuilder15.BooleanOperation.SetTargetBodies(targetBodies88)
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder15.ParentFeatureInternal = False
    
    feature19 = extrudeBuilder15.CommitFeature()
    
    theSession.DeleteUndoMark(markId243, None)
    
    theSession.SetUndoMarkName(markId240, "Extrude")
    
    expression120 = extrudeBuilder15.Limits.StartExtend.Value
    expression121 = extrudeBuilder15.Limits.EndExtend.Value
    extrudeBuilder15.Destroy()
    
    workPart.Expressions.Delete(expression118)
    
    workPart.Expressions.Delete(expression119)
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder16 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section16 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder16.Section = section16
    
    extrudeBuilder16.AllowSelfIntersectingSection(True)
    
    expression122 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder16.DistanceTolerance = 0.01
    
    extrudeBuilder16.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies89 = [NXOpen.Body.Null] * 1 
    targetBodies89[0] = NXOpen.Body.Null
    extrudeBuilder16.BooleanOperation.SetTargetBodies(targetBodies89)
    
    extrudeBuilder16.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder16.Limits.EndExtend.Value.SetFormula("26")
    
    extrudeBuilder16.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies90 = [NXOpen.Body.Null] * 1 
    targetBodies90[0] = NXOpen.Body.Null
    extrudeBuilder16.BooleanOperation.SetTargetBodies(targetBodies90)
    
    extrudeBuilder16.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder16.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder16.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder16.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder16 = extrudeBuilder16.SmartVolumeProfile
    
    smartVolumeProfileBuilder16.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder16.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId244, "Extrude Dialog")
    
    section16.DistanceTolerance = 0.01
    
    section16.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section16.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder16.Destroy()
    
    section16.Destroy()
    
    workPart.Expressions.Delete(expression122)
    
    theSession.UndoToMark(markId244, None)
    
    theSession.DeleteUndoMark(markId244, None)
    
    # ----------------------------------------------
    #   Menu: File->Execute->Grip...
    # ----------------------------------------------
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.37179416597019688
    rotMatrix13.Xy = 0.92602074321647632
    rotMatrix13.Xz = -0.065227917974811131
    rotMatrix13.Yx = 0.19866870658626995
    rotMatrix13.Yy = -0.01073408979893177
    rotMatrix13.Yz = 0.9800079205493829
    rotMatrix13.Zx = 0.90680750061623294
    rotMatrix13.Zy = -0.3773199735622158
    rotMatrix13.Zz = -0.18796221529111756
    translation13 = NXOpen.Point3d(5.5844792447706979, -26.499756334014023, -290.9755153722524)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.3170048460696151)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = -0.68534317930931077
    rotMatrix14.Xy = 0.71535797537218437
    rotMatrix14.Xz = 0.13626332465344634
    rotMatrix14.Yx = -0.046522114537170055
    rotMatrix14.Yy = -0.2297456639780881
    rotMatrix14.Yz = 0.97213817060243857
    rotMatrix14.Zx = 0.72673270150254687
    rotMatrix14.Zy = 0.65990900657187246
    rotMatrix14.Zz = 0.19073458944861538
    translation14 = NXOpen.Point3d(49.824488505465268, -24.673234644081312, -230.24493477142718)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 1.3170048460696151)
    
    # ----------------------------------------------
    #   Menu: Edit->Selection->Highlight Hidden Edges
    # ----------------------------------------------
    selPref1 = workPart.SelPref.CreateSelPref()
    
    selPref1.HighlightHiddenEdgesToggle = True
    
    nXObject41 = selPref1.Commit()
    
    selPref1.Destroy()
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = -0.72804545357293937
    rotMatrix15.Xy = 0.68135002487357021
    rotMatrix15.Xz = 0.075577517401368921
    rotMatrix15.Yx = -0.1343207980264845
    rotMatrix15.Yy = -0.24989186016792908
    rotMatrix15.Yz = 0.95891187365645769
    rotMatrix15.Zx = 0.67224083537769086
    rotMatrix15.Zy = 0.68797979754248417
    rotMatrix15.Zz = 0.27345211175652978
    translation15 = NXOpen.Point3d(52.318436667058663, -20.184230755368532, -227.97949482070632)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 1.3170048460696151)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = -0.75234889818628226
    rotMatrix16.Xy = 0.6548679956551251
    rotMatrix16.Xz = 0.071547492370606744
    rotMatrix16.Yx = 0.10367763987486864
    rotMatrix16.Yy = 0.010450605226095415
    rotMatrix16.Yz = 0.99455604761138727
    rotMatrix16.Zx = 0.65055521086826973
    rotMatrix16.Zy = 0.75567102175288392
    rotMatrix16.Zz = -0.075757669546341125
    translation16 = NXOpen.Point3d(52.318697404252291, -20.002024759343456, -211.26756600517382)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 1.3170048460696151)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.14518817055255509
    rotMatrix17.Xy = 0.87947067544445767
    rotMatrix17.Xz = 0.45326783049855895
    rotMatrix17.Yx = -0.19515616462081187
    rotMatrix17.Yy = -0.42366595024089798
    rotMatrix17.Yz = 0.8845457783613967
    rotMatrix17.Zx = 0.96996621927884197
    rotMatrix17.Zy = -0.2168835946763715
    rotMatrix17.Zz = 0.11012283967532957
    translation17 = NXOpen.Point3d(-0.46327692187644232, -24.543656066997535, -294.82662004526804)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 1.3170048460696151)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = -0.40039633399449681
    rotMatrix18.Xy = 0.91569190639734821
    rotMatrix18.Xz = -0.03451243663019142
    rotMatrix18.Yx = -0.87534010423670883
    rotMatrix18.Yy = -0.37106891908466039
    rotMatrix18.Yz = 0.30997993355087111
    rotMatrix18.Zx = 0.27103962374277807
    rotMatrix18.Zy = 0.15432494888296383
    rotMatrix18.Zz = 0.95011648365536772
    translation18 = NXOpen.Point3d(50.297925889804489, 38.096592135672601, -257.91830512889504)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 1.3170048460696151)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = -0.18642253399303482
    rotMatrix19.Xy = 0.98132273334397191
    rotMatrix19.Xz = 0.047458738309494944
    rotMatrix19.Yx = -0.12588883548744295
    rotMatrix19.Yy = -0.071766736600119091
    rotMatrix19.Yz = 0.98944506498207307
    rotMatrix19.Zx = 0.97437089443354363
    rotMatrix19.Zy = 0.17848033096137764
    rotMatrix19.Zz = 0.13691651303143312
    translation19 = NXOpen.Point3d(38.733284320974391, -10.994969811724928, -272.23985940035834)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 1.3170048460696151)
    
    scaleAboutPoint627 = NXOpen.Point3d(60.369779127193631, 28.929278516858339, 0.0)
    viewCenter627 = NXOpen.Point3d(-60.369779127194093, -28.92927851685829, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint627, viewCenter627)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()