﻿# NX 1872
# Journal created by liyu8 on Wed Jun 19 20:41:56 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "Z:\\model1.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane1 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane1
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch Dialog")
    
    datumAxis1 = workPart.Datums.FindObject("DATUM_CSYS(0) X axis")
    direction1 = workPart.Directions.CreateDirection(datumAxis1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XY plane")
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    point1 = datumCsys1.FindObject("POINT 1")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(datumPlane1, direction1, point1, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.Csystem = cartesianCoordinateSystem1
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane2.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    geom1[0] = datumPlane1
    plane2.SetGeometry(geom1)
    
    plane2.SetFlip(False)
    
    plane2.SetExpression(None)
    
    plane2.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane2.Evaluate()
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression3 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression4 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane3.SynchronizeToPlane(plane2)
    
    plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane3.SetGeometry(geom2)
    
    plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane3.Evaluate()
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature1 = sketch1.Feature
    
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId7)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane1.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId9, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 2 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(81.0, 0.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(81.0, 0.0, 0.0)
    endPoint2 = NXOpen.Point3d(81.0, -49.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(81.0, -49.0, 0.0)
    endPoint3 = NXOpen.Point3d(0.0, -49.0, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(0.0, -49.0, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line1
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point2 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point2
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(40.5, -10.497347910803205, 0.0)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression5 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(70.5026520891968, -24.5, 0.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression6 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.ModelView
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits3 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits7 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits11 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits19 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    point3 = NXOpen.Point3d(58.788793212966993, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line1, workPart.ModelingViews.WorkView, point3)
    
    point1_1 = NXOpen.Point3d(81.0, 0.0, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, workPart.ModelingViews.WorkView, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, workPart.ModelingViews.WorkView, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    dimensionlinearunits21 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits25 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point4 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point4
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point5 = NXOpen.Point3d(45.51888188405583, 24.996809712600133, 0.0)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point5)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject3 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId11, None)
    
    theSession.SetUndoMarkName(markId10, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId10, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines5 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId12, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits27 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression7 = workPart.Expressions.FindObject("p0")
    expression7.SetFormula("48")
    
    theSession.SetUndoMarkVisibility(markId12, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.59259259259259256)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId13, None)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId12, "Edit Driving Value")
    
    point6 = NXOpen.Point3d(48.0, -18.207552753622309, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(line2, workPart.ModelingViews.WorkView, point6)
    
    point1_3 = NXOpen.Point3d(48.0, -29.037037037037035, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, workPart.ModelingViews.WorkView, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(48.0, 0.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point7 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point7
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder2.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point8 = NXOpen.Point3d(63.726434637678139, -17.590347575533425, 0.0)
    sketchRapidDimensionBuilder2.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point8)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.TextCentered = False
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject4 = sketchRapidDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId15, None)
    
    theSession.SetUndoMarkName(markId14, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId14, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId16, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    expression8 = workPart.Expressions.FindObject("p1")
    expression8.SetFormula("16")
    
    theSession.SetUndoMarkVisibility(markId16, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId17, None)
    
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId16, "Edit Driving Value")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.95646044686456722
    rotMatrix1.Xy = -0.1338854202078488
    rotMatrix1.Xz = -0.25934168164682014
    rotMatrix1.Yx = 0.0041032144205480981
    rotMatrix1.Yy = 0.8946569972346311
    rotMatrix1.Yz = -0.44673484409717806
    rotMatrix1.Zx = 0.2918331324833624
    rotMatrix1.Zy = 0.42622007408717794
    rotMatrix1.Zz = 0.85625339195244543
    translation1 = NXOpen.Point3d(2.0563896830495096, -0.19029267945398845, -13.769395029284707)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 0.85735940891677709)
    
    expression8.SetFormula("30")
    
    theSession.SetUndoMarkVisibility(markId18, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId19, None)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId18, "Edit Driving Value")
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.99719911418614926
    rotMatrix2.Xy = 0.037987891091312877
    rotMatrix2.Xz = 0.06442706571615256
    rotMatrix2.Yx = -0.048534744672641829
    rotMatrix2.Yy = 0.98407835032378732
    rotMatrix2.Yz = 0.17098005434428101
    rotMatrix2.Zx = -0.056906108862936719
    rotMatrix2.Zy = -0.17362810992015668
    rotMatrix2.Zz = 0.9831657918274167
    translation2 = NXOpen.Point3d(0.65174951150939364, 1.6778207269005785, -1.5962968578906767)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 0.85735940891677709)
    
    scaleAboutPoint1 = NXOpen.Point3d(68.664076062389285, 37.340913274377968, 0.0)
    viewCenter1 = NXOpen.Point3d(-68.664076062389285, -37.340913274377968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint1, viewCenter1)
    
    expression8.SetFormula("30")
    
    theSession.SetUndoMarkVisibility(markId20, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId21, None)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId20, "Edit Driving Value")
    
    expression8.SetFormula("30")
    
    theSession.SetUndoMarkVisibility(markId22, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId23, None)
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId22, "Edit Driving Value")
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId24, None)
    
    theSession.DeleteUndoMark(markId24, None)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.92728859755755932
    rotMatrix3.Xy = -0.3740572324548071
    rotMatrix3.Xz = -0.014732402654852523
    rotMatrix3.Yx = -0.28503681686864807
    rotMatrix3.Yy = -0.73102442307159321
    rotMatrix3.Yz = 0.61996556831991001
    rotMatrix3.Zx = -0.24267235085423955
    rotMatrix3.Zy = -0.57068772522377909
    rotMatrix3.Zz = -0.78449069491599643
    translation3 = NXOpen.Point3d(-11.398822415085192, -0.67723982971785013, 4.1290861051744105)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 1.0716992611459715)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch2 = theSession.ActiveSketch
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression9 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId26, "Extrude Dialog")
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("25")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature1
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = curveFeatureRule1
    helpPoint1 = NXOpen.Point3d(34.399457737850604, -29.999999999999996, 1.7763568394002505e-15)
    section1.AddToSection(rules1, line3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId28, None)
    
    direction2 = workPart.Directions.CreateDirection(sketch2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction2
    
    expression10 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId27, None)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("70")
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = 0.97804443910693328
    rotMatrix4.Xy = 0.036302413962530637
    rotMatrix4.Xz = 0.20521016025649702
    rotMatrix4.Yx = -0.20834149026708126
    rotMatrix4.Yy = 0.14771812972709358
    rotMatrix4.Yz = 0.96683668609710005
    rotMatrix4.Zx = 0.0047852445387716932
    rotMatrix4.Zy = -0.98836303496762901
    rotMatrix4.Zz = 0.15203819436010657
    translation4 = NXOpen.Point3d(-15.404739540425417, -3.4985939651881921, 27.733595738136199)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 0.85735940891677709)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("75")
    
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId29, None)
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    feature2 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId30, None)
    
    theSession.SetUndoMarkName(markId26, "Extrude")
    
    expression11 = extrudeBuilder1.Limits.StartExtend.Value
    expression12 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression9)
    
    workPart.Expressions.Delete(expression10)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.96091872103159703
    rotMatrix5.Xy = 0.23948930246219996
    rotMatrix5.Xz = -0.13885274782001517
    rotMatrix5.Yx = -0.17241896916152108
    rotMatrix5.Yy = 0.9101751826029103
    rotMatrix5.Yz = 0.37663355671930848
    rotMatrix5.Zx = 0.21658003288456326
    rotMatrix5.Zy = -0.33797338797592774
    rotMatrix5.Zz = 0.91589687103723305
    translation5 = NXOpen.Point3d(0.95644007374690077, 29.208738673082806, 3.7616651473204819)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 0.85735940891677709)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane4
    
    expression13 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId31, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature2
    edge1 = extrude1.FindObject("EDGE * 130 * 140 {(48,-30,75)(24,-30,75)(0,-30,75) EXTRUDE(2)}")
    point9 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge2 = extrude1.FindObject("EDGE * 130 * 160 {(0,0,75)(24,0,75)(48,0,75) EXTRUDE(2)}")
    direction3 = workPart.Directions.CreateDirection(edge2, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 130 {(24,-15,75) EXTRUDE(2)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction3, point9, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.Csystem = cartesianCoordinateSystem2
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal6 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression16 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point10 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId32, None)
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject5 = sketchInPlaceBuilder2.Commit()
    
    sketch3 = nXObject5
    feature3 = sketch3.Feature
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs2 = theSession.UpdateManager.DoUpdate(markId34)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId33, None)
    
    theSession.SetUndoMarkName(markId31, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression14)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point10)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression16)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression15)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint2 = NXOpen.Point3d(-8.1779686096777873, 9.8752828494222715, 0.0)
    viewCenter2 = NXOpen.Point3d(8.1779686096777873, -9.8752828494222715, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(-6.5423748877422288, 7.9002262795377955, 0.0)
    viewCenter3 = NXOpen.Point3d(6.5423748877422288, -7.9002262795378364, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint3, viewCenter3)
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId36, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(22.000000000000014, -12.999999999999993, 75.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 7.1274927527366829, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_3.Geometry = arc1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 0.0
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(22.000000000000014, -10.760565779028642, 75.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression17 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines17 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines20)
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_5 = NXOpen.Point3d(22.000000000000014, -12.999999999999993, 75.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(22.000000000000014, -12.999999999999993, 75.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    point1_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point11 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point11
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder4.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point12 = NXOpen.Point3d(40.612054018275963, 13.05623322348108, 75.0)
    sketchRapidDimensionBuilder4.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point12)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.TextCentered = False
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject6 = sketchRapidDimensionBuilder4.Commit()
    
    theSession.DeleteUndoMark(markId38, None)
    
    theSession.SetUndoMarkName(markId37, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId37, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId39, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    expression18 = workPart.Expressions.FindObject("p4")
    expression18.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId39, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(1.0522634340276333)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId40, None)
    
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId39, "Edit Driving Value")
    
    point1_8 = NXOpen.Point3d(20.641150715281547, -12.111521621530226, 75.0)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(20.641150715281547, -12.111521621530226, 75.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    edge3 = extrude1.FindObject("EDGE * 130 * 170 {(48,0,75)(48,-15,75)(48,-30,75) EXTRUDE(2)}")
    point13 = NXOpen.Point3d(48.000000000000007, -9.854422987178598, 75.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(edge3, workPart.ModelingViews.WorkView, point13)
    
    point1_11 = NXOpen.Point3d(48.000000000000007, -9.854422987178598, 75.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    point1_12 = NXOpen.Point3d(20.641150715281547, -12.111521621530226, 75.0)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(48.000000000000007, -9.854422987178598, 75.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge3, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    point1_14 = NXOpen.Point3d(20.641150715281547, -12.111521621530226, 75.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point14 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin4.PointOnGeometry = point14
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point15 = NXOpen.Point3d(38.834503105379959, 26.289112241706931, 75.0)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point15)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject7 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId42, None)
    
    theSession.SetUndoMarkName(markId41, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId41, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines25 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines28)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId43, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    expression19 = workPart.Expressions.FindObject("p5")
    expression19.SetFormula("24")
    
    theSession.SetUndoMarkVisibility(markId43, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId44, None)
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId43, "Edit Driving Value")
    
    point1_15 = NXOpen.Point3d(24.000000000000007, -12.111521621530226, 75.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    point1_16 = NXOpen.Point3d(24.000000000000007, -12.111521621530226, 75.0)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, workPart.ModelingViews.WorkView, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point1_18 = NXOpen.Point3d(24.000000000000011, -30.0, 75.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(24.000000000000007, -12.111521621530226, 75.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    point1_20 = NXOpen.Point3d(24.000000000000011, -30.0, 75.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(24.000000000000007, -12.111521621530226, 75.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc1, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    point1_22 = NXOpen.Point3d(24.000000000000011, -30.0, 75.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, edge1, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    point16 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin5.PointOnGeometry = point16
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point17 = NXOpen.Point3d(72.212959136427244, -17.359637952739526, 75.0)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point17)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = False
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject8 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId46, None)
    
    theSession.SetUndoMarkName(markId45, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId45, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId47, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression20 = workPart.Expressions.FindObject("p6")
    expression20.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId47, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId48, None)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId47, "Edit Driving Value")
    
    sketchRapidDimensionBuilder7.Destroy()
    
    theSession.UndoToMark(markId49, None)
    
    theSession.DeleteUndoMark(markId49, None)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = 0.99569835457582123
    rotMatrix6.Xy = 0.010666342109894393
    rotMatrix6.Xz = -0.092038121672471745
    rotMatrix6.Yx = 0.073210085330851604
    rotMatrix6.Yy = 0.51827643554340708
    rotMatrix6.Yz = 0.85207383469172981
    rotMatrix6.Zx = 0.056789700658230656
    rotMatrix6.Zy = -0.85514663392099899
    rotMatrix6.Zz = 0.51526611026995917
    translation6 = NXOpen.Point3d(-41.410341889777385, -9.6340802511075925, -61.34125450092376)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.3396240764324641)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.99831119610910168
    rotMatrix7.Xy = -0.048406062930331006
    rotMatrix7.Xz = -0.032118667388283409
    rotMatrix7.Yx = 0.058071163944733821
    rotMatrix7.Yy = 0.84657652628051849
    rotMatrix7.Yz = 0.52908971362984625
    rotMatrix7.Zx = 0.0015797598925751982
    rotMatrix7.Zy = -0.5300613532624262
    rotMatrix7.Zz = 0.84795782096534
    translation7 = NXOpen.Point3d(-43.919231876190345, 3.9571071367177968, -70.810059764706324)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 1.3396240764324641)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    holeDimension1 = nXObject6
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(holeDimension1)
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId50, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits195 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits197 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits201 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits207 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits209 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId51, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("15.8")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("15.8")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject9 = sketchRadialDimensionBuilder1.Commit()
    
    point1_23 = NXOpen.Point3d(24.000000000000007, -15.000000000000004, 75.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc1, NXOpen.View.Null, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    theSession.SetUndoMarkName(markId52, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    point18 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin6.PointOnGeometry = point18
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point19 = NXOpen.Point3d(-45.193858875612605, -51.013625534259234, 75.0)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point19)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits213 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId53, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId53, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    point20 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin7.PointOnGeometry = point20
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point21 = NXOpen.Point3d(104.13675471738179, -47.725646863703687, 75.0)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point21)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits225 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId54, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject10 = sketchRadialDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId56, None)
    
    theSession.SetUndoMarkName(markId50, "Radial Dimension")
    
    expression21 = sketchRadialDimensionBuilder1.Driving.ExpressionValue
    sketchRadialDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId55, None)
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId54, None)
    
    theSession.DeleteUndoMark(markId53, None)
    
    theSession.DeleteUndoMark(markId52, None)
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch4 = theSession.ActiveSketch
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression22 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("75")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId58, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature3
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 1 
    rules2[0] = curveFeatureRule2
    helpPoint2 = NXOpen.Point3d(30.641799370298177, -10.755635099207268, 75.0)
    section2.AddToSection(rules2, arc1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId60, None)
    
    direction4 = workPart.Directions.CreateDirection(sketch4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction4
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies4[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies5)
    
    expression23 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId59, None)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = body1
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies6)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.99670348155787669
    rotMatrix8.Xy = -0.031200073235232731
    rotMatrix8.Xz = 0.074891423277460956
    rotMatrix8.Yx = -0.071194450063177692
    rotMatrix8.Yy = 0.10629098166181765
    rotMatrix8.Yz = 0.99178302944624319
    rotMatrix8.Zx = -0.038903986050395661
    rotMatrix8.Zy = -0.99384545209377584
    rotMatrix8.Zz = 0.1037193194246247
    translation8 = NXOpen.Point3d(-13.709645312168337, -13.182435797374815, 47.110406499026929)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 0.85735940891677709)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    feature4 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId61, None)
    
    theSession.SetUndoMarkName(markId58, "Extrude")
    
    expression24 = extrudeBuilder2.Limits.StartExtend.Value
    expression25 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression22)
    
    workPart.Expressions.Delete(expression23)
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression26 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId62, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    extrudeBuilder3.Destroy()
    
    section3.Destroy()
    
    workPart.Expressions.Delete(expression26)
    
    theSession.UndoToMark(markId62, None)
    
    theSession.DeleteUndoMark(markId62, None)
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.12199510182886947
    rotMatrix9.Xy = 0.99249569523866243
    rotMatrix9.Xz = 0.0083360699664561388
    rotMatrix9.Yx = 0.21526184059526893
    rotMatrix9.Yy = -0.034656477239205445
    rotMatrix9.Yz = 0.97594122188219123
    rotMatrix9.Zx = 0.96890636034309374
    rotMatrix9.Zy = -0.11726561097819876
    rotMatrix9.Zz = -0.21787437060978229
    translation9 = NXOpen.Point3d(25.633783227431486, -21.458717316310548, 50.543371853865175)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 0.85735940891677709)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane7 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane7
    
    expression27 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression28 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId63, "Create Sketch Dialog")
    
    scalar3 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point22 = workPart.Points.CreatePoint(edge3, scalar3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge4 = extrude1.FindObject("EDGE * 120 * 170 {(48,0,0)(48,-15,0)(48,-30,0) EXTRUDE(2)}")
    direction5 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude1.FindObject("FACE 170 {(48,-15,37.5) EXTRUDE(2)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction5, point22, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem3
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin8, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane8.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom6 = [NXOpen.NXObject.Null] * 1 
    geom6[0] = face2
    plane8.SetGeometry(geom6)
    
    plane8.SetFlip(False)
    
    plane8.SetExpression(None)
    
    plane8.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane8.Evaluate()
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin9, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression29 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression30 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane9.SynchronizeToPlane(plane8)
    
    scalar4 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point23 = workPart.Points.CreatePoint(edge3, scalar4, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom7 = [NXOpen.NXObject.Null] * 1 
    geom7[0] = face2
    plane9.SetGeometry(geom7)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId64, None)
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject11 = sketchInPlaceBuilder3.Commit()
    
    sketch5 = nXObject11
    feature5 = sketch5.Feature
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs3 = theSession.UpdateManager.DoUpdate(markId66)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId65, None)
    
    theSession.SetUndoMarkName(markId63, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression28)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point23)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression27)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane7.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression30)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression29)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane9.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId68, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(48.000000000000014, -15.999999999999993, 51.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 5.747379713674003, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = arc2
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(48.000000000000014, -15.999999999999993, 54.499115970267738)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension4 = sketchDimensionalConstraint4.AssociatedDimension
    
    expression31 = sketchDimensionalConstraint4.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint4 = NXOpen.Point3d(-149.20935180298963, 8.0236673151555973, 0.0)
    viewCenter4 = NXOpen.Point3d(149.20935180298963, -8.0236673151555973, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines33 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines36)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines37 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines40)
    
    theSession.SetUndoMarkName(markId69, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits237 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits241 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits247 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits249 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits251 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint5 = NXOpen.Point3d(55.178142921146978, -39.254249326453561, 0.0)
    viewCenter5 = NXOpen.Point3d(-55.178142921146964, 39.254249326453547, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(50.265189703559386, -37.921086141781537, 0.0)
    viewCenter6 = NXOpen.Point3d(-50.265189703559351, 37.921086141781537, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(40.212151762847505, -30.336868913425231, 0.0)
    viewCenter7 = NXOpen.Point3d(-40.212151762847483, 30.336868913425242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(32.169721410278001, -24.269495130740172, 0.0)
    viewCenter8 = NXOpen.Point3d(-32.16972141027798, 24.269495130740182, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    point1_24 = NXOpen.Point3d(48.000000000000014, -15.999999999999993, 51.0)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    point1_25 = NXOpen.Point3d(48.000000000000014, -15.999999999999993, 51.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    dimensionlinearunits257 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits261 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point24 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point24
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point25 = NXOpen.Point3d(48.000000000000014, 6.211724056960783, 65.517950913641698)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point25)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject12 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId70, None)
    
    theSession.SetUndoMarkName(markId69, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId69, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId71, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits263 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits273 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits275 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits279 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression32 = workPart.Expressions.FindObject("p9")
    expression32.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId71, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(0.86996166063350133)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId72, None)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId71, "Edit Driving Value")
    
    point1_27 = NXOpen.Point3d(48.000000000000014, -17.820536751130973, 54.120920144795967)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(48.000000000000014, -17.820536751130973, 54.120920144795967)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    point1_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    dimensionlinearunits283 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    edge5 = extrude1.FindObject("EDGE * 160 * 170 {(48,0,75)(48,0,37.5)(48,0,0) EXTRUDE(2)}")
    point26 = NXOpen.Point3d(48.0, 0.0, 55.506784172211376)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(edge5, workPart.ModelingViews.WorkView, point26)
    
    point1_30 = NXOpen.Point3d(48.0, 0.0, 55.506784172211376)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge5, workPart.ModelingViews.WorkView, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    point1_31 = NXOpen.Point3d(48.000000000000014, -17.820536751130973, 54.120920144795967)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(48.0, 0.0, 55.506784172211376)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge5, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    point1_33 = NXOpen.Point3d(48.000000000000014, -17.820536751130973, 54.120920144795967)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    dimensionlinearunits289 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point27 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point27
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point28 = NXOpen.Point3d(48.000000000000014, -2.4848450315544532, 79.472910613817305)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point28)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject13 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId74, None)
    
    theSession.SetUndoMarkName(markId73, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId73, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId75, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression33 = workPart.Expressions.FindObject("p10")
    expression33.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId75, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId76, None)
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId75, "Edit Driving Value")
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.27739660594706772
    rotMatrix10.Xy = 0.95701450945218403
    rotMatrix10.Xz = -0.084701544891717745
    rotMatrix10.Yx = 0.046653997058033386
    rotMatrix10.Yy = 0.074639544619618622
    rotMatrix10.Yz = 0.99611863898708608
    rotMatrix10.Zx = 0.95962207538569855
    rotMatrix10.Zy = -0.28027159520181855
    rotMatrix10.Zz = -0.023943795761560738
    translation10 = NXOpen.Point3d(21.038177581730018, -50.511543668543545, -48.513936542853301)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 2.6164532742821569)
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point29 = NXOpen.Point3d(97.302745121910462, -16.675466921834939, 64.049384732058527)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(perpendicularDimension1, workPart.ModelingViews.WorkView, point29)
    
    line5 = theSession.ActiveSketch.FindObject("Curve DATUM3")
    point1_34 = NXOpen.Point3d(48.000000000000014, -15.712499999999993, 75.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line5, NXOpen.View.Null, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    sketchRapidDimensionBuilder10.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder1 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList1 = convertToFromReferenceBuilder1.InputObjects
    
    added1 = selectNXObjectList1.Add(perpendicularDimension1)
    
    convertToFromReferenceBuilder1.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject14 = convertToFromReferenceBuilder1.Commit()
    
    convertToFromReferenceBuilder1.Destroy()
    
    expression34 = workPart.Expressions.FindObject("p11")
    expression34.SetFormula("30")
    
    theSession.SetUndoMarkVisibility(markId77, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId78, None)
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId77, "Edit Driving Value")
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 0.99131478547602891
    rotMatrix11.Xy = -0.067246409692737527
    rotMatrix11.Xz = 0.11301732822912526
    rotMatrix11.Yx = 0.0032508703767380868
    rotMatrix11.Yy = 0.87164677948582003
    rotMatrix11.Yz = 0.490123784011541
    rotMatrix11.Zx = -0.13147025495680481
    rotMatrix11.Zy = -0.48549954911970278
    rotMatrix11.Zz = 0.86429494957806896
    translation11 = NXOpen.Point3d(-16.251407709322095, -19.303316302296338, -61.26825436849721)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 2.6164532742821569)
    
    scaleAboutPoint9 = NXOpen.Point3d(56.376014730781897, -16.58415500600578, 0.0)
    viewCenter9 = NXOpen.Point3d(-56.376014730781847, 16.584155006005798, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(69.585193070169126, -20.098175655144196, 0.0)
    viewCenter10 = NXOpen.Point3d(-69.585193070169055, 20.098175655144217, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(86.191468709757586, -25.596733145702526, 0.0)
    viewCenter11 = NXOpen.Point3d(-86.191468709757558, 25.596733145702526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(107.34432457322013, -32.390927746105056, 0.0)
    viewCenter12 = NXOpen.Point3d(-107.34432457322006, 32.390927746105056, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(132.45223121787623, -42.216834181280213, 0.0)
    viewCenter13 = NXOpen.Point3d(-132.4522312178762, 42.216834181280213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(163.40507089903417, -57.091478973222522, 0.0)
    viewCenter14 = NXOpen.Point3d(-163.40507089903414, 57.091478973222522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.9983622570595827
    rotMatrix12.Xy = 0.033295329288062808
    rotMatrix12.Xz = -0.046521228772404208
    rotMatrix12.Yx = 0.04259580538976359
    rotMatrix12.Yy = 0.11020561991712668
    rotMatrix12.Yz = 0.99299562874258285
    rotMatrix12.Zx = 0.038189017296759054
    rotMatrix12.Zy = -0.99335096636902753
    rotMatrix12.Zz = 0.10860689007437027
    translation12 = NXOpen.Point3d(71.758181653702252, -71.412768068559444, -35.904075766426082)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.0716992611459717)
    
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.67883653397363208
    rotMatrix13.Xy = 0.72558518949236195
    rotMatrix13.Xz = -0.11272574210001945
    rotMatrix13.Yx = 0.027093230663070195
    rotMatrix13.Yy = 0.12866197139171537
    rotMatrix13.Yz = 0.99131834138677843
    rotMatrix13.Zx = 0.73378942278756143
    rotMatrix13.Zy = -0.67599721146387126
    rotMatrix13.Zz = 0.06768199980914201
    translation13 = NXOpen.Point3d(90.638676031932278, -70.662410717242864, -57.030769104468021)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 1.0716992611459717)
    
    expression34.SetFormula("20")
    
    theSession.SetUndoMarkVisibility(markId79, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId80, None)
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId79, "Edit Driving Value")
    
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId81, None)
    
    theSession.DeleteUndoMark(markId81, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch6 = theSession.ActiveSketch
    
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression35 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies9)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    targetBodies10[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies10)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId83, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature5
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section4.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule3
    helpPoint3 = NXOpen.Point3d(48.000000000000014, -10.373172758152501, 56.848856532932444)
    section4.AddToSection(rules3, arc2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId85, None)
    
    direction6 = workPart.Directions.CreateDirection(sketch6, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction6
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies12)
    
    expression36 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId84, None)
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.53439937921074177
    rotMatrix14.Xy = 0.84092996723447355
    rotMatrix14.Xz = -0.085170967507711887
    rotMatrix14.Yx = 0.1741183220908061
    rotMatrix14.Yy = -0.010921150512473816
    rotMatrix14.Yz = 0.98466417543432816
    rotMatrix14.Zx = 0.82710344782950607
    rotMatrix14.Zy = -0.54103375003645482
    rotMatrix14.Zz = -0.1522575709448763
    translation14 = NXOpen.Point3d(22.926422665613863, -21.091948584535331, 46.13400959325449)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 0.85735940891677709)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.98444396766636943
    rotMatrix15.Xy = 0.06260159820677251
    rotMatrix15.Xz = -0.16416794579714503
    rotMatrix15.Yx = 0.15188598081717208
    rotMatrix15.Yy = 0.16647834881672105
    rotMatrix15.Yz = 0.97427696688696452
    rotMatrix15.Zx = 0.088321703768112381
    rotMatrix15.Zy = -0.9840558923542978
    rotMatrix15.Zz = 0.1543803010953205
    translation15 = NXOpen.Point3d(13.996380942649644, -18.888200232842017, 38.96589798550356)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 0.85735940891677709)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    feature6 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId86, None)
    
    theSession.SetUndoMarkName(markId83, "Extrude")
    
    expression37 = extrudeBuilder4.Limits.StartExtend.Value
    expression38 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression35)
    
    workPart.Expressions.Delete(expression36)
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId87, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.014279721017802496
    rotMatrix16.Xy = -0.99173836127619119
    rotMatrix16.Xz = 0.12747985072498491
    rotMatrix16.Yx = -0.15661088924894731
    rotMatrix16.Yy = 0.1237009778140766
    rotMatrix16.Yz = 0.97988320602839896
    rotMatrix16.Zx = -0.98755714717494025
    rotMatrix16.Zy = -0.033957191595478678
    rotMatrix16.Zz = -0.1535506112089442
    translation16 = NXOpen.Point3d(15.6173044763392, -10.064490152163472, 100.96445335528395)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 0.85735940891677709)
    
    scalar5 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge6 = extrude1.FindObject("EDGE * 140 * 150 {(0,-30,75)(0,-30,37.5)(0,-30,0) EXTRUDE(2)}")
    point30 = workPart.Points.CreatePoint(edge6, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge7 = extrude1.FindObject("EDGE * 120 * 150 {(0,-30,0)(0,-15,0)(0,0,0) EXTRUDE(2)}")
    direction7 = workPart.Directions.CreateDirection(edge7, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude1.FindObject("FACE 150 {(0,-15,37.5) EXTRUDE(2)}")
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction7, point30, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    datumCsysBuilder1 = workPart.Features.CreateDatumCsysBuilder(NXOpen.Features.Feature.Null)
    
    datumCsysBuilder1.Csys = cartesianCoordinateSystem4
    
    datumCsysBuilder1.DisplayScaleFactor = 1.25
    
    feature7 = datumCsysBuilder1.CommitFeature()
    
    datumCsysBuilder1.Destroy()
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    theSession.BeginTaskEnvironment()
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder4.Csystem = cartesianCoordinateSystem4
    
    sketchInPlaceBuilder4.PlaneOption = NXOpen.Sketch.PlaneOption.Inferred
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject15 = sketchInPlaceBuilder4.Commit()
    
    sketchInPlaceBuilder4.Destroy()
    
    sketch7 = nXObject15
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.DeleteUndoMarksUpToMark(markId89, None, True)
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Dialog Begin Profile
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId91, "Curve")
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.Preferences.Sketch.SectionView = False
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.SketchOnly)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId88, None)
    
    theSession.DeleteUndoMark(markId88, None)
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    datumCsys3 = feature7
    nErrs4 = theSession.UpdateManager.AddToDeleteList(datumCsys3)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    extrudeBuilder5.Destroy()
    
    section5.Destroy()
    
    workPart.Expressions.Delete(expression39)
    
    theSession.UndoToMark(markId87, None)
    
    theSession.DeleteUndoMark(markId87, None)
    
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin10, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane10
    
    expression40 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression41 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId93, "Create Sketch Dialog")
    
    scalar6 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge8 = extrude1.FindObject("EDGE * 130 * 150 {(0,-30,75)(0,-15,75)(0,0,75) EXTRUDE(2)}")
    point31 = workPart.Points.CreatePoint(edge8, scalar6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction8 = workPart.Directions.CreateDirection(edge7, NXOpen.Sense.Reverse, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction8, point31, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem5
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin11, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane11.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom8 = [NXOpen.NXObject.Null] * 1 
    geom8[0] = face3
    plane11.SetGeometry(geom8)
    
    plane11.SetFlip(False)
    
    plane11.SetExpression(None)
    
    plane11.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane11.Evaluate()
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin12, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane12.SynchronizeToPlane(plane11)
    
    scalar7 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point32 = workPart.Points.CreatePoint(edge8, scalar7, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom9 = [NXOpen.NXObject.Null] * 1 
    geom9[0] = face3
    plane12.SetGeometry(geom9)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId94, None)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject16 = sketchInPlaceBuilder5.Commit()
    
    sketch8 = nXObject16
    feature8 = sketch8.Feature
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId96)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId95, None)
    
    theSession.SetUndoMarkName(markId93, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression41)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point32)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression40)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression43)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane12.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId98, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(0.0, -14.0, 57.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 2.7639320225002102, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = arc3
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_6.SplineDefiningPointIndex = 0
    geom1Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help1.Point.X = 0.0
    geom1Help1.Point.Y = -17.236067977499783
    geom1Help1.Point.Z = 50.527864045000413
    geom1Help1.Parameter = 0.0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude2 = feature6
    edge9 = extrude2.FindObject("EDGE * 130 * 140 {(63,-17.5,59.3301270189222)(63,-10,55)(63,-17.5,50.6698729810778) EXTRUDE(2)}")
    geom2_6.Geometry = edge9
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_6.SplineDefiningPointIndex = 0
    geom2Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help1.Point.X = 0.0
    geom2Help1.Point.Y = -17.236067977499783
    geom2Help1.Point.Z = 50.527864045000413
    geom2Help1.Parameter = 0.0
    sketchTangentConstraint1 = theSession.ActiveSketch.CreateTangentConstraint(geom1_6, geom1Help1, geom2_6, geom2Help1)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = arc3
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_7.SplineDefiningPointIndex = 0
    geom1Help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help2.Point.X = 0.0
    geom1Help2.Point.Y = -12.763932022500317
    geom1Help2.Point.Z = 59.472135954999629
    geom1Help2.Parameter = 0.0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    edge10 = extrude2.FindObject("EDGE * 140 EXTRUDE(2) 170 {(48,-17.5,59.3301270189222)(48,-10,55)(48,-17.5,50.6698729810778) EXTRUDE(2)}")
    geom2_7.Geometry = edge10
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_7.SplineDefiningPointIndex = 0
    geom2Help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help2.Point.X = 0.0
    geom2Help2.Point.Y = -12.763932022500317
    geom2Help2.Point.Z = 59.472135954999629
    geom2Help2.Parameter = 0.0
    sketchTangentConstraint2 = theSession.ActiveSketch.CreateTangentConstraint(geom1_7, geom1Help2, geom2_7, geom2Help2)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = arc3
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_8.SplineDefiningPointIndex = 0
    geom1Help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help3.Point.X = 0.0
    geom1Help3.Point.Y = -12.763932022500308
    geom1Help3.Point.Z = 59.472135954999629
    geom1Help3.Parameter = 0.0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = arc2
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_8.SplineDefiningPointIndex = 0
    geom2Help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help3.Point.X = 0.0
    geom2Help3.Point.Y = -12.763932022500308
    geom2Help3.Point.Z = 59.472135954999629
    geom2Help3.Parameter = 0.0
    sketchTangentConstraint3 = theSession.ActiveSketch.CreateTangentConstraint(geom1_8, geom1Help3, geom2_8, geom2Help3)
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = arc3
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(0.0, -14.0, 60.499115970267738)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension5 = sketchDimensionalConstraint5.AssociatedDimension
    
    expression44 = sketchDimensionalConstraint5.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    scaleAboutPoint15 = NXOpen.Point3d(38.421022336033538, -27.157027835911265, 0.0)
    viewCenter15 = NXOpen.Point3d(-38.421022336033538, 27.157027835911265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(30.736817868826829, -21.72562226872903, 0.0)
    viewCenter16 = NXOpen.Point3d(-30.736817868826829, 21.725622268729012, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    scaleAboutPoint17 = NXOpen.Point3d(24.589454295061444, -17.380497814983208, 0.0)
    viewCenter17 = NXOpen.Point3d(-24.589454295061444, 17.380497814983208, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(18.881540808095341, -14.062402777577336, 0.0)
    viewCenter18 = NXOpen.Point3d(-18.881540808095369, 14.06240277757731, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(14.978829026003718, -11.249922222061858, 0.0)
    viewCenter19 = NXOpen.Point3d(-14.978829026003718, 11.249922222061839, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(11.477448738912544, -8.9999377776494853, 0.0)
    viewCenter20 = NXOpen.Point3d(-11.477448738912527, 8.9999377776494605, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(-1.1730255979857735, -0.32359326840987962, 0.0)
    viewCenter21 = NXOpen.Point3d(1.1730255979857869, 0.32359326840985286, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(-1.1972950931165172, -0.06471865368199195, 0.0)
    viewCenter22 = NXOpen.Point3d(1.1972950931165278, 0.064718653681959892, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(-1.164935766275524, -2.1368826269595465e-14, 0.0)
    viewCenter23 = NXOpen.Point3d(1.1649357662755497, -2.1368826269595465e-14, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint23, viewCenter23)
    
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId99, "Curve")
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    objects1[0] = arc3
    nErrs6 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs7 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId100, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId103, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix4 = theSession.ActiveSketch.Orientation
    
    center4 = NXOpen.Point3d(0.0, -14.200000000000001, 59.299999999999997)
    arc4 = workPart.Curves.CreateArc(center4, nXMatrix4, 3.1902827622389216, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = arc4
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(0.0, -14.200000000000001, 59.769643395537848)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension6 = sketchDimensionalConstraint6.AssociatedDimension
    
    expression45 = sketchDimensionalConstraint6.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder11 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines49 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines52)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder11.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines53 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder11.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder11.AppendedText.SetBelow(lines56)
    
    theSession.SetUndoMarkName(markId104, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder11.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder11.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder11.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder11.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    point1_36 = NXOpen.Point3d(0.0, -16.656364430803535, 61.335725395558555)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc4, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(0.0, -16.656364430803535, 61.335725395558555)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder11.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder11.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder11.Destroy()
    
    theSession.UndoToMark(markId104, None)
    
    theSession.DeleteUndoMark(markId104, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder12 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines57 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines60)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder12.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines61 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBefore(lines61)
    
    lines62 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAfter(lines62)
    
    lines63 = []
    sketchRapidDimensionBuilder12.AppendedText.SetAbove(lines63)
    
    lines64 = []
    sketchRapidDimensionBuilder12.AppendedText.SetBelow(lines64)
    
    theSession.SetUndoMarkName(markId105, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder12.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder12.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    point1_39 = NXOpen.Point3d(0.0, -14.200000000000001, 59.299999999999997)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc4, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(0.0, -14.200000000000001, 59.299999999999997)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    point1_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder12.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder12.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin10 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin10.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin10.View = NXOpen.View.Null
    assocOrigin10.ViewOfGeometry = workPart.ModelingViews.WorkView
    point33 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin10.PointOnGeometry = point33
    assocOrigin10.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.DimensionLine = 0
    assocOrigin10.AssociatedView = NXOpen.View.Null
    assocOrigin10.AssociatedPoint = NXOpen.Point.Null
    assocOrigin10.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin10.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin10.XOffsetFactor = 0.0
    assocOrigin10.YOffsetFactor = 0.0
    assocOrigin10.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder12.Origin.SetAssociativeOrigin(assocOrigin10)
    
    point34 = NXOpen.Point3d(0.0, -19.84077214155182, 61.682965243372024)
    sketchRapidDimensionBuilder12.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point34)
    
    sketchRapidDimensionBuilder12.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder12.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder12.Style.DimensionStyle.TextCentered = False
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject17 = sketchRapidDimensionBuilder12.Commit()
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId105, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId105, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder12.Destroy()
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder13 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines65 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBefore(lines65)
    
    lines66 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAfter(lines66)
    
    lines67 = []
    sketchRapidDimensionBuilder13.AppendedText.SetAbove(lines67)
    
    lines68 = []
    sketchRapidDimensionBuilder13.AppendedText.SetBelow(lines68)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder13.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId107, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder13.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits387 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits388 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder13.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits389 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits390 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits391 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits392 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits393 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits394 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits395 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits396 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits397 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits398 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    expression46 = workPart.Expressions.FindObject("p14")
    expression46.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId107, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.Scale(1.5672591969526048)
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId108, None)
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId107, "Edit Driving Value")
    
    scaleAboutPoint24 = NXOpen.Point3d(14.103489010375725, 0.74555889041631784, 0.0)
    viewCenter24 = NXOpen.Point3d(-14.103489010375704, -0.74555889041635881, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(17.163386956459458, 1.0872733818571332, 0.0)
    viewCenter25 = NXOpen.Point3d(-17.163386956459433, -1.0872733818571887, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(20.354016582980748, 2.5887461472789188, 0.0)
    viewCenter26 = NXOpen.Point3d(-20.354016582980737, -2.5887461472789828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(25.442520728725956, 3.2359326840986493, 0.0)
    viewCenter27 = NXOpen.Point3d(-25.442520728725921, -3.2359326840987293, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(31.80315091090743, 4.0449158551233273, 0.0)
    viewCenter28 = NXOpen.Point3d(-31.803150910907398, -4.0449158551233939, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    point1_42 = NXOpen.Point3d(0.0, -22.255080596726991, 50.394030607844101)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc4, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(0.0, -22.255080596726991, 50.394030607844101)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc4, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    dimensionlinearunits399 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits400 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits401 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits402 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits403 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits404 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    point35 = NXOpen.Point3d(6.9388939039072284e-15, -30.000000000000011, 50.870419772724645)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(edge6, workPart.ModelingViews.WorkView, point35)
    
    point1_45 = NXOpen.Point3d(6.9388939039072284e-15, -30.000000000000011, 50.870419772724645)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    point1_46 = NXOpen.Point3d(0.0, -22.255080596726991, 50.394030607844101)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc4, workPart.ModelingViews.WorkView, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(6.9388939039072284e-15, -30.000000000000011, 50.870419772724645)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge6, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    point1_48 = NXOpen.Point3d(0.0, -22.255080596726991, 50.394030607844101)
    point2_48 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder13.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc4, workPart.ModelingViews.WorkView, point1_48, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_48)
    
    dimensionlinearunits405 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits406 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits407 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits408 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits409 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits410 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits411 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits412 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits413 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits414 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits415 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits416 = sketchRapidDimensionBuilder13.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin11 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin11.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin11.View = NXOpen.View.Null
    assocOrigin11.ViewOfGeometry = workPart.ModelingViews.WorkView
    point36 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin11.PointOnGeometry = point36
    assocOrigin11.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.DimensionLine = 0
    assocOrigin11.AssociatedView = NXOpen.View.Null
    assocOrigin11.AssociatedPoint = NXOpen.Point.Null
    assocOrigin11.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin11.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin11.XOffsetFactor = 0.0
    assocOrigin11.YOffsetFactor = 0.0
    assocOrigin11.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder13.Origin.SetAssociativeOrigin(assocOrigin11)
    
    point37 = NXOpen.Point3d(0.0, -28.650153933266456, 80.575270583786789)
    sketchRapidDimensionBuilder13.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point37)
    
    sketchRapidDimensionBuilder13.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder13.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder13.Style.DimensionStyle.TextCentered = False
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject18 = sketchRapidDimensionBuilder13.Commit()
    
    theSession.DeleteUndoMark(markId110, None)
    
    theSession.SetUndoMarkName(markId109, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId109, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder13.Destroy()
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder14 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines69 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBefore(lines69)
    
    lines70 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAfter(lines70)
    
    lines71 = []
    sketchRapidDimensionBuilder14.AppendedText.SetAbove(lines71)
    
    lines72 = []
    sketchRapidDimensionBuilder14.AppendedText.SetBelow(lines72)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder14.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId111, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder14.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits417 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits418 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits419 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits420 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits421 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits422 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits423 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits424 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits425 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits426 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder14.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder14.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder14.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits427 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits428 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits429 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits430 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits431 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits432 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits433 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits434 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits435 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits436 = sketchRapidDimensionBuilder14.Style.UnitsStyle.DimensionLinearUnits
    
    expression47 = workPart.Expressions.FindObject("p15")
    expression47.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId111, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId112, None)
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId111, "Edit Driving Value")
    
    perpendicularDimension2 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point38 = NXOpen.Point3d(9.5644915013408283e-16, -17.845101044177291, 69.704559223142766)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(perpendicularDimension2, workPart.ModelingViews.WorkView, point38)
    
    line6 = theSession.ActiveSketch.FindObject("Curve DATUM7")
    point1_49 = NXOpen.Point3d(1.9246855257099588e-15, -14.2875, 75.0)
    point2_49 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line6, NXOpen.View.Null, point1_49, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_49)
    
    point1_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_50 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder14.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_50, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_50)
    
    sketchRapidDimensionBuilder14.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder2 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList2 = convertToFromReferenceBuilder2.InputObjects
    
    added2 = selectNXObjectList2.Add(perpendicularDimension2)
    
    convertToFromReferenceBuilder2.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject19 = convertToFromReferenceBuilder2.Commit()
    
    convertToFromReferenceBuilder2.Destroy()
    
    expression48 = workPart.Expressions.FindObject("p16")
    expression48.SetFormula("20")
    
    theSession.SetUndoMarkVisibility(markId113, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId114, None)
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId113, "Edit Driving Value")
    
    sketchRapidDimensionBuilder14.Destroy()
    
    theSession.UndoToMark(markId115, None)
    
    theSession.DeleteUndoMark(markId115, None)
    
    sketchRapidDimensionBuilder14.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch9 = theSession.ActiveSketch
    
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId117, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature8
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section6.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = curveFeatureRule4
    helpPoint4 = NXOpen.Point3d(0.0, -19.520801463931917, 52.893797109534738)
    section6.AddToSection(rules4, arc4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId119, None)
    
    direction9 = workPart.Directions.CreateDirection(sketch9, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction9
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    targetBodies17[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies17)
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies18)
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId118, None)
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = body1
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies19)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder6.ParentFeatureInternal = False
    
    feature9 = extrudeBuilder6.CommitFeature()
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId117, "Extrude")
    
    expression51 = extrudeBuilder6.Limits.StartExtend.Value
    expression52 = extrudeBuilder6.Limits.EndExtend.Value
    extrudeBuilder6.Destroy()
    
    workPart.Expressions.Delete(expression49)
    
    workPart.Expressions.Delete(expression50)
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId121, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.97463904915154354
    rotMatrix17.Xy = 0.10940704163867776
    rotMatrix17.Xz = 0.1952148127290714
    rotMatrix17.Yx = -0.19721089759443722
    rotMatrix17.Yy = 0.0076249596363211873
    rotMatrix17.Yz = 0.98033143469978556
    rotMatrix17.Zx = 0.10576665702843253
    rotMatrix17.Zy = -0.9939677858111966
    rotMatrix17.Zz = 0.029007844294478301
    translation17 = NXOpen.Point3d(6.0377883546685567, -10.851400514750445, 52.109392643513218)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 0.85735940891677709)
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.99117894217824742
    rotMatrix18.Xy = 0.047577516907648373
    rotMatrix18.Xz = 0.12369593553270634
    rotMatrix18.Yx = -0.023801597535682936
    rotMatrix18.Yy = -0.85426074986324785
    rotMatrix18.Yz = 0.5192995813572614
    rotMatrix18.Zx = 0.1303755672553655
    rotMatrix18.Zy = -0.5176629705976461
    rotMatrix18.Zz = -0.84559284548466884
    translation18 = NXOpen.Point3d(7.9317375248986508, -7.1950759582405013, 98.020382066331706)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 0.85735940891677709)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    extrudeBuilder7.Destroy()
    
    section7.Destroy()
    
    workPart.Expressions.Delete(expression53)
    
    theSession.UndoToMark(markId121, None)
    
    theSession.DeleteUndoMark(markId121, None)
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin13, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane13
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId122, "Create Sketch Dialog")
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge11 = extrude1.FindObject("EDGE * 120 * 140 {(48,-30,0)(24,-30,0)(0,-30,0) EXTRUDE(2)}")
    point39 = workPart.Points.CreatePoint(edge11, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge12 = extrude1.FindObject("EDGE * 120 * 160 {(0,0,0)(24,0,0)(48,0,0) EXTRUDE(2)}")
    direction10 = workPart.Directions.CreateDirection(edge12, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face4 = extrude1.FindObject("FACE 120 {(24,-15,0) EXTRUDE(2)}")
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction10, point39, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem6
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin14, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane14.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face4
    plane14.SetGeometry(geom10)
    
    plane14.SetFlip(False)
    
    plane14.SetExpression(None)
    
    plane14.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane14.Evaluate()
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin15, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression57 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane15.SynchronizeToPlane(plane14)
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point40 = workPart.Points.CreatePoint(edge11, scalar9, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom11 = [NXOpen.NXObject.Null] * 1 
    geom11[0] = face4
    plane15.SetGeometry(geom11)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId123, None)
    
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject20 = sketchInPlaceBuilder6.Commit()
    
    sketch10 = nXObject20
    feature10 = sketch10.Feature
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId125)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId124, None)
    
    theSession.SetUndoMarkName(markId122, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression55)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point40)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression54)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression57)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression56)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane15.DestroyPlane()
    
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin16, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane16
    
    expression58 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId126, "Create Sketch Dialog")
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId127, None)
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject21 = sketchInPlaceBuilder7.Commit()
    
    sketch11 = nXObject21
    feature11 = sketch11.Feature
    
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId130)
    
    sketch11.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId128, None)
    
    theSession.SetUndoMarkName(markId126, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression59)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression58)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.98421499160910719
    rotMatrix19.Xy = 0.084320188843512417
    rotMatrix19.Xz = -0.15559870193957004
    rotMatrix19.Yx = 0.12075483182828253
    rotMatrix19.Yy = -0.96270272807413815
    rotMatrix19.Yz = 0.24211924324334819
    rotMatrix19.Zx = -0.12937975452909239
    rotMatrix19.Zy = -0.25708668404256724
    rotMatrix19.Zz = -0.95768852765707968
    translation19 = NXOpen.Point3d(8.645584621314768, -43.234022830941541, 87.344797592628368)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 0.85735940891677709)
    
    scaleAboutPoint29 = NXOpen.Point3d(65.886652760989236, -51.536632370422502, 0.0)
    viewCenter29 = NXOpen.Point3d(-65.886652760989236, 51.536632370422502, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.96873026859361222
    rotMatrix20.Xy = 0.15911450812325706
    rotMatrix20.Xz = 0.19037920058462698
    rotMatrix20.Yx = 0.13947849881860988
    rotMatrix20.Yy = -0.98381137361498916
    rotMatrix20.Yz = 0.11252079591387476
    rotMatrix20.Zx = 0.20520091393035916
    rotMatrix20.Zy = -0.082448495744184225
    rotMatrix20.Zz = -0.97524090894079252
    translation20 = NXOpen.Point3d(-18.607203402903899, -27.860763917911356, 82.724291531844358)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 1.0716992611459712)
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId132, "Curve")
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.96542691645676659
    rotMatrix21.Xy = 0.050090321352489357
    rotMatrix21.Xz = -0.25581600553441208
    rotMatrix21.Yx = 0.1206738101472046
    rotMatrix21.Yy = -0.95575589033594532
    rotMatrix21.Yz = 0.26826947204759921
    rotMatrix21.Zx = -0.23105995006780164
    rotMatrix21.Zy = -0.28986486126287453
    rotMatrix21.Zz = -0.92875705202152603
    translation21 = NXOpen.Point3d(-0.084501477824357352, -33.997309566629561, 87.991533223652823)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 1.0716992611459712)
    
    # ----------------------------------------------
    #   Menu: File->Execute->Grip...
    # ----------------------------------------------
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = 0.99313403412451107
    rotMatrix22.Xy = 0.10842640485001773
    rotMatrix22.Xz = 0.043914746895236043
    rotMatrix22.Yx = 0.11131296679651242
    rotMatrix22.Yy = -0.99133697872017013
    rotMatrix22.Yz = -0.069716698465440194
    rotMatrix22.Zx = 0.035975181535763623
    rotMatrix22.Zy = 0.074126306755851704
    rotMatrix22.Zz = -0.99659975765610276
    translation22 = NXOpen.Point3d(-13.362314908721462, -19.096987978889544, 90.095479339004157)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 1.0716992611459712)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId134, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix5 = theSession.ActiveSketch.Orientation
    
    center5 = NXOpen.Point3d(11.0, -16.0, 0.0)
    arc5 = workPart.Curves.CreateArc(center5, nXMatrix5, 5.1384048104053051, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = arc5
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_9.SplineDefiningPointIndex = 0
    geom1Help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help4.Point.X = 16.123269564537502
    geom1Help4.Point.Y = -15.605902341189299
    geom1Help4.Point.Z = 0.0
    geom1Help4.Parameter = 0.0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    extrude3 = feature4
    edge13 = extrude3.FindObject("EDGE * 140 EXTRUDE(2) 130 {(20.05,-8.1583993101029,75)(31.9,-15,75)(20.05,-21.8416006898971,75) EXTRUDE(2)}")
    geom2_9.Geometry = edge13
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_9.SplineDefiningPointIndex = 0
    geom2Help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help4.Point.X = 16.123269564537502
    geom2Help4.Point.Y = -15.605902341189299
    geom2Help4.Point.Z = 0.0
    geom2Help4.Parameter = 0.0
    sketchTangentConstraint4 = theSession.ActiveSketch.CreateTangentConstraint(geom1_9, geom1Help4, geom2_9, geom2Help4)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = arc5
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_10.SplineDefiningPointIndex = 0
    geom1Help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help5.Point.X = 16.123269564537505
    geom1Help5.Point.Y = -15.605902341189298
    geom1Help5.Point.Z = 0.0
    geom1Help5.Parameter = 0.0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = arc1
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_10.SplineDefiningPointIndex = 0
    geom2Help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help5.Point.X = 16.123269564537505
    geom2Help5.Point.Y = -15.605902341189298
    geom2Help5.Point.Z = 0.0
    geom2Help5.Parameter = 0.0
    sketchTangentConstraint5 = theSession.ActiveSketch.CreateTangentConstraint(geom1_10, geom1Help5, geom2_10, geom2Help5)
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = arc5
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(11.0, -13.200707223785813, 0.0)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension7 = sketchDimensionalConstraint7.AssociatedDimension
    
    expression60 = sketchDimensionalConstraint7.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId133, "Curve")
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete3 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects2 = [NXOpen.TaggedObject.Null] * 1 
    objects2[0] = theSession.ActiveSketch
    nErrs10 = theSession.UpdateManager.AddObjectsToDeleteList(objects2)
    
    notifyOnDelete4 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id2 = theSession.NewestVisibleUndoMark
    
    nErrs11 = theSession.UpdateManager.DoUpdate(id2)
    
    theSession.DeleteUndoMark(markId135, None)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.96889080758995938
    rotMatrix23.Xy = 0.055432800886079985
    rotMatrix23.Xz = -0.24120076192582243
    rotMatrix23.Yx = 0.20798548173667822
    rotMatrix23.Yy = -0.71059572553805683
    rotMatrix23.Yz = 0.67215753676783296
    rotMatrix23.Zx = -0.1341366555212832
    rotMatrix23.Zy = -0.70141351529106133
    rotMatrix23.Zz = -0.70001888418284519
    translation23 = NXOpen.Point3d(-0.74518363440365931, -50.590350125219118, 69.198926791373012)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 1.0716992611459712)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin17, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane17
    
    expression61 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression62 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId137, "Create Sketch Dialog")
    
    scalar10 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point41 = workPart.Points.CreatePoint(edge11, scalar10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction11 = workPart.Directions.CreateDirection(edge12, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction11, point41, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem7
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal18 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane18 = workPart.Planes.CreatePlane(origin18, normal18, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane18.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom12 = [NXOpen.NXObject.Null] * 1 
    geom12[0] = face4
    plane18.SetGeometry(geom12)
    
    plane18.SetFlip(False)
    
    plane18.SetExpression(None)
    
    plane18.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane18.Evaluate()
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin19, normal19, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane19.SynchronizeToPlane(plane18)
    
    scalar11 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point42 = workPart.Points.CreatePoint(edge11, scalar11, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane19.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom13 = [NXOpen.NXObject.Null] * 1 
    geom13[0] = face4
    plane19.SetGeometry(geom13)
    
    plane19.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane19.Evaluate()
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject22 = sketchInPlaceBuilder8.Commit()
    
    sketch12 = nXObject22
    feature12 = sketch12.Feature
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs12 = theSession.UpdateManager.DoUpdate(markId140)
    
    sketch12.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId139, None)
    
    theSession.SetUndoMarkName(markId137, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression62)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point42)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression61)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression63)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint30 = NXOpen.Point3d(29.749289583884629, -38.760485183982404, 0.0)
    viewCenter30 = NXOpen.Point3d(-29.74928958388459, 38.760485183982446, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(23.799431667107701, -30.415871176220584, 0.0)
    viewCenter31 = NXOpen.Point3d(-23.799431667107637, 30.415871176220616, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(6.8731968631979194, -4.5821312421319158, 0.0)
    viewCenter32 = NXOpen.Point3d(-6.8731968631978928, 4.5821312421319549, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(5.3721538700857367, -3.6657049937055226, 0.0)
    viewCenter33 = NXOpen.Point3d(-5.3721538700856746, 3.6657049937055644, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId142, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix6 = theSession.ActiveSketch.Orientation
    
    center6 = NXOpen.Point3d(12.500000000000007, -15.500000000000011, 0.0)
    arc6 = workPart.Curves.CreateArc(center6, nXMatrix6, 3.6108644332213373, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = arc6
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_11.SplineDefiningPointIndex = 0
    geom1Help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help6.Point.X = 16.107456348995036
    geom1Help6.Point.Y = -15.343154071782779
    geom1Help6.Point.Z = 0.0
    geom1Help6.Parameter = 0.0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    edge14 = extrude3.FindObject("EDGE * 130 * 140 {(20.05,-8.1583993101029,90)(31.9,-15,90)(20.05,-21.8416006898971,90) EXTRUDE(2)}")
    geom2_11.Geometry = edge14
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_11.SplineDefiningPointIndex = 0
    geom2Help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help6.Point.X = 16.107456348995036
    geom2Help6.Point.Y = -15.343154071782779
    geom2Help6.Point.Z = 0.0
    geom2Help6.Parameter = 0.0
    sketchTangentConstraint6 = theSession.ActiveSketch.CreateTangentConstraint(geom1_11, geom1Help6, geom2_11, geom2Help6)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = arc6
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_12.SplineDefiningPointIndex = 0
    geom1Help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help7.Point.X = 16.107456348995036
    geom1Help7.Point.Y = -15.343154071782779
    geom1Help7.Point.Z = 0.0
    geom1Help7.Parameter = 0.0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = edge13
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_12.SplineDefiningPointIndex = 0
    geom2Help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help7.Point.X = 16.107456348995036
    geom2Help7.Point.Y = -15.343154071782779
    geom2Help7.Point.Z = 0.0
    geom2Help7.Parameter = 0.0
    sketchTangentConstraint7 = theSession.ActiveSketch.CreateTangentConstraint(geom1_12, geom1Help7, geom2_12, geom2Help7)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = arc6
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_13.SplineDefiningPointIndex = 0
    geom1Help8 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help8.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help8.Point.X = 16.107456348995036
    geom1Help8.Point.Y = -15.343154071782781
    geom1Help8.Point.Z = 0.0
    geom1Help8.Parameter = 0.0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = arc1
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_13.SplineDefiningPointIndex = 0
    geom2Help8 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help8.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help8.Point.X = 16.107456348995036
    geom2Help8.Point.Y = -15.343154071782781
    geom2Help8.Point.Z = 0.0
    geom2Help8.Parameter = 0.0
    sketchTangentConstraint8 = theSession.ActiveSketch.CreateTangentConstraint(geom1_13, geom1Help8, geom2_13, geom2Help8)
    
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = arc6
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(12.500000000000007, -16.646590321137342, 0.0)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension8 = sketchDimensionalConstraint8.AssociatedDimension
    
    expression65 = sketchDimensionalConstraint8.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId143, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix7 = theSession.ActiveSketch.Orientation
    
    center7 = NXOpen.Point3d(29.490162161915766, -15.500000000000011, 0.0)
    arc7 = workPart.Curves.CreateArc(center7, nXMatrix7, 4.2950163289215766, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = arc7
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(29.490162161915766, -16.646590321137342, 0.0)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension9 = sketchDimensionalConstraint9.AssociatedDimension
    
    expression66 = sketchDimensionalConstraint9.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.DeleteUndoMark(markId145, "Curve")
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete5 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    theSession.SetUndoMarkName(markId147, "Class Selection Dialog")
    
    theSession.SetUndoMarkName(markId147, "Class Selection")
    
    theSession.DeleteUndoMark(markId147, None)
    
    theSession.DeleteUndoMark(markId146, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete6 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    theSession.SetUndoMarkName(markId149, "Class Selection Dialog")
    
    theSession.SetUndoMarkName(markId149, "Class Selection")
    
    theSession.DeleteUndoMark(markId149, None)
    
    theSession.DeleteUndoMark(markId148, None)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId151, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 4 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension3)
    
    diameterDimension1 = dimension8
    theSession.UpdateManager.LogForUpdate(diameterDimension1)
    
    horizontalDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    theSession.UpdateManager.LogForUpdate(horizontalDimension1)
    
    center8 = NXOpen.Point3d(6.1506896452641442, -15.776056971945057, 0.0)
    arc6.SetParameters(9.9661731930311639, center8, 0.0, ( 360.0 * math.pi/180.0 ))
    
    helpPoint1_1 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    helpPoint2_1 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    sketchTangentConstraint6.SetHelpPoints(True, True, helpPoint1_1, helpPoint2_1)
    
    sketchHelpedDimensionalConstraint3 = theSession.ActiveSketch.FindObject("ENTITY 243 5 1")
    sketchHelpedDimensionalConstraint3.Refresh()
    
    helpPoint1_2 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    helpPoint2_2 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    sketchTangentConstraint7.SetHelpPoints(True, True, helpPoint1_2, helpPoint2_2)
    
    helpPoint1_3 = NXOpen.Point3d(16.107456348995036, -15.343154071782781, 0.0)
    helpPoint2_3 = NXOpen.Point3d(16.107456348995036, -15.343154071782781, 0.0)
    sketchTangentConstraint8.SetHelpPoints(True, True, helpPoint1_3, helpPoint2_3)
    
    nErrs13 = theSession.UpdateManager.DoUpdate(markId151)
    
    geoms3 = [NXOpen.SmartObject.Null] * 1 
    geoms3[0] = arc6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 1 
    geoms4[0] = arc6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms4)
    
    geoms5 = [NXOpen.SmartObject.Null] * 1 
    geoms5[0] = arc6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms5)
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId153, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(perpendicularDimension3)
    
    theSession.UpdateManager.LogForUpdate(diameterDimension1)
    
    theSession.UpdateManager.LogForUpdate(horizontalDimension1)
    
    center9 = NXOpen.Point3d(3.4718899131144454, -15.892526525516784, 0.0)
    arc6.SetParameters(12.647503676555061, center9, 0.0, ( 360.0 * math.pi/180.0 ))
    
    helpPoint1_4 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    helpPoint2_4 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    sketchTangentConstraint6.SetHelpPoints(True, True, helpPoint1_4, helpPoint2_4)
    
    sketchHelpedDimensionalConstraint3.Refresh()
    
    helpPoint1_5 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    helpPoint2_5 = NXOpen.Point3d(16.107456348995036, -15.343154071782779, 0.0)
    sketchTangentConstraint7.SetHelpPoints(True, True, helpPoint1_5, helpPoint2_5)
    
    helpPoint1_6 = NXOpen.Point3d(16.107456348995036, -15.343154071782781, 0.0)
    helpPoint2_6 = NXOpen.Point3d(16.107456348995036, -15.343154071782781, 0.0)
    sketchTangentConstraint8.SetHelpPoints(True, True, helpPoint1_6, helpPoint2_6)
    
    nErrs14 = theSession.UpdateManager.DoUpdate(markId153)
    
    geoms6 = [NXOpen.SmartObject.Null] * 1 
    geoms6[0] = arc6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms6)
    
    geoms7 = [NXOpen.SmartObject.Null] * 1 
    geoms7[0] = arc6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 1 
    geoms8[0] = arc6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId155, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    theSession.UpdateManager.LogForUpdate(perpendicularDimension3)
    
    theSession.UpdateManager.LogForUpdate(diameterDimension1)
    
    theSession.UpdateManager.LogForUpdate(horizontalDimension1)
    
    center10 = NXOpen.Point3d(12.40039267401956, -15.324144651816596, 0.0)
    arc6.SetParameters(3.7041354642317295, center10, 0.0, ( 360.0 * math.pi/180.0 ))
    
    helpPoint1_7 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    helpPoint2_7 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    sketchTangentConstraint6.SetHelpPoints(True, True, helpPoint1_7, helpPoint2_7)
    
    sketchHelpedDimensionalConstraint3.Refresh()
    
    helpPoint1_8 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    helpPoint2_8 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    sketchTangentConstraint7.SetHelpPoints(True, True, helpPoint1_8, helpPoint2_8)
    
    helpPoint1_9 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    helpPoint2_9 = NXOpen.Point3d(16.103082719285336, -15.220675013424678, 0.0)
    sketchTangentConstraint8.SetHelpPoints(True, True, helpPoint1_9, helpPoint2_9)
    
    nErrs15 = theSession.UpdateManager.DoUpdate(markId155)
    
    geoms9 = [NXOpen.SmartObject.Null] * 1 
    geoms9[0] = arc6
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 1 
    geoms10[0] = arc6
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms10)
    
    geoms11 = [NXOpen.SmartObject.Null] * 1 
    geoms11[0] = arc6
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms11)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder15 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines73 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines73)
    
    lines74 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines74)
    
    lines75 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines75)
    
    lines76 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines76)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder15.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines77 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBefore(lines77)
    
    lines78 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAfter(lines78)
    
    lines79 = []
    sketchRapidDimensionBuilder15.AppendedText.SetAbove(lines79)
    
    lines80 = []
    sketchRapidDimensionBuilder15.AppendedText.SetBelow(lines80)
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder15.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits437 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits438 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits439 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits440 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits441 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits442 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits443 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits444 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits445 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits446 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder15.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits447 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits448 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits449 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits450 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits451 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits452 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits453 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits454 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits455 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits456 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    point1_51 = NXOpen.Point3d(12.40039267401956, -15.324144651816596, 0.0)
    point2_51 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_51, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_51)
    
    point1_52 = NXOpen.Point3d(12.40039267401956, -15.324144651816596, 0.0)
    point2_52 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc6, workPart.ModelingViews.WorkView, point1_52, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_52)
    
    point1_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_53 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_53, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_53)
    
    dimensionlinearunits457 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits458 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits459 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits460 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits461 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits462 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    point43 = NXOpen.Point3d(16.989100323482536, -23.110607672929063, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(perpendicularDimension3, workPart.ModelingViews.WorkView, point43)
    
    line7 = theSession.ActiveSketch.FindObject("Curve DATUM9")
    point1_54 = NXOpen.Point3d(14.287500000000007, -30.000000000000011, 0.0)
    point2_54 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, NXOpen.View.Null, point1_54, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_54)
    
    point1_55 = NXOpen.Point3d(12.40039267401956, -15.324144651816596, 0.0)
    point2_55 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_55, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_55)
    
    point1_56 = NXOpen.Point3d(14.287500000000007, -30.000000000000011, 0.0)
    point2_56 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line7, workPart.ModelingViews.WorkView, point1_56, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_56)
    
    point1_57 = NXOpen.Point3d(12.40039267401956, -15.324144651816596, 0.0)
    point2_57 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder15.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_57, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_57)
    
    dimensionlinearunits463 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits464 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits465 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits466 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits467 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits468 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits469 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits470 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits471 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits472 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits473 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits474 = sketchRapidDimensionBuilder15.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin12 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin12.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin12.View = NXOpen.View.Null
    assocOrigin12.ViewOfGeometry = workPart.ModelingViews.WorkView
    point44 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin12.PointOnGeometry = point44
    assocOrigin12.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.DimensionLine = 0
    assocOrigin12.AssociatedView = NXOpen.View.Null
    assocOrigin12.AssociatedPoint = NXOpen.Point.Null
    assocOrigin12.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin12.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin12.XOffsetFactor = 0.0
    assocOrigin12.YOffsetFactor = 0.0
    assocOrigin12.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder15.Origin.SetAssociativeOrigin(assocOrigin12)
    
    point45 = NXOpen.Point3d(-29.970100908397661, -22.706116087416731, 0.0)
    sketchRapidDimensionBuilder15.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point45)
    
    sketchRapidDimensionBuilder15.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder15.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder15.Style.DimensionStyle.TextCentered = True
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject23 = sketchRapidDimensionBuilder15.Commit()
    
    theSession.DeleteUndoMark(markId157, None)
    
    theSession.SetUndoMarkName(markId156, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId156, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder15.Destroy()
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder16 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines81 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBefore(lines81)
    
    lines82 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAfter(lines82)
    
    lines83 = []
    sketchRapidDimensionBuilder16.AppendedText.SetAbove(lines83)
    
    lines84 = []
    sketchRapidDimensionBuilder16.AppendedText.SetBelow(lines84)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder16.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId158, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder16.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits475 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits476 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits477 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits478 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits479 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits480 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits481 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits482 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits483 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits484 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder16.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits485 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits486 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits487 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits488 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits489 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits490 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits491 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits492 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits493 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits494 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    expression67 = workPart.Expressions.FindObject("p19")
    expression67.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId158, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId159, None)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId158, "Edit Driving Value")
    
    point1_58 = NXOpen.Point3d(29.485634023664485, -15.500000000000011, 0.0)
    point2_58 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_58, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_58)
    
    point1_59 = NXOpen.Point3d(29.485634023664485, -15.500000000000011, 0.0)
    point2_59 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc7, workPart.ModelingViews.WorkView, point1_59, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_59)
    
    point1_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_60 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_60, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_60)
    
    dimensionlinearunits495 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits496 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits497 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits498 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits499 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits500 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    point46 = NXOpen.Point3d(28.580056094513012, -30.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(line3, workPart.ModelingViews.WorkView, point46)
    
    point1_61 = NXOpen.Point3d(28.580056094513012, -30.0, 0.0)
    point2_61 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_61, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_61)
    
    point1_62 = NXOpen.Point3d(29.485634023664485, -15.500000000000011, 0.0)
    point2_62 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_62, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_62)
    
    point1_63 = NXOpen.Point3d(28.580056094513012, -30.0, 0.0)
    point2_63 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_63, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_63)
    
    point1_64 = NXOpen.Point3d(29.485634023664485, -15.500000000000011, 0.0)
    point2_64 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder16.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_64, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_64)
    
    dimensionlinearunits501 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits502 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits503 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits504 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits505 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits506 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits507 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits508 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits509 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits510 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits511 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits512 = sketchRapidDimensionBuilder16.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin13 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin13.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin13.View = NXOpen.View.Null
    assocOrigin13.ViewOfGeometry = workPart.ModelingViews.WorkView
    point47 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin13.PointOnGeometry = point47
    assocOrigin13.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.DimensionLine = 0
    assocOrigin13.AssociatedView = NXOpen.View.Null
    assocOrigin13.AssociatedPoint = NXOpen.Point.Null
    assocOrigin13.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin13.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin13.XOffsetFactor = 0.0
    assocOrigin13.YOffsetFactor = 0.0
    assocOrigin13.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder16.Origin.SetAssociativeOrigin(assocOrigin13)
    
    point48 = NXOpen.Point3d(58.107941836913554, -27.155523528052427, 0.0)
    sketchRapidDimensionBuilder16.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point48)
    
    sketchRapidDimensionBuilder16.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder16.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder16.Style.DimensionStyle.TextCentered = False
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject24 = sketchRapidDimensionBuilder16.Commit()
    
    theSession.DeleteUndoMark(markId161, None)
    
    theSession.SetUndoMarkName(markId160, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId160, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder16.Destroy()
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder17 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines85 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBefore(lines85)
    
    lines86 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAfter(lines86)
    
    lines87 = []
    sketchRapidDimensionBuilder17.AppendedText.SetAbove(lines87)
    
    lines88 = []
    sketchRapidDimensionBuilder17.AppendedText.SetBelow(lines88)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder17.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId162, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder17.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits513 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits514 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits515 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits516 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits517 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits518 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits519 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits520 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits521 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits522 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder17.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits523 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits524 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits525 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits526 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits527 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits528 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits529 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits530 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits531 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits532 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    expression68 = workPart.Expressions.FindObject("p20")
    expression68.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId162, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId163, None)
    
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId162, "Edit Driving Value")
    
    point1_65 = NXOpen.Point3d(15.362623763931769, -17.217872678826726, 0.0)
    point2_65 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc6, workPart.ModelingViews.WorkView, point1_65, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_65)
    
    point1_66 = NXOpen.Point3d(15.362623763931769, -17.217872678826726, 0.0)
    point2_66 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc6, workPart.ModelingViews.WorkView, point1_66, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_66)
    
    point1_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_67 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder17.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_67, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_67)
    
    dimensionlinearunits533 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits534 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits535 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits536 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits537 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits538 = sketchRapidDimensionBuilder17.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin14 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin14.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin14.View = NXOpen.View.Null
    assocOrigin14.ViewOfGeometry = workPart.ModelingViews.WorkView
    point49 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin14.PointOnGeometry = point49
    assocOrigin14.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.DimensionLine = 0
    assocOrigin14.AssociatedView = NXOpen.View.Null
    assocOrigin14.AssociatedPoint = NXOpen.Point.Null
    assocOrigin14.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin14.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin14.XOffsetFactor = 0.0
    assocOrigin14.YOffsetFactor = 0.0
    assocOrigin14.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder17.Origin.SetAssociativeOrigin(assocOrigin14)
    
    point50 = NXOpen.Point3d(18.06327487119227, -20.27916657434271, 0.0)
    sketchRapidDimensionBuilder17.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point50)
    
    sketchRapidDimensionBuilder17.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder17.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder17.Style.DimensionStyle.TextCentered = False
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject25 = sketchRapidDimensionBuilder17.Commit()
    
    theSession.DeleteUndoMark(markId165, None)
    
    theSession.SetUndoMarkName(markId164, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId164, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder17.Destroy()
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder18 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines89 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBefore(lines89)
    
    lines90 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAfter(lines90)
    
    lines91 = []
    sketchRapidDimensionBuilder18.AppendedText.SetAbove(lines91)
    
    lines92 = []
    sketchRapidDimensionBuilder18.AppendedText.SetBelow(lines92)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder18.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId166, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder18.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits539 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits540 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits541 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits542 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits543 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits544 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits545 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits546 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits547 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits548 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder18.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits549 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits550 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits551 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits552 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits553 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits554 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits555 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits556 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits557 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits558 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    expression69 = workPart.Expressions.FindObject("p21")
    expression69.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId166, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId167, None)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId166, "Edit Driving Value")
    
    point1_68 = NXOpen.Point3d(31.400277026787577, -17.853034631480082, 0.0)
    point2_68 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc7, workPart.ModelingViews.WorkView, point1_68, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_68)
    
    point1_69 = NXOpen.Point3d(31.400277026787577, -17.853034631480082, 0.0)
    point2_69 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc7, workPart.ModelingViews.WorkView, point1_69, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_69)
    
    point1_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_70 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder18.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_70, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_70)
    
    dimensionlinearunits559 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits560 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits561 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits562 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits563 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits564 = sketchRapidDimensionBuilder18.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin15 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin15.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin15.View = NXOpen.View.Null
    assocOrigin15.ViewOfGeometry = workPart.ModelingViews.WorkView
    point51 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin15.PointOnGeometry = point51
    assocOrigin15.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.DimensionLine = 0
    assocOrigin15.AssociatedView = NXOpen.View.Null
    assocOrigin15.AssociatedPoint = NXOpen.Point.Null
    assocOrigin15.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin15.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin15.XOffsetFactor = 0.0
    assocOrigin15.YOffsetFactor = 0.0
    assocOrigin15.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder18.Origin.SetAssociativeOrigin(assocOrigin15)
    
    point52 = NXOpen.Point3d(34.849675669954216, -20.68365815985505, 0.0)
    sketchRapidDimensionBuilder18.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point52)
    
    sketchRapidDimensionBuilder18.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder18.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder18.Style.DimensionStyle.TextCentered = False
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject26 = sketchRapidDimensionBuilder18.Commit()
    
    theSession.DeleteUndoMark(markId169, None)
    
    theSession.SetUndoMarkName(markId168, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId168, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder18.Destroy()
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder19 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines93 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBefore(lines93)
    
    lines94 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAfter(lines94)
    
    lines95 = []
    sketchRapidDimensionBuilder19.AppendedText.SetAbove(lines95)
    
    lines96 = []
    sketchRapidDimensionBuilder19.AppendedText.SetBelow(lines96)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder19.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId170, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder19.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits565 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits566 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits567 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits568 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits569 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits570 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits571 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits572 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits573 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits574 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder19.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits575 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits576 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits577 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits578 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits579 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits580 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits581 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits582 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits583 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits584 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    expression70 = workPart.Expressions.FindObject("p22")
    expression70.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId170, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId171, None)
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId170, "Edit Driving Value")
    
    point1_71 = NXOpen.Point3d(28.189769487896214, -14.999999999999998, 0.0)
    point2_71 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_71, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_71)
    
    point1_72 = NXOpen.Point3d(28.189769487896214, -14.999999999999998, 0.0)
    point2_72 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc7, workPart.ModelingViews.WorkView, point1_72, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_72)
    
    point1_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_73 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_73, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_73)
    
    dimensionlinearunits585 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits586 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits587 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits588 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits589 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits590 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    point53 = NXOpen.Point3d(48.000000000000007, -13.60505541338917, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(line2, workPart.ModelingViews.WorkView, point53)
    
    point1_74 = NXOpen.Point3d(48.000000000000007, -13.60505541338917, 0.0)
    point2_74 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line2, workPart.ModelingViews.WorkView, point1_74, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_74)
    
    point1_75 = NXOpen.Point3d(28.189769487896214, -14.999999999999998, 0.0)
    point2_75 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_75, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_75)
    
    point1_76 = NXOpen.Point3d(48.000000000000007, -13.60505541338917, 0.0)
    point2_76 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line2, workPart.ModelingViews.WorkView, point1_76, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_76)
    
    point1_77 = NXOpen.Point3d(28.189769487896214, -14.999999999999998, 0.0)
    point2_77 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder19.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_77, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_77)
    
    dimensionlinearunits591 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits592 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits593 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits594 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits595 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits596 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits597 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits598 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits599 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits600 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits601 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits602 = sketchRapidDimensionBuilder19.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin16 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin16.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin16.View = NXOpen.View.Null
    assocOrigin16.ViewOfGeometry = workPart.ModelingViews.WorkView
    point54 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin16.PointOnGeometry = point54
    assocOrigin16.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.DimensionLine = 0
    assocOrigin16.AssociatedView = NXOpen.View.Null
    assocOrigin16.AssociatedPoint = NXOpen.Point.Null
    assocOrigin16.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin16.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin16.XOffsetFactor = 0.0
    assocOrigin16.YOffsetFactor = 0.0
    assocOrigin16.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder19.Origin.SetAssociativeOrigin(assocOrigin16)
    
    point55 = NXOpen.Point3d(40.714803659883103, -36.661075787592331, 0.0)
    sketchRapidDimensionBuilder19.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point55)
    
    sketchRapidDimensionBuilder19.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder19.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder19.Style.DimensionStyle.TextCentered = False
    
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject27 = sketchRapidDimensionBuilder19.Commit()
    
    theSession.DeleteUndoMark(markId173, None)
    
    theSession.SetUndoMarkName(markId172, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId172, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder19.Destroy()
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder20 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines97 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBefore(lines97)
    
    lines98 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAfter(lines98)
    
    lines99 = []
    sketchRapidDimensionBuilder20.AppendedText.SetAbove(lines99)
    
    lines100 = []
    sketchRapidDimensionBuilder20.AppendedText.SetBelow(lines100)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder20.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId174, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder20.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits603 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits604 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits605 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits606 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits607 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits608 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits609 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits610 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits611 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits612 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder20.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits613 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits614 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits615 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits616 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits617 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits618 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits619 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits620 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits621 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits622 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    expression71 = workPart.Expressions.FindObject("p23")
    expression71.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId174, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId174, "Edit Driving Value")
    
    expression71.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId176, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId177, None)
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId176, "Edit Driving Value")
    
    point1_78 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_78 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_78, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_78)
    
    point1_79 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_79 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc6, workPart.ModelingViews.WorkView, point1_79, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_79)
    
    point1_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_80 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_80, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_80)
    
    dimensionlinearunits623 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits624 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits625 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits626 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits627 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits628 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    point1_81 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_81 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_81, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_81)
    
    point1_82 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_82 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_82, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_82)
    
    point1_83 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_83 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_83, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_83)
    
    point1_84 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_84 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_84, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_84)
    
    point1_85 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_85 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder20.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_85, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_85)
    
    dimensionlinearunits629 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits630 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits631 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits632 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits633 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits634 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits635 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits636 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits637 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits638 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits639 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits640 = sketchRapidDimensionBuilder20.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin17 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin17.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin17.View = NXOpen.View.Null
    assocOrigin17.ViewOfGeometry = workPart.ModelingViews.WorkView
    point56 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin17.PointOnGeometry = point56
    assocOrigin17.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.DimensionLine = 0
    assocOrigin17.AssociatedView = NXOpen.View.Null
    assocOrigin17.AssociatedPoint = NXOpen.Point.Null
    assocOrigin17.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin17.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin17.XOffsetFactor = 0.0
    assocOrigin17.YOffsetFactor = 0.0
    assocOrigin17.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder20.Origin.SetAssociativeOrigin(assocOrigin17)
    
    point57 = NXOpen.Point3d(9.7711973681893713, -34.335249170896397, 0.0)
    sketchRapidDimensionBuilder20.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point57)
    
    sketchRapidDimensionBuilder20.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder20.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder20.Style.DimensionStyle.TextCentered = False
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject28 = sketchRapidDimensionBuilder20.Commit()
    
    theSession.DeleteUndoMark(markId179, None)
    
    theSession.SetUndoMarkName(markId178, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId178, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder20.Destroy()
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder21 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines101 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBefore(lines101)
    
    lines102 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAfter(lines102)
    
    lines103 = []
    sketchRapidDimensionBuilder21.AppendedText.SetAbove(lines103)
    
    lines104 = []
    sketchRapidDimensionBuilder21.AppendedText.SetBelow(lines104)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder21.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId180, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder21.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits641 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits642 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits643 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits644 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits645 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits646 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits647 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits648 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits649 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits650 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder21.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits651 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits652 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits653 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits654 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits655 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits656 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits657 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits658 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits659 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits660 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    expression72 = workPart.Expressions.FindObject("p24")
    expression72.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId180, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId181, None)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId180, "Edit Driving Value")
    
    point1_86 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_86 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_86, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_86)
    
    point1_87 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_87 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc6, workPart.ModelingViews.WorkView, point1_87, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_87)
    
    point1_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_88 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_88, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_88)
    
    dimensionlinearunits661 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits662 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits663 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits664 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits665 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits666 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    point1_89 = NXOpen.Point3d(33.000000000000007, -14.999999999999998, 0.0)
    point2_89 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_89, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_89)
    
    point1_90 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_90 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_90, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_90)
    
    point1_91 = NXOpen.Point3d(33.000000000000007, -14.999999999999998, 0.0)
    point2_91 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_91, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_91)
    
    point1_92 = NXOpen.Point3d(11.100000000000009, -15.000000000000011, 0.0)
    point2_92 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc6, workPart.ModelingViews.WorkView, point1_92, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_92)
    
    point1_93 = NXOpen.Point3d(33.000000000000007, -14.999999999999998, 0.0)
    point2_93 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder21.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc7, workPart.ModelingViews.WorkView, point1_93, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_93)
    
    dimensionlinearunits667 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits668 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits669 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits670 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits671 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits672 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits673 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits674 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits675 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits676 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits677 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits678 = sketchRapidDimensionBuilder21.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin18 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin18.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin18.View = NXOpen.View.Null
    assocOrigin18.ViewOfGeometry = workPart.ModelingViews.WorkView
    point58 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin18.PointOnGeometry = point58
    assocOrigin18.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.DimensionLine = 0
    assocOrigin18.AssociatedView = NXOpen.View.Null
    assocOrigin18.AssociatedPoint = NXOpen.Point.Null
    assocOrigin18.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin18.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin18.XOffsetFactor = 0.0
    assocOrigin18.YOffsetFactor = 0.0
    assocOrigin18.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder21.Origin.SetAssociativeOrigin(assocOrigin18)
    
    point59 = NXOpen.Point3d(21.804822037181374, -37.470058958617003, 0.0)
    sketchRapidDimensionBuilder21.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point59)
    
    sketchRapidDimensionBuilder21.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder21.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder21.Style.DimensionStyle.TextCentered = True
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder21.Commit()
    
    theSession.DeleteUndoMark(markId183, None)
    
    theSession.SetUndoMarkName(markId182, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId182, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder21.Destroy()
    
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder22 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines105 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBefore(lines105)
    
    lines106 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAfter(lines106)
    
    lines107 = []
    sketchRapidDimensionBuilder22.AppendedText.SetAbove(lines107)
    
    lines108 = []
    sketchRapidDimensionBuilder22.AppendedText.SetBelow(lines108)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder22.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId184, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder22.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits679 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits680 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits681 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits682 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits683 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits684 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits685 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits686 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits687 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits688 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder22.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder22.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder22.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits689 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits690 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits691 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits692 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits693 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits694 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits695 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits696 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits697 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits698 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    point1_94 = NXOpen.Point3d(15.475851366367358, -12.580924800784203, 0.0)
    point2_94 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.DrfTangent, arc6, workPart.ModelingViews.WorkView, point1_94, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_94)
    
    point1_95 = NXOpen.Point3d(15.475851366367358, -12.580924800784203, 0.0)
    point2_95 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc6, workPart.ModelingViews.WorkView, point1_95, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_95)
    
    point1_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_96 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder22.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_96, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_96)
    
    dimensionlinearunits699 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits700 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits701 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits702 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits703 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits704 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits705 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits706 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits707 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits708 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits709 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits710 = sketchRapidDimensionBuilder22.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder22.Destroy()
    
    theSession.UndoToMark(markId184, None)
    
    theSession.DeleteUndoMark(markId184, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete7 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects3 = [NXOpen.TaggedObject.Null] * 1 
    objects3[0] = arc6
    nErrs16 = theSession.UpdateManager.AddObjectsToDeleteList(objects3)
    
    notifyOnDelete8 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id3 = theSession.NewestVisibleUndoMark
    
    nErrs17 = theSession.UpdateManager.DoUpdate(id3)
    
    theSession.DeleteUndoMark(markId185, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId188, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix8 = theSession.ActiveSketch.Orientation
    
    center11 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    arc8 = workPart.Curves.CreateArc(center11, nXMatrix8, 5.1862523283024018, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = arc8
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_14.SplineDefiningPointIndex = 0
    geom1Help9 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help9.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help9.Point.X = 16.152069406618072
    geom1Help9.Point.Y = -15.905530453082537
    geom1Help9.Point.Z = 0.0
    geom1Help9.Parameter = 0.0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = edge14
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_14.SplineDefiningPointIndex = 0
    geom2Help9 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help9.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help9.Point.X = 16.152069406618072
    geom2Help9.Point.Y = -15.905530453082537
    geom2Help9.Point.Z = 0.0
    geom2Help9.Parameter = 0.0
    sketchTangentConstraint9 = theSession.ActiveSketch.CreateTangentConstraint(geom1_14, geom1Help9, geom2_14, geom2Help9)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = arc8
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_15.SplineDefiningPointIndex = 0
    geom1Help10 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help10.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help10.Point.X = 16.152069406618072
    geom1Help10.Point.Y = -15.905530453082537
    geom1Help10.Point.Z = 0.0
    geom1Help10.Parameter = 0.0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = edge13
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_15.SplineDefiningPointIndex = 0
    geom2Help10 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help10.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help10.Point.X = 16.152069406618072
    geom2Help10.Point.Y = -15.905530453082537
    geom2Help10.Point.Z = 0.0
    geom2Help10.Parameter = 0.0
    sketchTangentConstraint10 = theSession.ActiveSketch.CreateTangentConstraint(geom1_15, geom1Help10, geom2_15, geom2Help10)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = arc8
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom1_16.SplineDefiningPointIndex = 0
    geom1Help11 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help11.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help11.Point.X = 16.152069406618072
    geom1Help11.Point.Y = -15.905530453082539
    geom1Help11.Point.Z = 0.0
    geom1Help11.Parameter = 0.0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = arc1
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_16.SplineDefiningPointIndex = 0
    geom2Help11 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help11.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help11.Point.X = 16.152069406618072
    geom2Help11.Point.Y = -15.905530453082539
    geom2Help11.Point.Z = 0.0
    geom2Help11.Parameter = 0.0
    sketchTangentConstraint11 = theSession.ActiveSketch.CreateTangentConstraint(geom1_16, geom1Help11, geom2_16, geom2Help11)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = arc8
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(11.000000000000007, -17.646590321137342, 0.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension10 = sketchDimensionalConstraint10.AssociatedDimension
    
    expression73 = sketchDimensionalConstraint10.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId189, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix9 = theSession.ActiveSketch.Orientation
    
    center12 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    arc9 = workPart.Curves.CreateArc(center12, nXMatrix9, 4.2558044552859036, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = arc9
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(11.000000000000007, -17.646590321137342, 0.0)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension11 = sketchDimensionalConstraint11.AssociatedDimension
    
    expression74 = sketchDimensionalConstraint11.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder23 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines109 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines109)
    
    lines110 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines110)
    
    lines111 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines111)
    
    lines112 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines112)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder23.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines113 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBefore(lines113)
    
    lines114 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAfter(lines114)
    
    lines115 = []
    sketchRapidDimensionBuilder23.AppendedText.SetAbove(lines115)
    
    lines116 = []
    sketchRapidDimensionBuilder23.AppendedText.SetBelow(lines116)
    
    theSession.SetUndoMarkName(markId190, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder23.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits711 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits712 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits713 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits714 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits715 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits716 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits717 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits718 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits719 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits720 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder23.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits721 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits722 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits723 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits724 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits725 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits726 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits727 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits728 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits729 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits730 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    point1_97 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_97 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_97, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_97)
    
    point1_98 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_98 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc9, workPart.ModelingViews.WorkView, point1_98, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_98)
    
    point1_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_99 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder23.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_99, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_99)
    
    dimensionlinearunits731 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits732 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits733 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits734 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits735 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits736 = sketchRapidDimensionBuilder23.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin19 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin19.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin19.View = NXOpen.View.Null
    assocOrigin19.ViewOfGeometry = workPart.ModelingViews.WorkView
    point60 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin19.PointOnGeometry = point60
    assocOrigin19.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.DimensionLine = 0
    assocOrigin19.AssociatedView = NXOpen.View.Null
    assocOrigin19.AssociatedPoint = NXOpen.Point.Null
    assocOrigin19.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin19.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin19.XOffsetFactor = 0.0
    assocOrigin19.YOffsetFactor = 0.0
    assocOrigin19.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder23.Origin.SetAssociativeOrigin(assocOrigin19)
    
    point61 = NXOpen.Point3d(19.074503834973115, -21.593764227257807, 0.0)
    sketchRapidDimensionBuilder23.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point61)
    
    sketchRapidDimensionBuilder23.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder23.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder23.Style.DimensionStyle.TextCentered = False
    
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject30 = sketchRapidDimensionBuilder23.Commit()
    
    theSession.DeleteUndoMark(markId191, None)
    
    theSession.SetUndoMarkName(markId190, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId190, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder23.Destroy()
    
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder24 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines117 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBefore(lines117)
    
    lines118 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAfter(lines118)
    
    lines119 = []
    sketchRapidDimensionBuilder24.AppendedText.SetAbove(lines119)
    
    lines120 = []
    sketchRapidDimensionBuilder24.AppendedText.SetBelow(lines120)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder24.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId192, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder24.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits737 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits738 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits739 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits740 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits741 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits742 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits743 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits744 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits745 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits746 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder24.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits747 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits748 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits749 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits750 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits751 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits752 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits753 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits754 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits755 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits756 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    expression75 = workPart.Expressions.FindObject("p24")
    expression75.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId192, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId193, None)
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId192, "Edit Driving Value")
    
    point1_100 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_100 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_100, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_100)
    
    point1_101 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_101 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc9, workPart.ModelingViews.WorkView, point1_101, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_101)
    
    point1_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_102 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_102, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_102)
    
    dimensionlinearunits757 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits758 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits759 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits760 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits761 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits762 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    point62 = NXOpen.Point3d(10.479057642835969, -30.000000000000004, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(line3, workPart.ModelingViews.WorkView, point62)
    
    point1_103 = NXOpen.Point3d(10.479057642835969, -30.000000000000004, 0.0)
    point2_103 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_103, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_103)
    
    point1_104 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_104 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_104, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_104)
    
    point1_105 = NXOpen.Point3d(10.479057642835969, -30.000000000000004, 0.0)
    point2_105 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line3, workPart.ModelingViews.WorkView, point1_105, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_105)
    
    point1_106 = NXOpen.Point3d(11.000000000000007, -16.500000000000011, 0.0)
    point2_106 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder24.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_106, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_106)
    
    dimensionlinearunits763 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits764 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits765 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits766 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits767 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits768 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits769 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits770 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits771 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits772 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits773 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits774 = sketchRapidDimensionBuilder24.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin20 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin20.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin20.View = NXOpen.View.Null
    assocOrigin20.ViewOfGeometry = workPart.ModelingViews.WorkView
    point63 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin20.PointOnGeometry = point63
    assocOrigin20.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.DimensionLine = 0
    assocOrigin20.AssociatedView = NXOpen.View.Null
    assocOrigin20.AssociatedPoint = NXOpen.Point.Null
    assocOrigin20.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin20.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin20.XOffsetFactor = 0.0
    assocOrigin20.YOffsetFactor = 0.0
    assocOrigin20.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder24.Origin.SetAssociativeOrigin(assocOrigin20)
    
    point64 = NXOpen.Point3d(-16.723001482868646, -30.290333315773033, 0.0)
    sketchRapidDimensionBuilder24.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point64)
    
    sketchRapidDimensionBuilder24.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder24.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder24.Style.DimensionStyle.TextCentered = False
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject31 = sketchRapidDimensionBuilder24.Commit()
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.SetUndoMarkName(markId194, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder24.Destroy()
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder25 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines121 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBefore(lines121)
    
    lines122 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAfter(lines122)
    
    lines123 = []
    sketchRapidDimensionBuilder25.AppendedText.SetAbove(lines123)
    
    lines124 = []
    sketchRapidDimensionBuilder25.AppendedText.SetBelow(lines124)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder25.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId196, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder25.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits775 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits776 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits777 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits778 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits779 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits780 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits781 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits782 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits783 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits784 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder25.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits785 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits786 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits787 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits788 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits789 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits790 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits791 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits792 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits793 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits794 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    expression76 = workPart.Expressions.FindObject("p25")
    expression76.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId197, None)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId196, "Edit Driving Value")
    
    point1_107 = NXOpen.Point3d(11.000000000000007, -15.000000000000002, 0.0)
    point2_107 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_107, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_107)
    
    point1_108 = NXOpen.Point3d(11.000000000000007, -15.000000000000002, 0.0)
    point2_108 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc9, workPart.ModelingViews.WorkView, point1_108, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_108)
    
    point1_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_109 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_109, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_109)
    
    dimensionlinearunits795 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits796 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits797 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits798 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits799 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits800 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    point1_110 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_110 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_110, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_110)
    
    point1_111 = NXOpen.Point3d(11.000000000000007, -15.000000000000002, 0.0)
    point2_111 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_111, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_111)
    
    point1_112 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_112 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_112, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_112)
    
    point1_113 = NXOpen.Point3d(11.000000000000007, -15.000000000000002, 0.0)
    point2_113 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc9, workPart.ModelingViews.WorkView, point1_113, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_113)
    
    point1_114 = NXOpen.Point3d(2.0206672185931331e-15, -15.000000000000004, 0.0)
    point2_114 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder25.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line4, workPart.ModelingViews.WorkView, point1_114, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_114)
    
    dimensionlinearunits801 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits802 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits803 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits804 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits805 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits806 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits807 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits808 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits809 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits810 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits811 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits812 = sketchRapidDimensionBuilder25.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin21 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin21.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin21.View = NXOpen.View.Null
    assocOrigin21.ViewOfGeometry = workPart.ModelingViews.WorkView
    point65 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin21.PointOnGeometry = point65
    assocOrigin21.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.DimensionLine = 0
    assocOrigin21.AssociatedView = NXOpen.View.Null
    assocOrigin21.AssociatedPoint = NXOpen.Point.Null
    assocOrigin21.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin21.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin21.XOffsetFactor = 0.0
    assocOrigin21.YOffsetFactor = 0.0
    assocOrigin21.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder25.Origin.SetAssociativeOrigin(assocOrigin21)
    
    point66 = NXOpen.Point3d(6.5352646840906825, -39.290271093422518, 0.0)
    sketchRapidDimensionBuilder25.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point66)
    
    sketchRapidDimensionBuilder25.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder25.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder25.Style.DimensionStyle.TextCentered = True
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject32 = sketchRapidDimensionBuilder25.Commit()
    
    theSession.DeleteUndoMark(markId199, None)
    
    theSession.SetUndoMarkName(markId198, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId198, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder25.Destroy()
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder26 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines125 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBefore(lines125)
    
    lines126 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAfter(lines126)
    
    lines127 = []
    sketchRapidDimensionBuilder26.AppendedText.SetAbove(lines127)
    
    lines128 = []
    sketchRapidDimensionBuilder26.AppendedText.SetBelow(lines128)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder26.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId200, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder26.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits813 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits814 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits815 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits816 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits817 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits818 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits819 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits820 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits821 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits822 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder26.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder26.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder26.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits823 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits824 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits825 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits826 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits827 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits828 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits829 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits830 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits831 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits832 = sketchRapidDimensionBuilder26.Style.UnitsStyle.DimensionLinearUnits
    
    expression77 = workPart.Expressions.FindObject("p26")
    expression77.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId201, None)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId200, "Edit Driving Value")
    
    sketchRapidDimensionBuilder26.Destroy()
    
    theSession.UndoToMark(markId202, None)
    
    theSession.DeleteUndoMark(markId202, None)
    
    sketchRapidDimensionBuilder26.Destroy()
    
    # ----------------------------------------------
    #   Menu: File->Finish Sketch
    # ----------------------------------------------
    sketch13 = theSession.ActiveSketch
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression78 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies23)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId204, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features5 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature5 = feature12
    features5[0] = sketchFeature5
    curveFeatureRule5 = workPart.ScRuleFactory.CreateRuleCurveFeature(features5)
    
    section8.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule5
    helpPoint5 = NXOpen.Point3d(19.81570836292363, -13.68714454381416, 0.0)
    section8.AddToSection(rules5, arc9, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId206, None)
    
    direction12 = workPart.Directions.CreateDirection(sketch13, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction12
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Unite
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = body1
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies25)
    
    expression79 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression80 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId205, None)
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    feature13 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId207, None)
    
    theSession.SetUndoMarkName(markId204, "Extrude")
    
    expression81 = extrudeBuilder8.Limits.StartExtend.Value
    expression82 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression78)
    
    workPart.Expressions.Delete(expression79)
    
    workPart.Expressions.Delete(expression80)
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies26)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId208, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Dialog Begin Extrude
    # ----------------------------------------------
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 0.97369400874859913
    rotMatrix24.Xy = 0.042052160249927709
    rotMatrix24.Xz = -0.22394551378715785
    rotMatrix24.Yx = 0.22344966114976425
    rotMatrix24.Yy = 0.016203606308708075
    rotMatrix24.Yz = 0.97458077760370376
    rotMatrix24.Zx = 0.044611951976298914
    rotMatrix24.Zy = -0.99898401336603138
    rotMatrix24.Zz = 0.0063808134244488137
    translation24 = NXOpen.Point3d(-1.7082418769532168, -51.400371984776868, 33.955414080032966)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 1.0716992611459712)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.27839320981890958
    rotMatrix25.Xy = -0.76389596324056463
    rotMatrix25.Xz = 0.58220286676681154
    rotMatrix25.Yx = 0.085373538969156434
    rotMatrix25.Yy = 0.62344809707932236
    rotMatrix25.Yz = 0.77718969955349593
    rotMatrix25.Zx = -0.95666534356095834
    rotMatrix25.Zy = -0.16665961596302031
    rotMatrix25.Zz = 0.23878021868750315
    translation25 = NXOpen.Point3d(-27.340808825771909, -31.575712264000263, 61.755957436607844)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 1.0716992611459712)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = 0.7704189678301665
    rotMatrix26.Xy = 0.44305430919073624
    rotMatrix26.Xz = 0.45842937636567366
    rotMatrix26.Yx = -0.45402631514569186
    rotMatrix26.Yy = -0.1235092649001116
    rotMatrix26.Yz = 0.8823862910534469
    rotMatrix26.Zx = 0.44756532390560255
    rotMatrix26.Zy = -0.88794613608673001
    rotMatrix26.Zz = 0.10600443502948337
    translation26 = NXOpen.Point3d(-16.403667041529886, -33.779348376183592, 22.214215502730465)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 1.0716992611459712)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()